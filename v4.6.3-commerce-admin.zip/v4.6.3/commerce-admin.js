/*
 * GPTYAR Commerce Admin v1
 *
 * Adds an authenticated administrative UI for coupon and catalog-price management.
 * This module does NOT modify checkout/client-side totals. All mutations are sent to
 * authenticated backend admin endpoints and only run after an explicit user action.
 *
 * Default endpoint contract (configurable in the UI):
 *   GET    /accupdator/coupons
 *   POST   /accupdator/coupons
 *   PATCH  /accupdator/coupons/{id}
 *   DELETE /accupdator/coupons/{id}
 *   GET    /accupdator/products
 *   PATCH  /accupdator/products/{id}/price
 */
;(() => {
  'use strict';

  const VERSION = '1.0.0';
  const STORAGE_KEY = 'gptyarCommerceAdminConfigV1';
  const ROOT_ID = 'gptyarCommerceAdminRoot';
  const OPEN_BUTTON_ID = 'gptyarCommerceAdminOpen';

  const DEFAULTS = Object.freeze({
    couponList: '/accupdator/coupons',
    couponCreate: '/accupdator/coupons',
    couponUpdate: '/accupdator/coupons/{id}',
    couponDelete: '/accupdator/coupons/{id}',
    productList: '/accupdator/products',
    productPriceUpdate: '/accupdator/products/{id}/price'
  });

  let config = { ...DEFAULTS };
  let currentCoupons = [];
  let selectedCouponId = null;
  let root = null;

  const $ = (selector, scope = document) => scope.querySelector(selector);
  const $$ = (selector, scope = document) => Array.from(scope.querySelectorAll(selector));

  const escapeHtml = value => String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');

  const getApiBase = () => {
    try {
      if (typeof CONFIG !== 'undefined' && CONFIG && CONFIG.API_SERVER) {
        return String(CONFIG.API_SERVER).replace(/\/$/, '');
      }
    } catch (_) {}
    return 'https://api.gptyar.com';
  };

  const getToken = () => {
    try {
      if (typeof PopupState !== 'undefined' && PopupState && PopupState.token) {
        return String(PopupState.token);
      }
    } catch (_) {}
    return '';
  };

  const resolvePath = (template, params = {}) => {
    let path = String(template || '').trim();
    for (const [key, value] of Object.entries(params)) {
      path = path.replaceAll(`{${key}}`, encodeURIComponent(String(value ?? '')));
    }
    if (/^https:\/\//i.test(path)) return path;
    if (!path.startsWith('/')) path = '/' + path;
    return getApiBase() + path;
  };

  const parseResponse = async response => {
    const text = await response.text();
    if (!text) return null;
    try { return JSON.parse(text); } catch (_) { return text; }
  };

  async function apiRequest(pathTemplate, method = 'GET', body = null, params = {}) {
    const url = resolvePath(pathTemplate, params);
    const headers = { 'Accept': 'application/json' };
    const token = getToken();
    if (token) headers.Authorization = `Bearer ${token}`;
    if (body !== null && body !== undefined) headers['Content-Type'] = 'application/json';

    const response = await fetch(url, {
      method,
      headers,
      cache: 'no-store',
      body: body !== null && body !== undefined ? JSON.stringify(body) : undefined
    });

    const data = await parseResponse(response);
    if (!response.ok) {
      const detail = typeof data === 'string' ? data : JSON.stringify(data ?? {});
      const error = new Error(`HTTP ${response.status}${detail ? ` — ${detail}` : ''}`);
      error.status = response.status;
      error.data = data;
      throw error;
    }
    return data;
  }

  function extractArray(data, preferredKeys = []) {
    if (Array.isArray(data)) return data;
    if (!data || typeof data !== 'object') return [];
    for (const key of preferredKeys) {
      if (Array.isArray(data[key])) return data[key];
    }
    if (data.data && type