function a0_0x3190(_0x4908b7,_0x3a2ef1){const _0x3bb254=a0_0x3bb2();return a0_0x3190=function(_0x31905e,_0x1e4b53){_0x31905e=_0x31905e-0xd9;let _0xef86da=_0x3bb254[_0x31905e];return _0xef86da;},a0_0x3190(_0x4908b7,_0x3a2ef1);}const a0_0x4d3c49=a0_0x3190;function a0_0x3bb2(){const _0x77029f=['SUBS_MENU','switchToSection','accupdatorCredMfaCode','کوکی\x20های\x20','\x20با\x20موفقیت\x20آپدیت\x20شد','LOGOUT_BTN','MANAGE_SUBS_BTN','items','testing','_initializeCalendar','https://','_normalizeProxy','getElement','PROXY_SECTION','SUBSCRIBER_DETAILS_MENU','[AccupdatorManager]\x20New\x20user\x20menu\x20created','[AccupdatorManager]\x20Invalid\x20proxy\x20index:','setupAccupdatorEventListeners','2025-12-04T13:00:00Z','show','SUBSCRIBER_DETAILS_NAME','\x22\x20class=\x22accupdator-btn\x20secondary-btn\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<svg\x20width=\x2216\x22\x20height=\x2216\x22\x20viewBox=\x220\x200\x2024\x2024\x22\x20fill=\x22none\x22\x20stroke=\x22currentColor\x22\x20stroke-width=\x222\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<path\x20d=\x22M18\x2013v6a2\x202\x200\x200\x201-2\x202H5a2\x202\x200\x200\x201-2-2V8a2\x202\x200\x200\x201\x202-2h6\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<polyline\x20points=\x2215\x203\x2021\x203\x2021\x209\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<line\x20x1=\x2210\x22\x20y1=\x2214\x22\x20x2=\x2221\x22\x20y2=\x223\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</svg>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20لود\x20کردن\x20کوکی\x20بر\x20روی\x20وبسایت\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</button>\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20','Accupdator\x20token\x20required','CRED_EMAIL_COPY','stringify','\x22\x20class=\x22accupdator-btn\x20danger-btn\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<svg\x20width=\x2216\x22\x20height=\x2216\x22\x20viewBox=\x220\x200\x2024\x2024\x22\x20fill=\x22none\x22\x20stroke=\x22currentColor\x22\x20stroke-width=\x222\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<polyline\x20points=\x223\x206\x205\x206\x2021\x206\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<path\x20d=\x22M19\x206v14a2\x202\x200\x200\x201-2\x202H7a2\x202\x200\x200\x201-2-2V6m3\x200V4a2\x202\x200\x200\x201\x202-2h4a2\x202\x200\x200\x201\x202\x202v2\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</svg>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20حذف\x20کاربر\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20','DELETE_COOKIES_BTN','350852QTcCxz','remove','_renderCalendar','/accupdator/update-cookies','[AccupdatorManager]\x20Creating\x20new\x20user:','IS_CHECKED','<!--\x20No\x20agent\x20type\x20assigned\x20-->','26cjTNiG','_calculateRemainingDays','chatgpt.com','STORAGE_KEYS','سرور\x20سوم','_hideNewUserMenu','join','SUBS_SEARCH_INPUT','_handleCreateNewUser','activeSubscriptionsCount','\x22\x20class=\x22new-user-btn\x22\x20title=\x22ایجاد\x20کاربر\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<svg\x20width=\x2218\x22\x20height=\x2218\x22\x20viewBox=\x220\x200\x2024\x2024\x22\x20fill=\x22none\x22\x20stroke=\x22currentColor\x22\x20stroke-width=\x222\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<line\x20x1=\x2212\x22\x20y1=\x225\x22\x20x2=\x2212\x22\x20y2=\x2219\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<line\x20x1=\x225\x22\x20y1=\x2212\x22\x20x2=\x2219\x22\x20y2=\x2212\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</svg>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20<!--\x20Subscribers\x20list\x20-->\x0a\x20\x20\x20\x20\x20\x20\x20\x20<div\x20id=\x22','\x0a\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22admin-proxy-item','isActive','خطا\x20در\x20بارگذاری\x20جزئیات\x20کاربر','[AccupdatorManager]\x20Error\x20refreshing\x20cookie\x20status:','no-cache','\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22admin-proxy-info\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22admin-proxy-name\x22>','<span\x20class=\x22','lastError','NEW_USER_BTN','_calendarState','_verifyAccupdatorAuth','ensure','SUBSCRIBER_CALENDAR','getServiceName','[AccupdatorManager]\x20Failed\x20to\x20create\x20accupdator\x20section','_setupSubscribersMenuEventListeners','18ZEWRfP','LOADING','_fetchAdminProxies','\x22\x20class=\x22cookie-status-card\x20hide\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22cookie-status-glow\x22></div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22cookie-status-row\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22cookie-status-dot\x22></span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22cookie-status-label\x22>وضعیت\x20کوکی:</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20id=\x22','[AccupdatorManager]\x20Closing\x20subscriber\x20details\x20menu...','_filteredSubscribersList','[AccupdatorManager]\x20Error\x20creating\x20new\x20user:','subscriberDetailsMenu','[AccupdatorAPI]\x20Response\x20status:\x20','NEW_USER_NAME_INPUT','_setProxyKeepAliveState','[AccupdatorManager]\x20Proxy\x20toggle\x20changed:','offline','_generateSubscriberItemHTML','create','_hideCookieStatus','accupdatorCredPassword','totalSubscriptionsCount','[AccupdatorAPI]\x20Account\x20info\x20fetched\x20and\x20stored:','[AccupdatorManager]\x20API\x20response\x20data:','[AccupdatorManager]\x20Loading\x20subscribers...','\x22\x20class=\x22accupdator-btn\x20danger-btn\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<svg\x20width=\x2216\x22\x20height=\x2216\x22\x20viewBox=\x220\x200\x2024\x2024\x22\x20fill=\x22none\x22\x20stroke=\x22currentColor\x22\x20stroke-width=\x222\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<polyline\x20points=\x223\x206\x205\x206\x2021\x206\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<path\x20d=\x22M19\x206v14a2\x202\x200\x200\x201-2\x202H7a2\x202\x200\x200\x201-2-2V6m3\x200V4a2\x202\x200\x200\x201\x202-2h4a2\x202\x200\x200\x201\x202\x202v2\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</svg>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20حذف\x20کوکی\x20ها\x20از\x20سرور\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<!--\x20Subscriptions\x20Section\x20-->\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20id=\x22','PATCH','status-green','http://','getElementById','newUserNameInput','PROXY_REFRESH_BTN','[AccupdatorManager]\x20Selecting\x20random\x20proxy\x20index:','[AccupdatorManager]\x20Subscription\x20stats\x20updated\x20from\x20account\x20data','</span>','createElement','\x22>-</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22stat-label\x22>اشتراک\x20فعال</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22stat-item\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22stat-value\x22\x20id=\x22','textContent','isFinite','status-yellow','_selectedAdminProxyIndex','_selectAdminProxy','updateSubscriberExpiry','accupdatorCredMfaCopy','کاربر\x20جدید\x20با\x20موفقیت\x20ایجاد\x20شد','4YqldbI','\x22\x20class=\x22section-card-content\x20admin-proxy-content\x22\x20style=\x22display:\x20none;\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22admin-proxy-header\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22admin-proxy-label\x22>انتخاب\x20پروکسی</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20id=\x22','_proxyServerNames','[AccupdatorAPI]\x20Making\x20','[AccupdatorManager]\x20Subscriptions\x20menu\x20opened\x20successfully','[AccupdatorManager]\x20Error\x20opening\x20subscriber\x20details:','[AccupdatorManager]\x20createNewUser\x20called\x20with:','length','_renderAdminProxyList','_makeAPIRequest','SUBSCRIBER_DETAILS_EXPIRY','_setupProxyEventListeners','[AccupdatorManager]\x20Handling\x20test\x20load\x20cookie\x20on\x20website...','[AccupdatorManager]\x20Admin\x20proxies\x20received:','fetchSubscribersList','_navigateNewUserCalendar','get','_createSubscriberDetailsMenu','.subscriber-item[data-token]','click','calendarPrevMonth','_generateSectionHTML','_persianMonths','accupdatorTestLoadCookieBtn','HMAC','[AccupdatorManager]\x20Handling\x20cookie\x20update\x20for:\x20','fetchCookiesStatus','sign','expired','\x22>نام\x20کاربر:</label>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<input\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20type=\x22text\x22\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20id=\x22','NEW_USER_MENU','accupdatorCredEmail','\x22\x20class=\x22cred-mfa-timer\x22>30</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20id=\x22','now','PANEL','[AccupdatorManager]\x20Error\x20creating\x20accupdator\x20section:','cred-mfa-timer-low','subscriberCalendar','path','SUBSCRIBER_DETAILS_TOKEN','\x22\x20class=\x22subscribers-back-btn\x22\x20title=\x22بازگشت\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<svg\x20width=\x2218\x22\x20height=\x2218\x22\x20viewBox=\x220\x200\x2024\x2024\x22\x20fill=\x22none\x22\x20stroke=\x22currentColor\x22\x20stroke-width=\x222\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<polyline\x20points=\x2215\x2018\x209\x2012\x2015\x206\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</svg>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<h2\x20class=\x22subscribers-title\x22>مدیریت\x20کاربران</h2>\x0a\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20<!--\x20Search\x20bar\x20with\x20new\x20user\x20button\x20-->\x0a\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22subscribers-search-row\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22subscribers-search-container\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<svg\x20class=\x22search-icon\x22\x20width=\x2216\x22\x20height=\x2216\x22\x20viewBox=\x220\x200\x2024\x2024\x22\x20fill=\x22none\x22\x20stroke=\x22currentColor\x22\x20stroke-width=\x222\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<circle\x20cx=\x2211\x22\x20cy=\x2211\x22\x20r=\x228\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<line\x20x1=\x2221\x22\x20y1=\x2221\x22\x20x2=\x2216.65\x22\x20y2=\x2216.65\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</svg>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<input\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20type=\x22text\x22\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20id=\x22','innerHTML','SUBS_MENU_BACK_BTN','API\x20request\x20failed\x20with\x20status:\x20','subscriberCopyTokenBtn','[AccupdatorManager]\x20Error\x20refreshing\x20account\x20info:','device_id','\x20selected','2025-12-02T11:00:00Z','[AccupdatorManager]\x20Error\x20initializing\x20proxy\x20state:','available','Copy\x20MFA\x20code','showSuccess','accupdatorData','value','\x22\x20class=\x22accupdator-btn\x20primary-btn\x22\x20disabled>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<svg\x20width=\x2216\x22\x20height=\x2216\x22\x20viewBox=\x220\x200\x2024\x2024\x22\x20fill=\x22none\x22\x20stroke=\x22currentColor\x22\x20stroke-width=\x222\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<polyline\x20points=\x2220\x206\x209\x2017\x204\x2012\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</svg>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20اعمال\x20تغییرات\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20id=\x22','2025-11-20T14:00:00Z','calendarNextMonth','[AccupdatorManager]\x20Proxy\x20','[AccupdatorManager]\x20Error\x20fetching\x20subscriber\x20details:','[AccupdatorAPI]\x20Fetching\x20cookies\x20status...','_createNewUserMenu','خطا\x20در\x20کپی\x20توکن','/client/proxy-info','77uVHVqD','_newUserExpiryDate','Main\x20card\x20container\x20not\x20found','handleLogout','امروز','_stopMfaLoop','[AccupdatorManager]\x20Error\x20disabling\x20proxy:','newUserCreateBtn','random','subscriberDetailsName','Copy\x20email','_setupSubscriberItemListeners','\x22\x20class=\x22cookie-status-value\x22>ست\x20شده</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22cookie-status-row\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<svg\x20class=\x22cookie-status-clock\x22\x20width=\x2214\x22\x20height=\x2214\x22\x20viewBox=\x220\x200\x2024\x2024\x22\x20fill=\x22none\x22\x20stroke=\x22currentColor\x22\x20stroke-width=\x222\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<circle\x20cx=\x2212\x22\x20cy=\x2212\x22\x20r=\x2210\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<polyline\x20points=\x2212\x206\x2012\x2012\x2016\x2014\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</svg>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22cookie-status-label\x22>زمان\x20باقی\x20مانده:</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20id=\x22','PROXY_PORT','\x22\x20class=\x22subscribers-back-btn\x22\x20title=\x22بازگشت\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<svg\x20width=\x2218\x22\x20height=\x2218\x22\x20viewBox=\x220\x200\x2024\x2024\x22\x20fill=\x22none\x22\x20stroke=\x22currentColor\x22\x20stroke-width=\x222\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<polyline\x20points=\x2215\x2018\x209\x2012\x2015\x206\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</svg>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<h2\x20class=\x22subscribers-title\x22>جزئیات\x20کاربر</h2>\x0a\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20<!--\x20Scrollable\x20Body\x20-->\x0a\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22subscriber-details-body\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<!--\x20User\x20Info\x20Card\x20-->\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22subscriber-details-card\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22detail-row\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22detail-label\x22>نام:</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20id=\x22','\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20id=\x22','\x22\x20class=\x22copy-token-btn\x22\x20title=\x22کپی\x20توکن\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<svg\x20width=\x2214\x22\x20height=\x2214\x22\x20viewBox=\x220\x200\x2024\x2024\x22\x20fill=\x22none\x22\x20stroke=\x22currentColor\x22\x20stroke-width=\x222\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<rect\x20x=\x229\x22\x20y=\x229\x22\x20width=\x2213\x22\x20height=\x2213\x22\x20rx=\x222\x22\x20ry=\x222\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<path\x20d=\x22M5\x2015H4a2\x202\x200\x200\x201-2-2V4a2\x202\x200\x200\x201\x202-2h9a2\x202\x200\x200\x201\x202\x202v1\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</svg>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22detail-row\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22detail-label\x22>تاریخ\x20پایان\x20اشتراک:</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20id=\x22','Proxy\x20configuration\x20failed','data-day','/accupdator/subscribers/update','status','CRED_PASSWORD_COPY','remainingDays','SUBS_LIST','[AccupdatorManager]\x20Cookie\x20extraction\x20error:','[AccupdatorManager]\x20Selecting\x20admin\x20proxy:','/accupdator/delete-cookies','COOKIE_STATUS_REMAINING','COOKIE_STATUS_VALUE','[AccupdatorManager]\x20Active\x20tab\x20found:\x20','from','\x20cookies\x20updated\x20successfully','<div\x20class=\x22subscribers-empty\x22>خطا\x20در\x20بارگذاری\x20لیست</div>','json','totalSubscriptions','\x22\x20class=\x22subscribers-back-btn\x22\x20title=\x22بازگشت\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<svg\x20width=\x2218\x22\x20height=\x2218\x22\x20viewBox=\x220\x200\x2024\x2024\x22\x20fill=\x22none\x22\x20stroke=\x22currentColor\x22\x20stroke-width=\x222\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<polyline\x20points=\x2215\x2018\x209\x2012\x2015\x206\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</svg>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<h2\x20class=\x22subscribers-title\x22>کاربر\x20جدید</h2>\x0a\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20<!--\x20Scrollable\x20Body\x20-->\x0a\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22subscriber-details-body\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<!--\x20Name\x20Input\x20Card\x20-->\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22subscriber-details-card\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22detail-row\x20new-user-input-row\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<label\x20class=\x22detail-label\x22\x20for=\x22','change','newUserMenu','1061230ODUsHj','[AccupdatorManager]\x20No\x20assigned\x20agent\x20type,\x20skipping\x20update\x20button\x20setup','newUserCalendarMonthYear','[AccupdatorManager]\x20Accupdator\x20section\x20created\x20successfully','[AccupdatorManager]\x20Fetching\x20subscriptions\x20list...','سرور\x20چهارم','[AccupdatorManager]\x20Account\x20description\x20did\x20not\x20match\x20expected\x20credentials\x20format','checked','grok.com','Authorization','[AccupdatorManager]\x20Error\x20fetching\x20admin\x20proxies:','[AccupdatorManager]\x20Extracted\x20','_setupNewUserMenuEventListeners','.card','subscriberApplyBtn','\x22\x20class=\x22detail-value\x20detail-token\x22>-</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20id=\x22','_puid','/accupdator/subscribers/all','No\x20cookies\x20found\x20for\x20','_resetNewUserForm','PROXY_HOST','newUserCalendarPrevMonth','\x20روز\x20مانده','[AccupdatorManager]\x20Updating\x20subscriber\x20expiry\x20for\x20subscription:','handleCookieUpdate','getTime','[AccupdatorManager]\x20Error\x20copying\x20credential:','[AccupdatorManager]\x20All\x20event\x20listeners\x20setup\x20completed','showError','accupdatorCredEmailCopy','toggle','\x22\x20class=\x22subscriber-details-menu\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20<!--\x20Header\x20-->\x0a\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22subscriber-details-header\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20id=\x22','[AccupdatorManager]\x20Cookies\x20extracted,\x20sending\x20to\x20API...','raw','_setupButton','generate','sections','[AccupdatorManager]\x20Error\x20fetching\x20subscribers\x20list:','<div\x20class=\x22admin-proxy-empty\x22>خطا\x20در\x20بارگذاری\x20پروکسی‌ها</div>','</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22subscriber-token\x22>','\x22\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20class=\x22new-user-name-input\x22\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20placeholder=\x22نام\x20کاربر\x20را\x20وارد\x20کنید\x22\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22detail-row\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22detail-label\x22>تاریخ\x20پایان\x20اشتراک:</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20id=\x22','COOKIE_STATUS_CARD','[AccupdatorManager]\x20Token\x20verified,\x20extracting\x20cookies...','getDay','_renderNewUserCalendar','deleteSubscriber','insertAdjacentHTML','name','NEW_USER_BACK_BTN','\x22\x20class=\x22accupdator-section-card\x20','[AccupdatorManager]\x20Proxy\x20state\x20initialized:','_renderAccountCredentials','\x22\x20data-day=\x22','_hideSubscribersMenu','accupdatorAccountInfo','_newUserCalendarState','9332772dNRSIt','/accupdator/subscribers/create','\x22\x20title=\x22','_handleCopyToken','padStart','\x22\x20class=\x22calendar-days\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<!--\x20Days\x20will\x20be\x20generated\x20dynamically\x20-->\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<!--\x20Action\x20Buttons\x20-->\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22subscriber-details-actions\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20id=\x22','API_SERVER','querySelector','_handleDeleteSubscriber','Invalid\x20API\x20response:\x20missing\x20message','[AccupdatorManager]\x20Error\x20in\x20handleCookieUpdate\x20for\x20','fetchAccountInfo','showSubscriptionsMenu','copied','style','_loadSubscribers','none','runtime','querySelectorAll','[AccupdatorManager]\x20Using\x20stored\x20proxy\x20index:','_renderCookieStatus','[AccupdatorManager]\x20Stored\x20proxy\x20index:','\x20cookies:','expirationDate','_getCookieDomains','<div\x20class=\x22admin-proxy-empty\x22>هیچ\x20پروکسی\x20در\x20دسترس\x20نیست</div>','toLowerCase','_gregorianToPersian','امکان\x20تنظیم\x20پروکسی\x20وجود\x20ندارد.\x20بارگذاری\x20کوکی\x20متوقف\x20شد.','indexOf','_adminProxies','\x0a\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22admin-proxy-item\x20skeleton\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22skeleton-line\x20name\x22></div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22skeleton-line\x20ping\x22></div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20','_base32ToBytes','active','غیرفعال','Not\x20implemented','_getFirstDayOfPersianMonth','_proxyEnabled','[AccupdatorManager]\x20Disabling\x20proxy...','getMonth','CRED_MFA_CODE','accupdatorCredentialsSection','title','POST','set','PROXY_LIST','refreshAccountInfo','آفلاین','type','\x22\x20class=\x22accupdator-btn\x20primary-btn\x22\x20disabled>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<svg\x20width=\x2216\x22\x20height=\x2216\x22\x20viewBox=\x220\x200\x2024\x2024\x22\x20fill=\x22none\x22\x20stroke=\x22currentColor\x22\x20stroke-width=\x222\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<path\x20d=\x22M16\x2021v-2a4\x204\x200\x200\x200-4-4H5a4\x204\x200\x200\x200-4\x204v2\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<circle\x20cx=\x228.5\x22\x20cy=\x227\x22\x20r=\x224\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<line\x20x1=\x2220\x22\x20y1=\x228\x22\x20x2=\x2220\x22\x20y2=\x2214\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<line\x20x1=\x2223\x22\x20y1=\x2211\x22\x20x2=\x2217\x22\x20y2=\x2211\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</svg>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20ایجاد\x20کاربر\x20جدید\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20','data-index','SUBSCRIBER_COPY_TOKEN_BTN','_disableProxy','ceil','NEW_USER_EXPIRY','subscribersMenu','cookies','تاریخ\x20پایان\x20اشتراک\x20با\x20موفقیت\x20به‌روزرسانی\x20شد','توکن\x20کپی\x20شد','forEach','_setupSubscriberDetailsEventListeners','_handleCopyCredential','PROXY_SERVER','application/json','expiry-changing','url','</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22status-indicator\x20','خطا\x20در\x20کپی\x20کردن','دریافت\x20کوکی\x20از\x20سرور\x20ناموفق\x20بود','_parseAccountCredentials','[AccupdatorManager]\x20Accupdator\x20section\x20not\x20found','_selectedNewDate','_mfaCurrentCode','midjourney.com','www.midjourney.com','[AccupdatorManager]\x20Generating\x20section\x20for\x20agent\x20type:\x20','split','expiryDate','ensureProxyBeforeTargetAccess','_openSubscriberDetails','selected','انتخاب\x20نشده','day','8059248sDHcqQ','[AccupdatorManager]\x20No\x20agent\x20type\x20found\x20in\x20accupdatorData','\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20<div\x20id=\x22','PROXY_LIST_CONTAINER','_updateSubscriberDetailsContent','\x22\x20class=\x22section\x20','abort','accupdatorAgentInfo','\x22\x20class=\x22copy-token-btn\x22\x20type=\x22button\x22\x20title=\x22کپی\x20رمز\x20عبور\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<svg\x20width=\x2214\x22\x20height=\x2214\x22\x20viewBox=\x220\x200\x2024\x2024\x22\x20fill=\x22none\x22\x20stroke=\x22currentColor\x22\x20stroke-width=\x222\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<rect\x20x=\x229\x22\x20y=\x229\x22\x20width=\x2213\x22\x20height=\x2213\x22\x20rx=\x222\x22\x20ry=\x222\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<path\x20d=\x22M5\x2015H4a2\x202\x200\x200\x201-2-2V4a2\x202\x200\x200\x201\x202-2h9a2\x202\x200\x200\x201\x202\x202v1\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</svg>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22detail-row\x20cred-row\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22detail-label\x22>کد\x20MFA:</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22detail-value-with-action\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20id=\x22','CRED_MFA_COPY','\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22subscriber-info\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22subscriber-name\x22>','getFullYear','_generateSkeletonHTML','[AccupdatorManager]\x20','trim','message','_showNewUserMenu','\x22\x20class=\x22detail-value\x20cred-token\x22\x20dir=\x22ltr\x22>-</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20id=\x22','_handleApplyChanges','_testAdminProxies','status-red','Failed\x20to\x20create\x20accupdator\x20section\x20element','_refreshCookieStatus','\x0a\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22subscriber-item\x20skeleton\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22subscriber-info\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22skeleton-line\x20skeleton-name\x22></span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22skeleton-line\x20skeleton-token\x22></span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22subscriber-status\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22skeleton-line\x20skeleton-status\x22></span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22skeleton-dot\x22></span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20','\x22\x20class=\x22accupdator-btn\x20primary-btn\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<svg\x20width=\x2216\x22\x20height=\x2216\x22\x20viewBox=\x220\x200\x2024\x2024\x22\x20fill=\x22none\x22\x20stroke=\x22currentColor\x22\x20stroke-width=\x222\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<path\x20d=\x22M21\x2012a9\x209\x200\x200\x200-9-9\x209.75\x209.75\x200\x200\x200-6.74\x202.74L3\x208\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<path\x20d=\x22M3\x203v5h5\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<path\x20d=\x22M3\x2012a9\x209\x200\x200\x200\x209\x209\x209.75\x209.75\x200\x200\x200\x206.74-2.74L21\x2016\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<path\x20d=\x22M16\x2021h5v-5\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</svg>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20آپدیت\x20کوکی\x20های\x20سرور\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</button>','\x22\x20class=\x22admin-proxy-list\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<!--\x20Skeleton\x20loading\x20state\x20-->\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22admin-proxy-item\x20skeleton\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22skeleton-line\x20name\x22></div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22skeleton-line\x20ping\x22></div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22admin-proxy-item\x20skeleton\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22skeleton-line\x20name\x22></div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22skeleton-line\x20ping\x22></div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22admin-proxy-item\x20skeleton\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22skeleton-line\x20name\x22></div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22skeleton-line\x20ping\x22></div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div><!--\x20End\x20accupdator-content\x20-->\x0a\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20','آبان','block','[AccupdatorManager]\x20API\x20response\x20status:\x20','subscriberDeleteBtn','خطا\x20در\x20تغییر\x20پروکسی','accupdatorCookieStatusValue','ACTIVE_SUBS_COUNT','input','SUBS_SECTION','accupdatorFetchCookies','32koWoXR','/accupdator/subscribers/delete','[AccupdatorAPI]\x20Response\x20data:','agent','[AccupdatorManager]\x20Failed\x20to\x20open\x20tab\x20for','_setupAgentUpdateButton','کوکی\x20با\x20موفقیت\x20بارگذاری\x20و\x20وبسایت\x20باز\x20شد','newUserCalendar','Test\x20load\x20cookie\x20on\x20website','HIDE','classList','خرداد','floor','کاربر\x20با\x20موفقیت\x20حذف\x20شد','[AccupdatorManager]\x20UI\x20refreshed\x20successfully','display','remainingSeconds','inactive','error','[AccupdatorManager]\x20Account\x20info\x20refreshed\x20successfully','getDate','disableProxy','AGENT_INFO','updateCookies','\x20cookies\x20from\x20','533113UzquNv','subscriberDetailsBackBtn','[AccupdatorManager]\x20Creating\x20accupdator\x20section...','disabled','substring','subscriptions','[AccupdatorManager]\x20Test\x20load\x20cookie\x20error:','_updateAccountInfo','768060FCwrUo','\x22\x20class=\x22accupdator-section-card\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22section-card-header\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<svg\x20width=\x2218\x22\x20height=\x2218\x22\x20viewBox=\x220\x200\x2024\x2024\x22\x20fill=\x22none\x22\x20stroke=\x22currentColor\x22\x20stroke-width=\x222\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<circle\x20cx=\x2212\x22\x20cy=\x2212\x22\x20r=\x2210\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<line\x20x1=\x222\x22\x20y1=\x2212\x22\x20x2=\x2222\x22\x20y2=\x2212\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<path\x20d=\x22M12\x202a15.3\x2015.3\x200\x200\x201\x204\x2010\x2015.3\x2015.3\x200\x200\x201-4\x2010\x2015.3\x2015.3\x200\x200\x201-4-10\x2015.3\x2015.3\x200\x200\x201\x204-10z\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</svg>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span>فعال‌سازی\x20پروکسی</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<label\x20class=\x22admin-proxy-toggle\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<input\x20type=\x22checkbox\x22\x20id=\x22','loading','\x0a\x20\x20\x20\x20\x20\x20<div\x20class=\x22subscriber-item\x22\x20data-token=\x22','[AccupdatorAPI]\x20Fetching\x20subscriber\x20details\x20for\x20','sendProxyAuth','match','خطا\x20در\x20ایجاد\x20رابط\x20کاربری\x20Accupdator','NEW_USER_CREATE_BTN','PROXY_TOGGLE','extractCookies','adminProxyRefreshBtn','ست\x20شده','/accupdator/fetch-cookies','setDate','map','خطا','سرور\x20پنجم','adminProxySection','_navigateCalendar','success','_updateSubscriptionStats','[AccupdatorManager]\x20Applying\x20changes\x20for\x20subscription:','</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22admin-proxy-status\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22admin-proxy-ping\x22>تست...</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20','[AccupdatorManager]\x20Extracting\x20cookies\x20for:\x20','[AccupdatorManager]\x20Closing\x20subscriptions\x20menu...','[AccupdatorManager]\x20Error\x20applying\x20changes:','accupdatorLogout','<div\x20class=\x22subscribers-empty\x22>اشتراکی\x20یافت\x20نشد</div>','\x20today','اسفند','manageSubscriptionsBtn','خطا\x20در\x20باز\x20کردن\x20وبسایت','کاربر\x20یافت\x20نشد','[AccupdatorManager]\x20Error\x20in\x20handleCookieDelete:','_generateProxySkeletonHTML','ELEMENT_IDS','TOTAL_SUBS_COUNT','headers','ایمیل\x20کپی\x20شد','PING_PORT','__GPTYAR_DEV_LOG__','_hideSubscriberDetailsMenu','tabs','سرور\x20','):\x20','accupdatorCookieStatusRemaining','query','\x22\x20class=\x22accupdator-logout-btn\x22\x20title=\x22خروج\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<svg\x20width=\x2218\x22\x20height=\x2218\x22\x20viewBox=\x220\x200\x2024\x2024\x22\x20fill=\x22none\x22\x20stroke=\x22currentColor\x22\x20stroke-width=\x222\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<path\x20d=\x22M9\x2021H5a2\x202\x200\x200\x201-2-2V5a2\x202\x200\x200\x201\x202-2h4\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<polyline\x20points=\x2216\x2017\x2021\x2012\x2016\x207\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<line\x20x1=\x2221\x22\x20y1=\x2212\x22\x20x2=\x229\x22\x20y2=\x2212\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</svg>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<!--\x20Scrollable\x20Content\x20-->\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22accupdator-content\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<!--\x20Account\x20Info\x20Section\x20-->\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22accupdator-section-card\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22section-card-header\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<svg\x20width=\x2218\x22\x20height=\x2218\x22\x20viewBox=\x220\x200\x2024\x2024\x22\x20fill=\x22none\x22\x20stroke=\x22currentColor\x22\x20stroke-width=\x222\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<path\x20d=\x22M20\x2021v-2a4\x204\x200\x200\x200-4-4H8a4\x204\x200\x200\x200-4\x204v2\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<circle\x20cx=\x2212\x22\x20cy=\x227\x22\x20r=\x224\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</svg>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span>اطلاعات\x20حساب</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22section-card-content\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22info-row\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22info-label\x22>نام\x20حساب:</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20id=\x22','\x20expiry','.calendar-day:not(.empty)','_setupProxyItemListeners','[AccupdatorManager]\x20Deleting\x20cookies\x20via\x20API...','خطا\x20در\x20بارگذاری\x20کوکی:\x20','\x20روز','CSS_CLASSES','\x22\x20class=\x22subscribers-list\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<!--\x20Subscribers\x20will\x20be\x20dynamically\x20inserted\x20here\x20-->\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22subscribers-loading\x22>در\x20حال\x20بارگذاری...</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20','[AccupdatorManager]\x20Creating\x20subscriber\x20details\x20menu...','پایان\x20اشتراک','importKey','_refreshAdminProxies','account','\x20button\x20not\x20found\x20(ID:\x20','subscriptionsSection','domain','[AccupdatorAPI]\x20Fetching\x20subscribers\x20list...','_setButtonLoading','_subscribersList','[AccupdatorAPI]\x20Deleting\x20subscription\x20','[AccupdatorManager]\x20Error\x20deleting\x20subscriber:','[AccupdatorManager]\x20No\x20stored\x20proxy\x20preference,\x20defaulting\x20proxy\x20to\x20enabled','addEventListener','_handleProxyToggle','_formatPersianDate','[AccupdatorManager]\x20Opening\x20new\x20user\x20menu...','password','ACCOUNT_INFO','body','کد\x20MFA\x20کپی\x20شد','email','chat.openai.com','منقضی\x20شده','[AccupdatorManager]\x20Testing\x20admin\x20proxies...','toISOString','خطا\x20در\x20ایجاد\x20کاربر\x20جدید','[AccupdatorManager]\x20Cookies\x20deleted\x20successfully:','setUint32','[AccupdatorManager]\x20Fetching\x20subscribers\x20list...','div','CURRENT_VERSION','_mfaTimerHandle','SUBSCRIBER_APPLY_BTN','filter','\x22\x20class=\x22copy-token-btn\x22\x20type=\x22button\x22\x20title=\x22کپی\x20کد\x20MFA\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<svg\x20width=\x2214\x22\x20height=\x2214\x22\x20viewBox=\x220\x200\x2024\x2024\x22\x20fill=\x22none\x22\x20stroke=\x22currentColor\x22\x20stroke-width=\x222\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<rect\x20x=\x229\x22\x20y=\x229\x22\x20width=\x2213\x22\x20height=\x2213\x22\x20rx=\x222\x22\x20ry=\x222\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<path\x20d=\x22M5\x2015H4a2\x202\x200\x200\x201-2-2V4a2\x202\x200\x200\x201\x202-2h9a2\x202\x200\x200\x201\x202\x202v1\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</svg>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<!--\x20Cookies\x20Section\x20-->\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22accupdator-section-card\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22section-card-header\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<svg\x20width=\x2218\x22\x20height=\x2218\x22\x20viewBox=\x220\x200\x2024\x2024\x22\x20fill=\x22none\x22\x20stroke=\x22currentColor\x22\x20stroke-width=\x222\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<path\x20d=\x22M12\x202a10\x2010\x200\x201\x200\x2010\x2010\x204\x204\x200\x200\x201-5-5\x204\x204\x200\x200\x201-5-5\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<path\x20d=\x22M8.5\x208.5v.01\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<path\x20d=\x22M16\x2015.5v.01\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<path\x20d=\x22M12\x2012v.01\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<path\x20d=\x22M11\x2017v.01\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<path\x20d=\x22M7\x2014v.01\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</svg>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span>مدیریت\x20کوکی\x20ها</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22section-card-content\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20id=\x22','[AccupdatorManager]\x20Creating\x20new\x20accupdator\x20section...','_getPersianMonthDays','handleTestLoadCookie','_formatCookiesForAPI','[AccupdatorManager]\x20Refreshing\x20admin\x20proxies...','Manage\x20subscriptions','\x22\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20class=\x22subscribers-search-input\x22\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20placeholder=\x22جست‌‌و‌جو\x20با\x20نام\x20یا\x20توکن\x22\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20id=\x22','add','1245wnpgHz','subtle','find','beforeend','NEW_USER_CALENDAR','[AccupdatorManager]\x20Error\x20setting\x20up\x20event\x20listeners:','TEST_LOAD_COOKIE_BTN','</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22subscriber-status\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22status-text\x22>','target','\x20update','_request','\x22\x20data-index=\x22','subscriptionId','...','بهمن','accupdatorPanel','[AccupdatorManager]\x20Setting\x20up\x20event\x20listeners...','\x22\x20class=\x22cookie-status-remaining\x22>-</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22accupdator-buttons\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20id=\x22','GET','خطا\x20در\x20نمایش\x20رابط\x20کاربری\x20Accupdator','[AccupdatorManager]\x20Error\x20fetching\x20subscriptions\x20list:','[AccupdatorManager]\x20Cookies\x20deleted\x20successfully','getAll','21282cTKrmA','<span\x20class=\x22calendar-day\x20empty\x22></span>','\x20request\x20to:\x20','newUserExpiry','[AccupdatorManager]\x20Error\x20refreshing\x20UI:','SECTION','CRED_EMAIL','_selectedSubscriber','SELECTED_PROXY_INDEX','activeSubscriptions','\x22></span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20','_getAssignedAgentType','string','[AccupdatorManager]\x20Token\x20verified,\x20calling\x20delete\x20API...','[AccupdatorManager]\x20Making\x20','getDomain','_showCreatedUserDetails','SUBSCRIBER_DETAILS_BACK_BTN','_updateNewUserCreateButtonState','mfaSecret','changeProxyIndex','writeText','[AccupdatorManager]\x20Fetching\x20subscriber\x20details\x20for:','[AccupdatorManager]\x20Setting\x20up\x20proxy\x20event\x20listeners...','[AccupdatorManager]\x20Cookie\x20update\x20error:','calendar-day','\x22\x20class=\x22info-value\x20agent-badge\x22>-</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<!--\x20Account\x20Credentials\x20Section\x20(email\x20/\x20password\x20/\x20MFA)\x20-->\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20id=\x22','calendarMonthYear','subscribersList','deleteCookies','month','\x22\x20class=\x22accupdator-section-card\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22section-card-header\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<svg\x20width=\x2218\x22\x20height=\x2218\x22\x20viewBox=\x220\x200\x2024\x2024\x22\x20fill=\x22none\x22\x20stroke=\x22currentColor\x22\x20stroke-width=\x222\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<path\x20d=\x22M17\x2021v-2a4\x204\x200\x200\x200-4-4H5a4\x204\x200\x200\x200-4\x204v2\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<circle\x20cx=\x229\x22\x20cy=\x227\x22\x20r=\x224\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<path\x20d=\x22M23\x2021v-2a4\x204\x200\x200\x200-3-3.87\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<path\x20d=\x22M16\x203.13a4\x204\x200\x200\x201\x200\x207.75\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</svg>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span>اشتراک\x20ها</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22section-card-content\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22stats-grid\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22stat-item\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22stat-value\x22\x20id=\x22','[AccupdatorManager]\x20Deleting\x20subscription:','\x0a\x20\x20\x20\x20\x20\x20<div\x20id=\x22','\x22\x20class=\x22subscriber-details-menu\x20new-user-menu\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20<!--\x20Header\x20-->\x0a\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22subscriber-details-header\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20id=\x22','\x22\x20class=\x22info-value\x22>-</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22info-row\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22info-label\x22>نوع\x20سرویس:</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20id=\x22','[AccupdatorManager]\x20Opening\x20subscriber\x20details\x20for:','expiresAt','createAccupdatorSection','year','hide','[AccupdatorManager]\x20Subscriber\x20details\x20menu\x20created','سرور\x20اول','cookie-status-danger','text','cookie-status-warning','fetchSubscribers','2025-12-01T10:00:00Z','_persianToGregorian','[AccupdatorManager]\x20Accupdator\x20section\x20already\x20exists,\x20skipping\x20creation','[AccupdatorManager]\x20Test\x20cookie\x20load\x20succeeded\x20for','CREDENTIALS_SECTION','_renderSubscribersList','newUserBtn','اردیبهشت','.admin-proxy-ping','accupdatorCookieStatusCard','_accountCredentials','[AccupdatorAPI]\x20Deleting\x20cookies...','includes','Bearer\x20','[AccupdatorManager]\x20Subscriber\x20details\x20opened','getUpdateButtonId','_escapeHTML','sendMessage','Proxy\x20host\x20missing','نامشخص','.admin-proxy-item[data-index]','[AccupdatorManager]\x20Error\x20deleting\x20cookies:','description','_initializeProxyState','[AccupdatorManager]\x20Error\x20selecting\x20proxy:','SUBSCRIBER_DELETE_BTN','token','DELETE','subscribersBackBtn','خطا\x20در\x20آپدیت\x20کوکی\x20های\x20','CRED_PASSWORD','toString'];a0_0x3bb2=function(){return _0x77029f;};return a0_0x3bb2();}(function(_0x53a7c8,_0x3c9aac){const _0x20c7af=a0_0x3190,_0x297b15=_0x53a7c8();while(!![]){try{const _0xe039bc=-parseInt(_0x20c7af(0x266))/0x1*(-parseInt(_0x20c7af(0x21b))/0x2)+-parseInt(_0x20c7af(0x23d))/0x3*(-parseInt(_0x20c7af(0x134))/0x4)+-parseInt(_0x20c7af(0x19a))/0x5*(-parseInt(_0x20c7af(0x1b1))/0x6)+-parseInt(_0x20c7af(0x12c))/0x7*(parseInt(_0x20c7af(0x113))/0x8)+-parseInt(_0x20c7af(0xef))/0x9+-parseInt(_0x20c7af(0x2cc))/0xa*(-parseInt(_0x20c7af(0x2a6))/0xb)+-parseInt(_0x20c7af(0x304))/0xc*(parseInt(_0x20c7af(0x222))/0xd);if(_0xe039bc===_0x3c9aac)break;else _0x297b15['push'](_0x297b15['shift']());}catch(_0x15b361){_0x297b15['push'](_0x297b15['shift']());}}}(a0_0x3bb2,0xb0d40));const AccupdatorAPI={async '_request'(_0x1436ad,_0x58fd38,_0x350690=null){const _0x29a432=a0_0x3190;globalThis['__GPTYAR_DEV_LOG__']?.(_0x29a432(0x269)+_0x58fd38+_0x29a432(0x1b3)+_0x1436ad);const _0x4da19f={'method':_0x58fd38,'headers':{'Content-Type':_0x29a432(0xdb)}};PopupState[_0x29a432(0x1fa)]&&(_0x4da19f[_0x29a432(0x15a)][_0x29a432(0x2d5)]=_0x29a432(0x1ed)+PopupState[_0x29a432(0x1fa)]);_0x350690&&_0x58fd38!==_0x29a432(0x1ac)&&(_0x4da19f[_0x29a432(0x181)]=JSON[_0x29a432(0x218)](_0x350690));const _0x557fa9=await fetch(_0x1436ad,_0x4da19f);globalThis[_0x29a432(0x15d)]?.(_0x29a432(0x245)+_0x557fa9['status']);if(!_0x557fa9['ok']){const _0x2c4708=await _0x557fa9[_0x29a432(0x1dd)]();throw new Error('API\x20request\x20failed\x20('+_0x557fa9[_0x29a432(0x2ba)]+_0x29a432(0x161)+_0x2c4708);}const _0x1da90a=await _0x557fa9[_0x29a432(0x2c7)]();return globalThis['__GPTYAR_DEV_LOG__']?.(_0x29a432(0x115),_0x1da90a),_0x1da90a;},async 'fetchAccountInfo'(_0x477ab9){const _0x10782c=a0_0x3190;globalThis['__GPTYAR_DEV_LOG__']?.('[AccupdatorAPI]\x20Fetching\x20account\x20info...');const _0x4785f4=CONFIG[_0x10782c(0x30a)]+'/accupdator/validate',_0x56bb4a={'token':_0x477ab9,'version':CONFIG[_0x10782c(0x18d)]},_0x1553ba=await this['_request'](_0x4785f4,'POST',_0x56bb4a);return PopupState[_0x10782c(0x29b)]=_0x1553ba,globalThis[_0x10782c(0x15d)]?.(_0x10782c(0x24f),_0x1553ba),_0x1553ba;},async 'fetchCookiesStatus'(_0x36ac34){const _0x1a940c=a0_0x3190;globalThis[_0x1a940c(0x15d)]?.(_0x1a940c(0x2a2));const _0x40cd7a=CONFIG[_0x1a940c(0x30a)]+_0x1a940c(0x141);return await this['_request'](_0x40cd7a,'POST',{'token':_0x36ac34});},async 'updateCookies'(_0xedec10,_0x10a303,_0x243a54){const _0x3f4716=a0_0x3190;globalThis[_0x3f4716(0x15d)]?.('[AccupdatorAPI]\x20Updating\x20cookies\x20for\x20'+_0x10a303+'...');const _0x49f2cf=CONFIG[_0x3f4716(0x30a)]+_0x3f4716(0x21e),_0x4e842a={'token':_0xedec10,'cookie_type':_0x10a303,'cookies':_0x243a54};return await this[_0x3f4716(0x1a4)](_0x49f2cf,_0x3f4716(0x32f),_0x4e842a);},async 'deleteCookies'(_0x48991b){const _0x3294ce=a0_0x3190;globalThis[_0x3294ce(0x15d)]?.(_0x3294ce(0x1eb));const _0x4ac86f=CONFIG[_0x3294ce(0x30a)]+'/accupdator/delete-cookies',_0x589c2d={'token':_0x48991b};return await this[_0x3294ce(0x1a4)](_0x4ac86f,_0x3294ce(0x1fb),_0x589c2d);},async 'fetchSubscribers'(){const _0x2e5fe6=a0_0x3190;globalThis[_0x2e5fe6(0x15d)]?.(_0x2e5fe6(0x175));const _0x14a939=CONFIG[_0x2e5fe6(0x30a)]+_0x2e5fe6(0x2dd);return await this[_0x2e5fe6(0x1a4)](_0x14a939,_0x2e5fe6(0x1ac));},async 'fetchSubscriberDetails'(_0x103579,_0x1a1434){const _0x101643=a0_0x3190;globalThis[_0x101643(0x15d)]?.(_0x101643(0x138)+_0x1a1434+_0x101643(0x1a7));throw new Error(_0x101643(0x327));},async 'createUser'(_0x31dd39,_0x4a2a7f=null){const _0x128e47=a0_0x3190;globalThis[_0x128e47(0x15d)]?.('[AccupdatorAPI]\x20Creating\x20new\x20user:\x20'+_0x31dd39+_0x128e47(0x1a7));const _0x13a8ec=CONFIG[_0x128e47(0x30a)]+_0x128e47(0x305),_0x32c2f9={'name':_0x31dd39};return _0x4a2a7f&&(_0x32c2f9[_0x128e47(0x1d6)]=_0x4a2a7f['toISOString']()),await this[_0x128e47(0x1a4)](_0x13a8ec,_0x128e47(0x32f),_0x32c2f9);},async 'updateSubscriberExpiry'(_0x50d15b,_0x1473f0){const _0x14eec8=a0_0x3190;globalThis['__GPTYAR_DEV_LOG__']?.('[AccupdatorAPI]\x20Updating\x20expiry\x20for\x20subscription\x20'+_0x50d15b+_0x14eec8(0x1a7));const _0x4669e4=CONFIG['API_SERVER']+_0x14eec8(0x2b9),_0x3253e4={'subscriptionId':_0x50d15b,'expiresAt':_0x1473f0[_0x14eec8(0x187)]()};return await this[_0x14eec8(0x1a4)](_0x4669e4,_0x14eec8(0x253),_0x3253e4);},async 'deleteSubscriber'(_0x4ad1fe){const _0x6aa431=a0_0x3190;globalThis[_0x6aa431(0x15d)]?.(_0x6aa431(0x178)+_0x4ad1fe+_0x6aa431(0x1a7));const _0x3d8f53=CONFIG[_0x6aa431(0x30a)]+_0x6aa431(0x114),_0x5308a0={'subscriptionId':_0x4ad1fe};return await this[_0x6aa431(0x1a4)](_0x3d8f53,'DELETE',_0x5308a0);}},TOTPGenerator={'_base32ToBytes'(_0x52db0d){const _0x36f971=a0_0x3190,_0x3e6d20='ABCDEFGHIJKLMNOPQRSTUVWXYZ234567',_0x171f57=String(_0x52db0d||'')['toUpperCase']()['replace'](/[^A-Z2-7]/g,'');let _0x29324c='';for(const _0x90a3c6 of _0x171f57){const _0x278f0c=_0x3e6d20[_0x36f971(0x321)](_0x90a3c6);if(_0x278f0c===-0x1)continue;_0x29324c+=_0x278f0c['toString'](0x2)[_0x36f971(0x308)](0x5,'0');}const _0x4270df=[];for(let _0x3b9716=0x0;_0x3b9716+0x8<=_0x29324c[_0x36f971(0x26d)];_0x3b9716+=0x8){_0x4270df['push'](parseInt(_0x29324c[_0x36f971(0x130)](_0x3b9716,_0x3b9716+0x8),0x2));}return new Uint8Array(_0x4270df);},async 'generate'(_0x734e6b,{digits:digits=0x6,period:period=0x1e,timestamp:timestamp=Date[a0_0x4d3c49(0x287)]()}={}){const _0x4da791=a0_0x4d3c49,_0x384445=this[_0x4da791(0x324)](_0x734e6b);if(_0x384445[_0x4da791(0x26d)]===0x0)throw new Error('Invalid\x20MFA\x20secret');const _0xca14e0=Math['floor'](Math[_0x4da791(0x11f)](timestamp/0x3e8)/period),_0x3d1e1f=new ArrayBuffer(0x8),_0x50dd20=new DataView(_0x3d1e1f);_0x50dd20['setUint32'](0x0,Math['floor'](_0xca14e0/0x2**0x20),![]),_0x50dd20[_0x4da791(0x18a)](0x4,_0xca14e0>>>0x0,![]);const _0x667a0a=await crypto[_0x4da791(0x19b)][_0x4da791(0x16f)](_0x4da791(0x2ed),_0x384445,{'name':_0x4da791(0x27e),'hash':'SHA-1'},![],[_0x4da791(0x281)]),_0x280d71=new Uint8Array(await crypto[_0x4da791(0x19b)][_0x4da791(0x281)](_0x4da791(0x27e),_0x667a0a,_0x3d1e1f)),_0x35808b=_0x280d71[_0x280d71[_0x4da791(0x26d)]-0x1]&0xf,_0x4ba7df=(_0x280d71[_0x35808b]&0x7f)<<0x18|(_0x280d71[_0x35808b+0x1]&0xff)<<0x10|(_0x280d71[_0x35808b+0x2]&0xff)<<0x8|_0x280d71[_0x35808b+0x3]&0xff,_0x829a9f=(_0x4ba7df%0xa**digits)['toString']()[_0x4da791(0x308)](digits,'0');return _0x829a9f;},'remainingSeconds'(_0x103122=0x1e,_0x4a4a5e=Date[a0_0x4d3c49(0x287)]()){const _0x54e7cf=a0_0x4d3c49,_0xad28b4=Math[_0x54e7cf(0x11f)](_0x4a4a5e/0x3e8);return _0x103122-_0xad28b4%_0x103122;}},AccupdatorManager={'CSS_CLASSES':{'LOADING':a0_0x4d3c49(0x136),'SUCCESS':'success','ERROR':'error','HIDE':a0_0x4d3c49(0x1d9)},'ELEMENT_IDS':{'SECTION':'accupdator-section','PANEL':a0_0x4d3c49(0x1a9),'ACCOUNT_INFO':a0_0x4d3c49(0x302),'AGENT_INFO':a0_0x4d3c49(0xf6),'CREDENTIALS_SECTION':a0_0x4d3c49(0x32d),'CRED_EMAIL':a0_0x4d3c49(0x285),'CRED_EMAIL_COPY':a0_0x4d3c49(0x2e9),'CRED_PASSWORD':a0_0x4d3c49(0x24d),'CRED_PASSWORD_COPY':'accupdatorCredPasswordCopy','CRED_MFA_CODE':a0_0x4d3c49(0x202),'CRED_MFA_TIMER':'accupdatorCredMfaTimer','CRED_MFA_COPY':a0_0x4d3c49(0x264),'DELETE_COOKIES_BTN':a0_0x4d3c49(0x1ce),'TEST_LOAD_COOKIE_BTN':a0_0x4d3c49(0x27d),'COOKIE_STATUS_CARD':a0_0x4d3c49(0x1e9),'COOKIE_STATUS_VALUE':a0_0x4d3c49(0x10e),'COOKIE_STATUS_REMAINING':a0_0x4d3c49(0x162),'LOGOUT_BTN':a0_0x4d3c49(0x14f),'MANAGE_SUBS_BTN':a0_0x4d3c49(0x153),'ACTIVE_SUBS_COUNT':a0_0x4d3c49(0x22b),'TOTAL_SUBS_COUNT':a0_0x4d3c49(0x24e),'SUBS_SECTION':a0_0x4d3c49(0x173),'SUBS_MENU':a0_0x4d3c49(0x33b),'SUBS_MENU_BACK_BTN':a0_0x4d3c49(0x1fc),'SUBS_SEARCH_INPUT':'subscribersSearchInput','SUBS_LIST':a0_0x4d3c49(0x1cd),'SUBSCRIBER_DETAILS_MENU':a0_0x4d3c49(0x244),'SUBSCRIBER_DETAILS_BACK_BTN':a0_0x4d3c49(0x12d),'SUBSCRIBER_DETAILS_NAME':a0_0x4d3c49(0x2af),'SUBSCRIBER_DETAILS_TOKEN':'subscriberDetailsToken','SUBSCRIBER_DETAILS_EXPIRY':'subscriberDetailsExpiry','SUBSCRIBER_COPY_TOKEN_BTN':a0_0x4d3c49(0x292),'SUBSCRIBER_CALENDAR':a0_0x4d3c49(0x28b),'SUBSCRIBER_APPLY_BTN':a0_0x4d3c49(0x2da),'SUBSCRIBER_DELETE_BTN':a0_0x4d3c49(0x10c),'NEW_USER_BTN':a0_0x4d3c49(0x1e6),'NEW_USER_MENU':a0_0x4d3c49(0x2cb),'NEW_USER_BACK_BTN':'newUserBackBtn','NEW_USER_NAME_INPUT':a0_0x4d3c49(0x257),'NEW_USER_EXPIRY':a0_0x4d3c49(0x1b4),'NEW_USER_CALENDAR':a0_0x4d3c49(0x11a),'NEW_USER_CREATE_BTN':a0_0x4d3c49(0x2ad),'PROXY_SECTION':a0_0x4d3c49(0x146),'PROXY_TOGGLE':'adminProxyToggle','PROXY_LIST_CONTAINER':'adminProxyListContainer','PROXY_LIST':'adminProxyList','PROXY_REFRESH_BTN':a0_0x4d3c49(0x13f)},'_subscribersList':[],'_filteredSubscribersList':[],'_selectedSubscriber':null,'_selectedNewDate':null,'_accountCredentials':null,'_mfaCurrentCode':'','_mfaTimerHandle':null,'_proxyEnabled':![],'_adminProxies':[],'_selectedAdminProxyIndex':-0x1,'_calendarState':{'year':null,'month':null},async 'extractCookies'(_0x294201){const _0x53d668=a0_0x4d3c49;globalThis['__GPTYAR_DEV_LOG__']?.(_0x53d668(0x14c)+_0x294201);try{const _0x59f9da=this[_0x53d668(0x31c)](_0x294201);globalThis[_0x53d668(0x15d)]?.('[AccupdatorManager]\x20Target\x20domains:\x20'+_0x59f9da[_0x53d668(0x228)](',\x20'));const _0x5169f9=await chrome['tabs'][_0x53d668(0x163)]({'active':!![],'currentWindow':!![]});if(!_0x5169f9||_0x5169f9[_0x53d668(0x26d)]===0x0||!_0x5169f9[0x0])throw new Error('No\x20active\x20tab\x20found');globalThis['__GPTYAR_DEV_LOG__']?.(_0x53d668(0x2c3)+_0x5169f9[0x0][_0x53d668(0xdd)]);const _0x4d0464=new Map();for(const _0x5155d6 of _0x59f9da){const _0x4cdc21=await chrome[_0x53d668(0x33c)][_0x53d668(0x1b0)]({'domain':_0x5155d6});for(const _0x23fab3 of _0x4cdc21||[]){_0x4d0464[_0x53d668(0x330)](_0x23fab3[_0x53d668(0x174)]+'|'+_0x23fab3[_0x53d668(0x28c)]+'|'+_0x23fab3['name'],_0x23fab3);}}const _0x2a92b1=Array[_0x53d668(0x2c4)](_0x4d0464['values']());if(_0x2a92b1[_0x53d668(0x26d)]===0x0)throw new Error(_0x53d668(0x2de)+_0x59f9da['join'](',\x20'));const _0x180123=this[_0x53d668(0x195)](_0x2a92b1);return globalThis[_0x53d668(0x15d)]?.(_0x53d668(0x2d7)+_0x2a92b1[_0x53d668(0x26d)]+_0x53d668(0x12b)+_0x59f9da[_0x53d668(0x228)](',\x20')),{'success':!![],'cookies':_0x180123,'domain':_0x59f9da[0x0]};}catch(_0x6190c2){return globalThis[_0x53d668(0x15d)]?.(_0x53d668(0x2be),_0x6190c2),{'success':![],'error':_0x6190c2[_0x53d668(0xfe)]};}},'_getCookieDomains'(_0x5ce6b1){const _0x2e7487=a0_0x4d3c49,_0x472544=_0x5ce6b1?.[_0x2e7487(0x31e)](),_0x3811bb={'gpt':[_0x2e7487(0x224),_0x2e7487(0x184)],'grok':[_0x2e7487(0x2d4)],'claude':['claude.ai'],'midjourney':[_0x2e7487(0xe5),_0x2e7487(0xe6)]};return _0x3811bb[_0x472544]||[AGENT_ASSETS[_0x2e7487(0x1c0)](_0x5ce6b1)];},'_formatCookiesForAPI'(_0x110986){const _0x33a948=a0_0x4d3c49;return _0x110986[_0x33a948(0x143)](_0xfeb7ca=>({'name':_0xfeb7ca[_0x33a948(0x2fb)],'value':_0xfeb7ca[_0x33a948(0x29c)],'domain':_0xfeb7ca['domain'],'path':_0xfeb7ca[_0x33a948(0x28c)],'expirationDate':_0xfeb7ca['expirationDate']||0x0}));},async 'updateCookies'(_0x116a19){const _0x26caae=a0_0x4d3c49;globalThis['__GPTYAR_DEV_LOG__']?.('[AccupdatorManager]\x20Updating\x20cookies\x20via\x20API\x20for:\x20'+_0x116a19);try{this[_0x26caae(0x237)](),globalThis['__GPTYAR_DEV_LOG__']?.(_0x26caae(0x2f6));const _0xfc565c=await this[_0x26caae(0x13e)](_0x116a19);if(!_0xfc565c[_0x26caae(0x148)])throw new Error(_0xfc565c['error']);globalThis['__GPTYAR_DEV_LOG__']?.(_0x26caae(0x2ec));const _0x2e189e=CONFIG[_0x26caae(0x30a)]+'/accupdator/update-cookies',_0x14ebbb={'token':PopupState[_0x26caae(0x1fa)],'cookie_type':_0x116a19,'cookies':_0xfc565c[_0x26caae(0x33c)]},_0x4e9c4d=await this['_makeAPIRequest'](_0x2e189e,_0x26caae(0x32f),_0x14ebbb);if(_0x4e9c4d[_0x26caae(0xfe)])return globalThis[_0x26caae(0x15d)]?.('[AccupdatorManager]\x20Cookies\x20updated\x20successfully:',_0x4e9c4d['message']),{'success':!![],'message':_0x4e9c4d[_0x26caae(0xfe)]};else throw new Error(_0x26caae(0x30d));}catch(_0x49caec){return globalThis['__GPTYAR_DEV_LOG__']?.(_0x26caae(0x1c9),_0x49caec),{'success':![],'error':_0x49caec['message']};}},async 'deleteCookies'(){const _0x318ca4=a0_0x4d3c49;globalThis['__GPTYAR_DEV_LOG__']?.(_0x318ca4(0x168));try{this[_0x318ca4(0x237)](),globalThis[_0x318ca4(0x15d)]?.(_0x318ca4(0x1be));const _0xdbc327=CONFIG[_0x318ca4(0x30a)]+_0x318ca4(0x2c0),_0xd23ed7={'token':PopupState[_0x318ca4(0x1fa)]},_0x5cb100=await this[_0x318ca4(0x26f)](_0xdbc327,_0x318ca4(0x1fb),_0xd23ed7);if(_0x5cb100[_0x318ca4(0xfe)])return globalThis[_0x318ca4(0x15d)]?.(_0x318ca4(0x189),_0x5cb100[_0x318ca4(0xfe)]),{'success':!![],'message':_0x5cb100['message']};else throw new Error('Invalid\x20API\x20response:\x20missing\x20message');}catch(_0x41b0de){return globalThis[_0x318ca4(0x15d)]?.('[AccupdatorManager]\x20Cookie\x20deletion\x20error:',_0x41b0de),{'success':![],'error':_0x41b0de['message']};}},'_verifyAccupdatorAuth'(){const _0x3b332f=a0_0x4d3c49;if(!PopupState['token']||!PopupState['isAccupdator'])throw new Error(_0x3b332f(0x216));},async '_makeAPIRequest'(_0x44ecb1,_0x4c4abb,_0x6152ea){const _0x34eaf4=a0_0x4d3c49;globalThis['__GPTYAR_DEV_LOG__']?.(_0x34eaf4(0x1bf)+_0x4c4abb+_0x34eaf4(0x1b3)+_0x44ecb1);const _0x53cc2f=await fetch(_0x44ecb1,{'method':_0x4c4abb,'headers':{'Content-Type':_0x34eaf4(0xdb),'Authorization':_0x34eaf4(0x1ed)+PopupState[_0x34eaf4(0x1fa)]},'body':JSON[_0x34eaf4(0x218)](_0x6152ea)});globalThis[_0x34eaf4(0x15d)]?.(_0x34eaf4(0x10b)+_0x53cc2f[_0x34eaf4(0x2ba)]);if(!_0x53cc2f['ok'])throw new Error(_0x34eaf4(0x291)+_0x53cc2f[_0x34eaf4(0x2ba)]);const _0x516c13=await _0x53cc2f[_0x34eaf4(0x2c7)]();return globalThis['__GPTYAR_DEV_LOG__']?.(_0x34eaf4(0x250),_0x516c13),_0x516c13;},'showAccupdatorUI'(){const _0x5842c7=a0_0x4d3c49;globalThis['__GPTYAR_DEV_LOG__']?.('[AccupdatorManager]\x20Showing\x20Accupdator\x20UI...');try{let _0x4aa295=DOMManager[_0x5842c7(0x20c)](this[_0x5842c7(0x158)][_0x5842c7(0x1b6)]);if(!_0x4aa295){globalThis[_0x5842c7(0x15d)]?.(_0x5842c7(0x192)),this[_0x5842c7(0x1d7)](),_0x4aa295=DOMManager[_0x5842c7(0x20c)](this[_0x5842c7(0x158)][_0x5842c7(0x1b6)]);if(!_0x4aa295){globalThis[_0x5842c7(0x15d)]?.(_0x5842c7(0x23b)),NotificationManager[_0x5842c7(0x2e8)](_0x5842c7(0x13b));return;}}this[_0x5842c7(0x133)](),this[_0x5842c7(0x149)](),this[_0x5842c7(0x1f7)](),this[_0x5842c7(0x105)](),UIManager[_0x5842c7(0x201)](UIManager[_0x5842c7(0x2f0)]['accupdator'],![]),globalThis[_0x5842c7(0x15d)]?.('[AccupdatorManager]\x20Accupdator\x20UI\x20shown\x20successfully');}catch(_0x3a4107){globalThis['__GPTYAR_DEV_LOG__']?.('[AccupdatorManager]\x20Error\x20showing\x20Accupdator\x20UI:',_0x3a4107),NotificationManager[_0x5842c7(0x2e8)](_0x5842c7(0x1ad));}},'_updateAccountInfo'(){const _0x470452=a0_0x4d3c49;if(PopupState[_0x470452(0x29b)]){const _0x181c21=DOMManager[_0x470452(0x20c)](this[_0x470452(0x158)][_0x470452(0x180)]);if(_0x181c21){const _0x24dd0e=PopupState['accupdatorData'][_0x470452(0x171)]?.[_0x470452(0x2fb)]||'نامشخص';_0x181c21[_0x470452(0x25e)]=_0x24dd0e;}const _0x328118=DOMManager[_0x470452(0x20c)](this[_0x470452(0x158)][_0x470452(0x129)]);if(_0x328118){const _0x258bda=PopupState[_0x470452(0x29b)]['agent']?.[_0x470452(0x32e)]||'نامشخص';_0x328118[_0x470452(0x25e)]=_0x258bda;}this[_0x470452(0x1ea)]=this[_0x470452(0xe1)](PopupState[_0x470452(0x29b)][_0x470452(0x171)]?.[_0x470452(0x1f6)]),this[_0x470452(0x2ff)]();}},'_parseAccountCredentials'(_0x44c1c5){const _0x1e7303=a0_0x4d3c49;if(!_0x44c1c5||typeof _0x44c1c5!=='string')return null;const _0x1e149d=_0x44c1c5[_0x1e7303(0x13a)](/email:([\s\S]*?),password:([\s\S]*?),MFA:([\s\S]*)$/i);if(!_0x1e149d)return globalThis['__GPTYAR_DEV_LOG__']?.(_0x1e7303(0x2d2)),null;const [,_0x281d0f,_0x57a7e1,_0x2b124d]=_0x1e149d;if(!_0x281d0f['trim']()||!_0x57a7e1[_0x1e7303(0xfd)]()||!_0x2b124d[_0x1e7303(0xfd)]())return null;return{'email':_0x281d0f['trim'](),'password':_0x57a7e1[_0x1e7303(0xfd)](),'mfaSecret':_0x2b124d['trim']()};},'_renderAccountCredentials'(){const _0x57040c=a0_0x4d3c49,_0x16fbe7=DOMManager[_0x57040c(0x20c)](this[_0x57040c(0x158)][_0x57040c(0x1e4)]);if(!_0x16fbe7)return;if(!this[_0x57040c(0x1ea)]){_0x16fbe7[_0x57040c(0x11d)]['add'](this[_0x57040c(0x16b)][_0x57040c(0x11c)]),this['_stopMfaLoop']();return;}const _0xd4756d=DOMManager['getElement'](this[_0x57040c(0x158)][_0x57040c(0x1b7)]),_0x5d58f0=DOMManager[_0x57040c(0x20c)](this[_0x57040c(0x158)][_0x57040c(0x1fe)]);_0xd4756d&&(_0xd4756d['textContent']=this[_0x57040c(0x1ea)][_0x57040c(0x183)],_0xd4756d['title']=this[_0x57040c(0x1ea)]['email']),_0x5d58f0&&(_0x5d58f0[_0x57040c(0x25e)]=this['_accountCredentials'][_0x57040c(0x17f)],_0x5d58f0[_0x57040c(0x32e)]=this[_0x57040c(0x1ea)]['password']),_0x16fbe7['classList']['remove'](this[_0x57040c(0x16b)][_0x57040c(0x11c)]),this['_startMfaLoop']();},'_startMfaLoop'(){const _0x1115cd=a0_0x4d3c49;this[_0x1115cd(0x2ab)]();if(!this[_0x1115cd(0x1ea)]?.['mfaSecret'])return;const _0x1ee829=async()=>{const _0x3456cd=_0x1115cd,_0x4bf036=TOTPGenerator[_0x3456cd(0x123)](),_0xf37514=DOMManager[_0x3456cd(0x20c)](this['ELEMENT_IDS']['CRED_MFA_TIMER']);_0xf37514&&(_0xf37514[_0x3456cd(0x25e)]=String(_0x4bf036),_0xf37514[_0x3456cd(0x11d)][_0x3456cd(0x2ea)](_0x3456cd(0x28a),_0x4bf036<=0x5));if(_0x4bf036===0x1e||!this[_0x3456cd(0xe4)]){try{this[_0x3456cd(0xe4)]=await TOTPGenerator[_0x3456cd(0x2ef)](this['_accountCredentials'][_0x3456cd(0x1c4)]);}catch(_0x5cf7f5){globalThis[_0x3456cd(0x15d)]?.('[AccupdatorManager]\x20Failed\x20to\x20generate\x20MFA\x20code:',_0x5cf7f5),this[_0x3456cd(0xe4)]='';}const _0x29058b=DOMManager[_0x3456cd(0x20c)](this[_0x3456cd(0x158)]['CRED_MFA_CODE']);_0x29058b&&(_0x29058b[_0x3456cd(0x25e)]=this[_0x3456cd(0xe4)]||_0x3456cd(0x144));}};_0x1ee829(),this[_0x1115cd(0x18e)]=setInterval(_0x1ee829,0x3e8);},'_stopMfaLoop'(){const _0x47f280=a0_0x4d3c49;this[_0x47f280(0x18e)]&&(clearInterval(this[_0x47f280(0x18e)]),this[_0x47f280(0x18e)]=null),this[_0x47f280(0xe4)]='';},async '_handleCopyCredential'(_0x83536,_0x510028,_0x454528){const _0x4d5a7e=a0_0x4d3c49,_0x4a95b1=DOMManager['getElement'](_0x83536),_0x39c461=_0x4a95b1?.[_0x4d5a7e(0x25e)]?.[_0x4d5a7e(0xfd)]();if(!_0x39c461)return;try{await navigator['clipboard']['writeText'](_0x39c461),NotificationManager[_0x4d5a7e(0x29a)](_0x454528);const _0x51e97b=DOMManager[_0x4d5a7e(0x20c)](_0x510028);_0x51e97b&&(_0x51e97b['classList'][_0x4d5a7e(0x199)](_0x4d5a7e(0x311)),setTimeout(()=>_0x51e97b['classList'][_0x4d5a7e(0x21c)](_0x4d5a7e(0x311)),0x5dc));}catch(_0x13911d){globalThis[_0x4d5a7e(0x15d)]?.(_0x4d5a7e(0x2e6),_0x13911d),NotificationManager[_0x4d5a7e(0x2e8)](_0x4d5a7e(0xdf));}},'_updateSubscriptionStats'(){const _0x3f0455=a0_0x4d3c49,_0xbb0af=PopupState['accupdatorData']?.[_0x3f0455(0x171)],_0x437de9=DOMManager[_0x3f0455(0x20c)](this['ELEMENT_IDS'][_0x3f0455(0x10f)]),_0x4542b9=DOMManager[_0x3f0455(0x20c)](this[_0x3f0455(0x158)][_0x3f0455(0x159)]);_0x437de9&&(_0x437de9['textContent']=_0xbb0af?.[_0x3f0455(0x1ba)]?.[_0x3f0455(0x1ff)]()||'0'),_0x4542b9&&(_0x4542b9['textContent']=_0xbb0af?.[_0x3f0455(0x2c8)]?.[_0x3f0455(0x1ff)]()||'0'),globalThis[_0x3f0455(0x15d)]?.(_0x3f0455(0x25a));},async 'refreshAccountInfo'(){const _0x3397c7=a0_0x4d3c49;globalThis[_0x3397c7(0x15d)]?.('[AccupdatorManager]\x20Refreshing\x20account\x20info...');try{await AccupdatorAPI[_0x3397c7(0x30f)](PopupState[_0x3397c7(0x1fa)]),this['_updateAccountInfo'](),this[_0x3397c7(0x149)](),globalThis[_0x3397c7(0x15d)]?.(_0x3397c7(0x126));}catch(_0x4b0661){globalThis[_0x3397c7(0x15d)]?.(_0x3397c7(0x293),_0x4b0661),NotificationManager[_0x3397c7(0x2e8)]('خطا\x20در\x20بروزرسانی\x20اطلاعات\x20حساب');}},'createAccupdatorSection'(){const _0x55059d=a0_0x4d3c49;globalThis['__GPTYAR_DEV_LOG__']?.(_0x55059d(0x12e));try{const _0x470980=document[_0x55059d(0x256)](this[_0x55059d(0x158)][_0x55059d(0x1b6)]);if(_0x470980){globalThis[_0x55059d(0x15d)]?.(_0x55059d(0x1e2));return;}const _0x4105ec=document[_0x55059d(0x30b)](_0x55059d(0x2d9));if(!_0x4105ec){globalThis['__GPTYAR_DEV_LOG__']?.('[AccupdatorManager]\x20Card\x20container\x20not\x20found');throw new Error(_0x55059d(0x2a8));}globalThis['__GPTYAR_DEV_LOG__']?.('[AccupdatorManager]\x20Card\x20container\x20found,\x20creating\x20HTML...');const _0x4b808a=this[_0x55059d(0x27b)]();_0x4105ec[_0x55059d(0x2fa)]('beforeend',_0x4b808a),globalThis[_0x55059d(0x15d)]?.('[AccupdatorManager]\x20Accupdator\x20section\x20HTML\x20inserted');const _0x3f654c=document[_0x55059d(0x256)](this[_0x55059d(0x158)]['SECTION']);if(!_0x3f654c)throw new Error(_0x55059d(0x104));this[_0x55059d(0x211)](),globalThis['__GPTYAR_DEV_LOG__']?.(_0x55059d(0x2cf));}catch(_0x418e4d){globalThis[_0x55059d(0x15d)]?.(_0x55059d(0x289),_0x418e4d);throw _0x418e4d;}},'_generateSectionHTML'(){const _0x3a30a2=a0_0x4d3c49,_0x106876=this[_0x3a30a2(0x1bc)]();globalThis['__GPTYAR_DEV_LOG__']?.(_0x3a30a2(0xe7)+_0x106876);const _0x465c96=_0x106876?'<button\x20id=\x22'+AGENT_ASSETS[_0x3a30a2(0x1ef)](_0x106876)+_0x3a30a2(0x107):_0x3a30a2(0x221);return _0x3a30a2(0x1d2)+this[_0x3a30a2(0x158)][_0x3a30a2(0x1b6)]+_0x3a30a2(0xf4)+this[_0x3a30a2(0x16b)]['HIDE']+_0x3a30a2(0xf1)+this[_0x3a30a2(0x158)][_0x3a30a2(0x288)]+'\x22\x20class=\x22panel\x20accupdator-panel\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<!--\x20Header\x20Section\x20-->\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22accupdator-header\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<a\x20href=\x22https://gptyar.com\x22\x20target=\x22_blank\x22\x20rel=\x22noopener\x20noreferrer\x22\x20title=\x22باز\x20کردن\x20gptyar.com\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<img\x20src=\x22icons/icon.png\x22\x20alt=\x22Extension\x20Logo\x22\x20class=\x22logo-small\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</a>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<h2\x20class=\x22accupdator-title\x22>GPTYAR\x20ACCOUNT\x20HUB\x20</h2>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20id=\x22'+this[_0x3a30a2(0x158)][_0x3a30a2(0x205)]+_0x3a30a2(0x164)+this[_0x3a30a2(0x158)][_0x3a30a2(0x180)]+_0x3a30a2(0x1d4)+this[_0x3a30a2(0x158)][_0x3a30a2(0x129)]+_0x3a30a2(0x1cb)+this['ELEMENT_IDS'][_0x3a30a2(0x1e4)]+_0x3a30a2(0x2fd)+this[_0x3a30a2(0x16b)][_0x3a30a2(0x11c)]+'\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22section-card-header\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<svg\x20width=\x2218\x22\x20height=\x2218\x22\x20viewBox=\x220\x200\x2024\x2024\x22\x20fill=\x22none\x22\x20stroke=\x22currentColor\x22\x20stroke-width=\x222\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<rect\x20x=\x223\x22\x20y=\x2211\x22\x20width=\x2218\x22\x20height=\x2211\x22\x20rx=\x222\x22\x20ry=\x222\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<path\x20d=\x22M7\x2011V7a5\x205\x200\x200\x201\x2010\x200v4\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</svg>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span>اطلاعات\x20ورود</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22section-card-content\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22detail-row\x20cred-row\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22detail-label\x22>ایمیل:</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22detail-value-with-action\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20id=\x22'+this[_0x3a30a2(0x158)][_0x3a30a2(0x1b7)]+_0x3a30a2(0x100)+this[_0x3a30a2(0x158)][_0x3a30a2(0x217)]+'\x22\x20class=\x22copy-token-btn\x22\x20type=\x22button\x22\x20title=\x22کپی\x20ایمیل\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<svg\x20width=\x2214\x22\x20height=\x2214\x22\x20viewBox=\x220\x200\x2024\x2024\x22\x20fill=\x22none\x22\x20stroke=\x22currentColor\x22\x20stroke-width=\x222\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<rect\x20x=\x229\x22\x20y=\x229\x22\x20width=\x2213\x22\x20height=\x2213\x22\x20rx=\x222\x22\x20ry=\x222\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<path\x20d=\x22M5\x2015H4a2\x202\x200\x200\x201-2-2V4a2\x202\x200\x200\x201\x202-2h9a2\x202\x200\x200\x201\x202\x202v1\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</svg>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22detail-row\x20cred-row\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22detail-label\x22>رمز\x20عبور:</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22detail-value-with-action\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20id=\x22'+this[_0x3a30a2(0x158)][_0x3a30a2(0x1fe)]+_0x3a30a2(0x100)+this['ELEMENT_IDS']['CRED_PASSWORD_COPY']+_0x3a30a2(0xf7)+this['ELEMENT_IDS'][_0x3a30a2(0x32c)]+'\x22\x20class=\x22detail-value\x20cred-token\x20cred-mfa-code\x22\x20dir=\x22ltr\x22>------</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20id=\x22'+this[_0x3a30a2(0x158)]['CRED_MFA_TIMER']+_0x3a30a2(0x286)+this['ELEMENT_IDS']['CRED_MFA_COPY']+_0x3a30a2(0x191)+this[_0x3a30a2(0x158)]['COOKIE_STATUS_CARD']+_0x3a30a2(0x240)+this[_0x3a30a2(0x158)][_0x3a30a2(0x2c2)]+_0x3a30a2(0x2b2)+this['ELEMENT_IDS'][_0x3a30a2(0x2c1)]+_0x3a30a2(0x1ab)+this[_0x3a30a2(0x158)][_0x3a30a2(0x1a0)]+_0x3a30a2(0x215)+_0x465c96+_0x3a30a2(0x2b5)+this[_0x3a30a2(0x158)][_0x3a30a2(0x21a)]+_0x3a30a2(0x252)+this[_0x3a30a2(0x158)][_0x3a30a2(0x111)]+_0x3a30a2(0x1d0)+this[_0x3a30a2(0x158)][_0x3a30a2(0x10f)]+_0x3a30a2(0x25d)+this[_0x3a30a2(0x158)][_0x3a30a2(0x159)]+'\x22>-</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22stat-label\x22>کل\x20اشتراک\x20ها</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20id=\x22'+this[_0x3a30a2(0x158)][_0x3a30a2(0x206)]+'\x22\x20class=\x22accupdator-btn\x20secondary-btn\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<svg\x20width=\x2216\x22\x20height=\x2216\x22\x20viewBox=\x220\x200\x2024\x2024\x22\x20fill=\x22none\x22\x20stroke=\x22currentColor\x22\x20stroke-width=\x222\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<path\x20d=\x22M12\x2020h9\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<path\x20d=\x22M16.5\x203.5a2.121\x202.121\x200\x200\x201\x203\x203L7\x2019l-4\x201\x201-4L16.5\x203.5z\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</svg>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20مدیریت\x20اشتراک\x20ها\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<!--\x20Proxy\x20Section\x20-->\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20id=\x22'+this[_0x3a30a2(0x158)][_0x3a30a2(0x20d)]+_0x3a30a2(0x135)+this['ELEMENT_IDS'][_0x3a30a2(0x13d)]+'\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22toggle-slider\x22></span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</label>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20id=\x22'+this[_0x3a30a2(0x158)][_0x3a30a2(0xf2)]+_0x3a30a2(0x267)+this[_0x3a30a2(0x158)][_0x3a30a2(0x258)]+'\x22\x20class=\x22admin-proxy-refresh-btn\x22\x20title=\x22به‌روزرسانی\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<svg\x20width=\x2216\x22\x20height=\x2216\x22\x20viewBox=\x220\x200\x2024\x2024\x22\x20fill=\x22none\x22\x20stroke=\x22currentColor\x22\x20stroke-width=\x222\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<path\x20d=\x22M21\x2012a9\x209\x200\x200\x200-9-9\x209.75\x209.75\x200\x200\x200-6.74\x202.74L3\x208\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<path\x20d=\x22M3\x203v5h5\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<path\x20d=\x22M3\x2012a9\x209\x200\x200\x200\x209\x209\x209.75\x209.75\x200\x200\x200\x206.74-2.74L21\x2016\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<path\x20d=\x22M16\x2021h5v-5\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</svg>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20id=\x22'+this[_0x3a30a2(0x158)][_0x3a30a2(0x331)]+_0x3a30a2(0x108);},'_getAssignedAgentType'(){const _0x1ef336=a0_0x4d3c49,_0x16a5cb=PopupState[_0x1ef336(0x29b)]?.[_0x1ef336(0x116)]?.[_0x1ef336(0x334)];if(!_0x16a5cb)return globalThis['__GPTYAR_DEV_LOG__']?.(_0x1ef336(0xf0)),null;return _0x16a5cb[_0x1ef336(0x31e)]();},'setupAccupdatorEventListeners'(){const _0x2f6b1e=a0_0x4d3c49;globalThis[_0x2f6b1e(0x15d)]?.(_0x2f6b1e(0x1aa));try{const _0x57dc13=this[_0x2f6b1e(0x1bc)]();_0x57dc13?this[_0x2f6b1e(0x118)](_0x57dc13):globalThis[_0x2f6b1e(0x15d)]?.(_0x2f6b1e(0x2cd)),this[_0x2f6b1e(0x2ee)](this['ELEMENT_IDS'][_0x2f6b1e(0x1a0)],async()=>await this[_0x2f6b1e(0x194)](),_0x2f6b1e(0x11b)),this[_0x2f6b1e(0x2ee)](this['ELEMENT_IDS'][_0x2f6b1e(0x21a)],async()=>await this['handleCookieDelete'](),'Delete\x20cookies'),this[_0x2f6b1e(0x2ee)](this['ELEMENT_IDS']['LOGOUT_BTN'],()=>AuthManager[_0x2f6b1e(0x2a9)](),'Logout'),this[_0x2f6b1e(0x2ee)](this[_0x2f6b1e(0x158)][_0x2f6b1e(0x206)],()=>this[_0x2f6b1e(0x310)](),_0x2f6b1e(0x197)),this[_0x2f6b1e(0x2ee)](this['ELEMENT_IDS'][_0x2f6b1e(0x217)],()=>this[_0x2f6b1e(0xd9)](this[_0x2f6b1e(0x158)][_0x2f6b1e(0x1b7)],this['ELEMENT_IDS'][_0x2f6b1e(0x217)],_0x2f6b1e(0x15b)),_0x2f6b1e(0x2b0)),this[_0x2f6b1e(0x2ee)](this[_0x2f6b1e(0x158)]['CRED_PASSWORD_COPY'],()=>this[_0x2f6b1e(0xd9)](this[_0x2f6b1e(0x158)][_0x2f6b1e(0x1fe)],this['ELEMENT_IDS'][_0x2f6b1e(0x2bb)],'رمز\x20عبور\x20کپی\x20شد'),'Copy\x20password'),this[_0x2f6b1e(0x2ee)](this[_0x2f6b1e(0x158)][_0x2f6b1e(0xf8)],()=>this[_0x2f6b1e(0xd9)](this[_0x2f6b1e(0x158)][_0x2f6b1e(0x32c)],this[_0x2f6b1e(0x158)][_0x2f6b1e(0xf8)],_0x2f6b1e(0x182)),_0x2f6b1e(0x299)),this[_0x2f6b1e(0x271)](),globalThis[_0x2f6b1e(0x15d)]?.(_0x2f6b1e(0x2e7));}catch(_0x2bdec3){globalThis[_0x2f6b1e(0x15d)]?.(_0x2f6b1e(0x19f),_0x2bdec3);}},'_setupAgentUpdateButton'(_0x5f1069){const _0x2570a1=a0_0x4d3c49,_0xc2d778=AGENT_ASSETS[_0x2570a1(0x1ef)](_0x5f1069),_0xb74881=AGENT_ASSETS[_0x2570a1(0x23a)](_0x5f1069);this[_0x2570a1(0x2ee)](_0xc2d778,async()=>await this[_0x2570a1(0x2e4)](_0x5f1069),_0xb74881+_0x2570a1(0x1a3));},'_setupButton'(_0x132a1e,_0x38ec65,_0x5a6aa7){const _0x551e59=a0_0x4d3c49,_0x28197d=document[_0x551e59(0x256)](_0x132a1e);_0x28197d?(EventManager[_0x551e59(0x17b)](_0x28197d,'click',_0x38ec65),globalThis['__GPTYAR_DEV_LOG__']?.(_0x551e59(0xfc)+_0x5a6aa7+'\x20button\x20listener\x20added')):globalThis[_0x551e59(0x15d)]?.(_0x551e59(0xfc)+_0x5a6aa7+_0x551e59(0x172)+_0x132a1e+')');},async 'handleCookieUpdate'(_0x92a0ae){const _0x2c30e0=a0_0x4d3c49;globalThis[_0x2c30e0(0x15d)]?.(_0x2c30e0(0x27f)+_0x92a0ae);const _0x1454e8=document[_0x2c30e0(0x256)](AGENT_ASSETS[_0x2c30e0(0x1ef)](_0x92a0ae)),_0x3eb88d=AGENT_ASSETS['getServiceName'](_0x92a0ae);try{this[_0x2c30e0(0x176)](_0x1454e8,!![]);const _0x3f4817=await this[_0x2c30e0(0x12a)](_0x92a0ae);_0x3f4817['success']?(NotificationManager[_0x2c30e0(0x29a)](_0x2c30e0(0x203)+_0x3eb88d+_0x2c30e0(0x204)),globalThis[_0x2c30e0(0x15d)]?.(_0x2c30e0(0xfc)+_0x3eb88d+_0x2c30e0(0x2c5))):(NotificationManager[_0x2c30e0(0x2e8)]('خطا\x20در\x20آپدیت\x20کوکی\x20های\x20'+_0x3eb88d+':\x20'+_0x3f4817[_0x2c30e0(0x125)]),globalThis[_0x2c30e0(0x15d)]?.('[AccupdatorManager]\x20Error\x20updating\x20'+_0x3eb88d+_0x2c30e0(0x31a),_0x3f4817[_0x2c30e0(0x125)]));}catch(_0x1603ab){globalThis[_0x2c30e0(0x15d)]?.(_0x2c30e0(0x30e)+_0x92a0ae+':',_0x1603ab),NotificationManager[_0x2c30e0(0x2e8)](_0x2c30e0(0x1fd)+_0x3eb88d+':\x20'+_0x1603ab[_0x2c30e0(0xfe)]);}finally{this['_setButtonLoading'](_0x1454e8,![]);}},async 'handleTestLoadCookie'(){const _0x102d63=a0_0x4d3c49;globalThis[_0x102d63(0x15d)]?.(_0x102d63(0x272));const _0x5b44e0=DOMManager[_0x102d63(0x20c)](this[_0x102d63(0x158)]['TEST_LOAD_COOKIE_BTN']),_0x29674e=this['_getAssignedAgentType']();if(!_0x29674e||!PopupState[_0x102d63(0x1fa)]){NotificationManager[_0x102d63(0x2e8)]('اطلاعات\x20حساب\x20برای\x20بارگذاری\x20کوکی\x20در\x20دسترس\x20نیست');return;}try{this[_0x102d63(0x176)](_0x5b44e0,!![]);const _0x1ad478=await ProxyManager[_0x102d63(0xea)]();if(!_0x1ad478)throw new Error(_0x102d63(0x320));const _0x33087d=await new Promise((_0x54d317,_0xe89ac)=>{const _0x3b6d1f=_0x102d63;chrome[_0x3b6d1f(0x315)][_0x3b6d1f(0x1f1)]({'action':_0x3b6d1f(0x112),'token':PopupState['token']},_0x87f13d=>{const _0x2b1f72=_0x3b6d1f;if(chrome[_0x2b1f72(0x315)][_0x2b1f72(0x234)]){_0xe89ac(new Error(chrome[_0x2b1f72(0x315)][_0x2b1f72(0x234)][_0x2b1f72(0xfe)]));return;}_0x54d317(_0x87f13d);});});if(!_0x33087d?.['success'])throw new Error(_0x33087d?.['error']||_0x102d63(0xe0));this['_renderCookieStatus'](_0x33087d[_0x102d63(0x33c)]);const _0x5912eb=_0x102d63(0x20a)+AGENT_ASSETS[_0x102d63(0x1c0)](_0x29674e);try{chrome?.[_0x102d63(0x15f)]?.[_0x102d63(0x24b)]?chrome[_0x102d63(0x15f)]['create']({'url':_0x5912eb}):window['open'](_0x5912eb,'_blank');}catch(_0x4f2bc){globalThis[_0x102d63(0x15d)]?.(_0x102d63(0x117),_0x29674e,_0x4f2bc);throw new Error(_0x102d63(0x154));}NotificationManager[_0x102d63(0x29a)](_0x102d63(0x119)),globalThis[_0x102d63(0x15d)]?.(_0x102d63(0x1e3),_0x29674e);}catch(_0x3dd841){globalThis[_0x102d63(0x15d)]?.(_0x102d63(0x132),_0x3dd841),NotificationManager[_0x102d63(0x2e8)](_0x102d63(0x169)+_0x3dd841[_0x102d63(0xfe)]);}finally{this[_0x102d63(0x176)](_0x5b44e0,![]);}},async '_refreshCookieStatus'(){const _0xb44e49=a0_0x4d3c49;if(!PopupState[_0xb44e49(0x1fa)])return;try{const _0x3310c4=await AccupdatorAPI[_0xb44e49(0x280)](PopupState[_0xb44e49(0x1fa)]);Array['isArray'](_0x3310c4?.['cookies'])&&_0x3310c4['cookies'][_0xb44e49(0x26d)]>0x0?this[_0xb44e49(0x318)](_0x3310c4['cookies']):this[_0xb44e49(0x24c)]();}catch(_0x33fd80){globalThis['__GPTYAR_DEV_LOG__']?.(_0xb44e49(0x230),_0x33fd80),this[_0xb44e49(0x24c)]();}},'_hideCookieStatus'(){const _0x26af8c=a0_0x4d3c49,_0x11141e=DOMManager[_0x26af8c(0x20c)](this['ELEMENT_IDS']['COOKIE_STATUS_CARD']);_0x11141e&&_0x11141e[_0x26af8c(0x11d)]['add'](this[_0x26af8c(0x16b)]['HIDE']);},'_renderCookieStatus'(_0x92486d){const _0x5305ad=a0_0x4d3c49,_0x30515b=DOMManager['getElement'](this[_0x5305ad(0x158)][_0x5305ad(0x2f5)]),_0x3ef266=DOMManager[_0x5305ad(0x20c)](this[_0x5305ad(0x158)][_0x5305ad(0x2c2)]),_0x3853c6=DOMManager[_0x5305ad(0x20c)](this[_0x5305ad(0x158)][_0x5305ad(0x2c1)]);if(!_0x30515b)return;_0x30515b[_0x5305ad(0x11d)][_0x5305ad(0x21c)](this[_0x5305ad(0x16b)][_0x5305ad(0x11c)]),_0x30515b[_0x5305ad(0x11d)][_0x5305ad(0x21c)]('cookie-status-warning',_0x5305ad(0x1dc));_0x3ef266&&(_0x3ef266[_0x5305ad(0x25e)]=_0x5305ad(0x140));const _0x240664=Array['isArray'](_0x92486d)?_0x92486d[_0x5305ad(0x19c)](_0x514352=>_0x514352?.[_0x5305ad(0x2fb)]===_0x5305ad(0x2dc)):null;if(!_0x3853c6)return;if(!_0x240664?.[_0x5305ad(0x31b)]){_0x3853c6[_0x5305ad(0x25e)]=_0x5305ad(0x1f3);return;}const _0x85f98d=new Date(_0x240664[_0x5305ad(0x31b)]);if(Number['isNaN'](_0x85f98d[_0x5305ad(0x2e5)]())){_0x3853c6[_0x5305ad(0x25e)]='نامشخص';return;}const _0x41a996=_0x85f98d['getTime']()-Date['now'](),_0x309bb1=Math[_0x5305ad(0x339)](_0x41a996/(0x3e8*0x3c*0x3c*0x18));if(_0x309bb1<=0x0)_0x3853c6[_0x5305ad(0x25e)]=_0x5305ad(0x185),_0x30515b['classList'][_0x5305ad(0x199)](_0x5305ad(0x1dc));else{_0x3853c6[_0x5305ad(0x25e)]=_0x309bb1+_0x5305ad(0x16a);if(_0x309bb1<=0x3)_0x30515b[_0x5305ad(0x11d)][_0x5305ad(0x199)](_0x5305ad(0x1dc));else _0x309bb1<=0x7&&_0x30515b[_0x5305ad(0x11d)]['add'](_0x5305ad(0x1de));}},async 'handleCookieDelete'(){const _0x3d35dc=a0_0x4d3c49;globalThis['__GPTYAR_DEV_LOG__']?.('[AccupdatorManager]\x20Handling\x20cookie\x20delete...');const _0x314d90=document['getElementById'](this[_0x3d35dc(0x158)][_0x3d35dc(0x21a)]);try{this[_0x3d35dc(0x176)](_0x314d90,!![]);const _0x28dcea=await this[_0x3d35dc(0x1ce)]();_0x28dcea[_0x3d35dc(0x148)]?(NotificationManager[_0x3d35dc(0x29a)]('کوکی\x20ها\x20با\x20موفقیت\x20حذف\x20شدند'),globalThis[_0x3d35dc(0x15d)]?.(_0x3d35dc(0x1af))):(NotificationManager['showError']('خطا\x20در\x20حذف\x20کوکی\x20ها:\x20'+_0x28dcea[_0x3d35dc(0x125)]),globalThis['__GPTYAR_DEV_LOG__']?.(_0x3d35dc(0x1f5),_0x28dcea[_0x3d35dc(0x125)]));}catch(_0x3b2f38){globalThis[_0x3d35dc(0x15d)]?.(_0x3d35dc(0x156),_0x3b2f38),NotificationManager[_0x3d35dc(0x2e8)]('خطا\x20در\x20حذف\x20کوکی\x20ها:\x20'+_0x3b2f38['message']);}finally{this[_0x3d35dc(0x176)](_0x314d90,![]);}},'_setButtonLoading'(_0x4665fe,_0x24913f){const _0x354f1c=a0_0x4d3c49;if(!_0x4665fe)return;_0x4665fe['disabled']=_0x24913f,_0x24913f?_0x4665fe[_0x354f1c(0x11d)]['add'](this['CSS_CLASSES'][_0x354f1c(0x23e)]):_0x4665fe['classList'][_0x354f1c(0x21c)](this[_0x354f1c(0x16b)][_0x354f1c(0x23e)]);},async 'fetchSubscriptionsList'(){const _0x1b7517=a0_0x4d3c49;globalThis[_0x1b7517(0x15d)]?.(_0x1b7517(0x2d0));try{const _0x1f37f7={'subscriptions':[{'id':0x1,'userId':0x65,'status':_0x1b7517(0x325),'createdAt':_0x1b7517(0x1e0)},{'id':0x2,'userId':0x66,'status':'active','createdAt':_0x1b7517(0x296)},{'id':0x3,'userId':0x67,'status':_0x1b7517(0x124),'createdAt':'2025-12-03T12:00:00Z'},{'id':0x4,'userId':0x68,'status':_0x1b7517(0x325),'createdAt':_0x1b7517(0x212)},{'id':0x5,'userId':0x69,'status':_0x1b7517(0x282),'createdAt':_0x1b7517(0x29e)}],'total':0x2d};return await new Promise(_0x3a231e=>setTimeout(_0x3a231e,0x1f4)),globalThis[_0x1b7517(0x15d)]?.('[AccupdatorManager]\x20Subscriptions\x20list\x20fetched:',_0x1f37f7[_0x1b7517(0x131)][_0x1b7517(0x26d)],_0x1b7517(0x207)),_0x1f37f7;}catch(_0x30b64c){return globalThis['__GPTYAR_DEV_LOG__']?.(_0x1b7517(0x1ae),_0x30b64c),{'subscriptions':[],'total':0x0};}},'showSubscriptionsMenu'(){const _0x25cc03=a0_0x4d3c49;globalThis[_0x25cc03(0x15d)]?.('[AccupdatorManager]\x20Opening\x20subscriptions\x20management\x20menu...');try{let _0xe172af=DOMManager[_0x25cc03(0x20c)](this[_0x25cc03(0x158)][_0x25cc03(0x200)]);!_0xe172af&&(this['_createSubscribersMenu'](),_0xe172af=DOMManager[_0x25cc03(0x20c)](this[_0x25cc03(0x158)][_0x25cc03(0x200)]));const _0x14624a=DOMManager[_0x25cc03(0x20c)](this[_0x25cc03(0x158)][_0x25cc03(0x288)]);_0x14624a&&_0x14624a[_0x25cc03(0x11d)][_0x25cc03(0x199)](_0x25cc03(0x1d9));_0xe172af&&_0xe172af['classList'][_0x25cc03(0x199)](_0x25cc03(0x213));const _0x953a95=DOMManager['getElement'](this['ELEMENT_IDS'][_0x25cc03(0x2bd)]);_0x953a95&&(_0x953a95[_0x25cc03(0x28f)]=this['_generateSkeletonHTML']()),this[_0x25cc03(0x313)](),globalThis[_0x25cc03(0x15d)]?.(_0x25cc03(0x26a));}catch(_0x17da74){globalThis['__GPTYAR_DEV_LOG__']?.('[AccupdatorManager]\x20Error\x20showing\x20subscriptions\x20menu:',_0x17da74),NotificationManager['showError']('خطا\x20در\x20باز\x20کردن\x20منوی\x20اشتراک\x20ها');}},'_hideSubscribersMenu'(){const _0xbb5023=a0_0x4d3c49;globalThis[_0xbb5023(0x15d)]?.(_0xbb5023(0x14d));const _0x3f2af9=DOMManager[_0xbb5023(0x20c)](this[_0xbb5023(0x158)]['SUBS_MENU']),_0x3621d8=DOMManager['getElement'](this['ELEMENT_IDS'][_0xbb5023(0x288)]);_0x3f2af9&&_0x3f2af9['classList'][_0xbb5023(0x21c)](_0xbb5023(0x213));_0x3621d8&&_0x3621d8[_0xbb5023(0x11d)][_0xbb5023(0x21c)](_0xbb5023(0x1d9));const _0x5fe313=DOMManager[_0xbb5023(0x20c)](this[_0xbb5023(0x158)]['SUBS_SEARCH_INPUT']);_0x5fe313&&(_0x5fe313['value']='');},'_createSubscribersMenu'(){const _0x372ce2=a0_0x4d3c49;globalThis[_0x372ce2(0x15d)]?.('[AccupdatorManager]\x20Creating\x20subscribers\x20menu...');const _0x1b04ea=DOMManager[_0x372ce2(0x20c)](this[_0x372ce2(0x158)]['SECTION']);if(!_0x1b04ea){globalThis[_0x372ce2(0x15d)]?.('[AccupdatorManager]\x20Accupdator\x20section\x20not\x20found');return;}const _0x34c5cd=this['_generateSubscribersMenuHTML']();_0x1b04ea['insertAdjacentHTML']('beforeend',_0x34c5cd),this[_0x372ce2(0x23c)](),globalThis[_0x372ce2(0x15d)]?.('[AccupdatorManager]\x20Subscribers\x20menu\x20created');},'_generateSubscribersMenuHTML'(){const _0x5d41e6=a0_0x4d3c49;return _0x5d41e6(0x1d2)+this[_0x5d41e6(0x158)]['SUBS_MENU']+'\x22\x20class=\x22subscribers-menu\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20<!--\x20Header\x20with\x20title\x20and\x20back\x20button\x20-->\x0a\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22subscribers-header\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20id=\x22'+this[_0x5d41e6(0x158)][_0x5d41e6(0x290)]+_0x5d41e6(0x28e)+this[_0x5d41e6(0x158)][_0x5d41e6(0x229)]+_0x5d41e6(0x198)+this[_0x5d41e6(0x158)][_0x5d41e6(0x235)]+_0x5d41e6(0x22c)+this[_0x5d41e6(0x158)]['SUBS_LIST']+_0x5d41e6(0x16c);},'_setupSubscribersMenuEventListeners'(){const _0x5cbca3=a0_0x4d3c49,_0x5d334f=DOMManager[_0x5cbca3(0x20c)](this[_0x5cbca3(0x158)][_0x5cbca3(0x290)]);_0x5d334f&&EventManager['addEventListener'](_0x5d334f,'click',()=>this[_0x5cbca3(0x301)]());const _0x4ad646=DOMManager[_0x5cbca3(0x20c)](this[_0x5cbca3(0x158)]['SUBS_SEARCH_INPUT']);_0x4ad646&&EventManager[_0x5cbca3(0x17b)](_0x4ad646,_0x5cbca3(0x110),_0x7b8feb=>this['_handleSubscribersSearch'](_0x7b8feb[_0x5cbca3(0x1a2)][_0x5cbca3(0x29c)]));const _0x3137ac=DOMManager['getElement'](this[_0x5cbca3(0x158)]['NEW_USER_BTN']);_0x3137ac&&EventManager[_0x5cbca3(0x17b)](_0x3137ac,_0x5cbca3(0x279),()=>this[_0x5cbca3(0xff)]());},async '_loadSubscribers'(){const _0x225b1d=a0_0x4d3c49;globalThis['__GPTYAR_DEV_LOG__']?.(_0x225b1d(0x251));const _0xc5e2ad=DOMManager['getElement'](this['ELEMENT_IDS'][_0x225b1d(0x2bd)]);if(!_0xc5e2ad)return;_0xc5e2ad[_0x225b1d(0x28f)]=this[_0x225b1d(0xfb)]();try{const _0x4c0ec7=await this[_0x225b1d(0x274)]();this[_0x225b1d(0x177)]=_0x4c0ec7,this['_filteredSubscribersList']=_0x4c0ec7,this[_0x225b1d(0x1e5)](_0x4c0ec7);}catch(_0x54863c){globalThis['__GPTYAR_DEV_LOG__']?.('[AccupdatorManager]\x20Error\x20loading\x20subscribers:',_0x54863c),_0xc5e2ad['innerHTML']=_0x225b1d(0x2c6);}},'_generateSkeletonHTML'(){const _0xd68615=a0_0x4d3c49,_0x3b0131=PopupState[_0xd68615(0x29b)]?.['account']?.[_0xd68615(0x2c8)]||0xa;let _0x2ae259='';for(let _0x2d2c9b=0x0;_0x2d2c9b<_0x3b0131;_0x2d2c9b++){_0x2ae259+=_0xd68615(0x106);}return _0x2ae259;},'_handleSubscribersSearch'(_0x5a579c){const _0x21d11d=a0_0x4d3c49,_0x3478e6=_0x5a579c[_0x21d11d(0xfd)]()[_0x21d11d(0x31e)]();!_0x3478e6?this[_0x21d11d(0x242)]=this['_subscribersList']:this['_filteredSubscribersList']=this[_0x21d11d(0x177)][_0x21d11d(0x190)](_0x5e0292=>{const _0x33d94c=_0x21d11d,_0x1d8654=_0x5e0292[_0x33d94c(0x2fb)][_0x33d94c(0x31e)]()[_0x33d94c(0x1ec)](_0x3478e6),_0x3a1212=_0x5e0292[_0x33d94c(0x1fa)][_0x33d94c(0x31e)]()[_0x33d94c(0x1ec)](_0x3478e6);return _0x1d8654||_0x3a1212;}),this['_renderSubscribersList'](this[_0x21d11d(0x242)]);},'_renderSubscribersList'(_0x400194){const _0x445b4e=a0_0x4d3c49,_0xe2f4ce=DOMManager[_0x445b4e(0x20c)](this[_0x445b4e(0x158)][_0x445b4e(0x2bd)]);if(!_0xe2f4ce)return;if(_0x400194['length']===0x0){_0xe2f4ce[_0x445b4e(0x28f)]=_0x445b4e(0x150);return;}const _0x5ea3bc=_0x400194[_0x445b4e(0x143)](_0x251a07=>this[_0x445b4e(0x24a)](_0x251a07))[_0x445b4e(0x228)]('');_0xe2f4ce[_0x445b4e(0x28f)]=_0x5ea3bc,this[_0x445b4e(0x2b1)]();},'_setupSubscriberItemListeners'(){const _0x1f1a4c=a0_0x4d3c49,_0xe157ce=DOMManager[_0x1f1a4c(0x20c)](this['ELEMENT_IDS']['SUBS_LIST']);if(!_0xe157ce)return;const _0x50892d=_0xe157ce[_0x1f1a4c(0x316)](_0x1f1a4c(0x278));_0x50892d[_0x1f1a4c(0x33f)](_0xd7794f=>{const _0x17f718=_0x1f1a4c;_0xd7794f[_0x17f718(0x17b)](_0x17f718(0x279),()=>{const _0x39ad8d=_0x17f718,_0x56b925=_0xd7794f['getAttribute']('data-token');this[_0x39ad8d(0xeb)](_0x56b925);});});},'_generateSubscriberItemHTML'(_0x4e5dd7){const _0x1160a2=a0_0x4d3c49;let _0x393abd,_0x408154;if(_0x4e5dd7[_0x1160a2(0x2bc)]<=0x0)_0x393abd=_0x1160a2(0x103),_0x408154=_0x1160a2(0x185);else{if(_0x4e5dd7['remainingDays']<=0x5)_0x393abd=_0x1160a2(0x260),_0x408154=_0x4e5dd7[_0x1160a2(0x2bc)]+_0x1160a2(0x2e2);else _0x4e5dd7['isActive']?(_0x393abd=_0x1160a2(0x254),_0x408154=_0x4e5dd7[_0x1160a2(0x2bc)]+_0x1160a2(0x2e2)):(_0x393abd='status-red',_0x408154=_0x1160a2(0x326));}return _0x1160a2(0x137)+this['_escapeHTML'](_0x4e5dd7['token'])+_0x1160a2(0xf9)+this[_0x1160a2(0x1f0)](_0x4e5dd7[_0x1160a2(0x2fb)])+_0x1160a2(0x2f3)+this[_0x1160a2(0x1f0)](_0x4e5dd7[_0x1160a2(0x1fa)])+_0x1160a2(0x1a1)+_0x408154+_0x1160a2(0xde)+_0x393abd+_0x1160a2(0x1bb);},'_getSubscriberStatusClass'(_0x4b3dc1,_0x35440f=!![]){const _0x147228=a0_0x4d3c49;if(!_0x35440f)return'status-red';else{if(_0x4b3dc1<=0x0)return'status-red';else return _0x4b3dc1<=0x5?_0x147228(0x260):'status-green';}},'_escapeHTML'(_0x52ae5e){const _0x48ed21=a0_0x4d3c49,_0x1a986e=document[_0x48ed21(0x25c)](_0x48ed21(0x18c));return _0x1a986e['textContent']=_0x52ae5e,_0x1a986e[_0x48ed21(0x28f)];},async 'fetchSubscribersList'(){const _0x31fd53=a0_0x4d3c49;globalThis[_0x31fd53(0x15d)]?.(_0x31fd53(0x18b));try{const _0x29a76c=await AccupdatorAPI[_0x31fd53(0x1df)](),_0x179054=_0x29a76c['subscribers'][_0x31fd53(0x143)](_0x39b81b=>{const _0x2ee05f=_0x31fd53,_0x2476ea=_0x39b81b[_0x2ee05f(0x1d6)]?new Date(_0x39b81b[_0x2ee05f(0x1d6)]):null,_0x386347=this[_0x2ee05f(0x223)](_0x2476ea);return{'subscriptionId':_0x39b81b[_0x2ee05f(0x1a6)],'name':_0x39b81b[_0x2ee05f(0x2fb)],'token':_0x39b81b['token'],'expiryDate':_0x2476ea,'remainingDays':_0x386347?_0x386347:0x3e7,'isActive':_0x39b81b[_0x2ee05f(0x22e)]};});return globalThis[_0x31fd53(0x15d)]?.('[AccupdatorManager]\x20Subscribers\x20list\x20fetched:',_0x179054[_0x31fd53(0x26d)],'items'),_0x179054;}catch(_0x2dab6e){return globalThis['__GPTYAR_DEV_LOG__']?.(_0x31fd53(0x2f1),_0x2dab6e),[];}},'_calculateRemainingDays'(_0x4aae29){const _0x397019=a0_0x4d3c49;if(!_0x4aae29)return 0x0;const _0x1e9ffe=new Date(),_0x3e7fc5=_0x4aae29[_0x397019(0x2e5)]()-_0x1e9ffe['getTime'](),_0x42bfaa=Math['ceil'](_0x3e7fc5/(0x3e8*0x3c*0x3c*0x18));return _0x42bfaa;},async '_openSubscriberDetails'(_0x23113e){const _0x2abb58=a0_0x4d3c49;globalThis['__GPTYAR_DEV_LOG__']?.(_0x2abb58(0x1d5),_0x23113e);try{const _0x5d045c=await this['fetchSubscriberDetails'](_0x23113e);if(!_0x5d045c){NotificationManager[_0x2abb58(0x2e8)](_0x2abb58(0x155));return;}this[_0x2abb58(0x1b8)]=_0x5d045c,this['_selectedNewDate']=null;let _0x3037df=DOMManager[_0x2abb58(0x20c)](this[_0x2abb58(0x158)][_0x2abb58(0x20e)]);!_0x3037df&&(this[_0x2abb58(0x277)](),_0x3037df=DOMManager['getElement'](this[_0x2abb58(0x158)]['SUBSCRIBER_DETAILS_MENU']));this[_0x2abb58(0xf3)](_0x5d045c),this[_0x2abb58(0x209)](_0x5d045c[_0x2abb58(0xe9)]);const _0x5335d1=DOMManager[_0x2abb58(0x20c)](this['ELEMENT_IDS'][_0x2abb58(0x18f)]);_0x5335d1&&(_0x5335d1[_0x2abb58(0x12f)]=!![]);const _0x5f594b=DOMManager[_0x2abb58(0x20c)](this[_0x2abb58(0x158)][_0x2abb58(0x200)]);_0x5f594b&&_0x5f594b[_0x2abb58(0x11d)][_0x2abb58(0x21c)](_0x2abb58(0x213)),_0x3037df&&_0x3037df[_0x2abb58(0x11d)][_0x2abb58(0x199)](_0x2abb58(0x213)),globalThis[_0x2abb58(0x15d)]?.(_0x2abb58(0x1ee));}catch(_0x10e552){globalThis[_0x2abb58(0x15d)]?.(_0x2abb58(0x26b),_0x10e552),NotificationManager[_0x2abb58(0x2e8)](_0x2abb58(0x22f));}},'_hideSubscriberDetailsMenu'(){const _0x3443ff=a0_0x4d3c49;globalThis[_0x3443ff(0x15d)]?.(_0x3443ff(0x241));const _0x3a80f6=DOMManager[_0x3443ff(0x20c)](this['ELEMENT_IDS'][_0x3443ff(0x20e)]),_0x40ce9e=DOMManager[_0x3443ff(0x20c)](this['ELEMENT_IDS'][_0x3443ff(0x200)]);_0x3a80f6&&_0x3a80f6['classList'][_0x3443ff(0x21c)](_0x3443ff(0x213)),_0x40ce9e&&_0x40ce9e[_0x3443ff(0x11d)][_0x3443ff(0x199)](_0x3443ff(0x213)),this[_0x3443ff(0x1b8)]=null,this['_selectedNewDate']=null;},'_createSubscriberDetailsMenu'(){const _0x14c8d7=a0_0x4d3c49;globalThis[_0x14c8d7(0x15d)]?.(_0x14c8d7(0x16d));const _0x28a1fd=DOMManager[_0x14c8d7(0x20c)](this[_0x14c8d7(0x158)][_0x14c8d7(0x1b6)]);if(!_0x28a1fd){globalThis[_0x14c8d7(0x15d)]?.(_0x14c8d7(0xe2));return;}const _0x4ae0ad=this['_generateSubscriberDetailsMenuHTML']();_0x28a1fd[_0x14c8d7(0x2fa)](_0x14c8d7(0x19d),_0x4ae0ad),this[_0x14c8d7(0x340)](),globalThis[_0x14c8d7(0x15d)]?.(_0x14c8d7(0x1da));},'_generateSubscriberDetailsMenuHTML'(){const _0x774ae0=a0_0x4d3c49;return _0x774ae0(0x1d2)+this[_0x774ae0(0x158)][_0x774ae0(0x20e)]+_0x774ae0(0x2eb)+this[_0x774ae0(0x158)]['SUBSCRIBER_DETAILS_BACK_BTN']+_0x774ae0(0x2b4)+this['ELEMENT_IDS'][_0x774ae0(0x214)]+'\x22\x20class=\x22detail-value\x22>-</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22detail-row\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22detail-label\x22>توکن:</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22detail-value-with-action\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20id=\x22'+this[_0x774ae0(0x158)][_0x774ae0(0x28d)]+_0x774ae0(0x2db)+this[_0x774ae0(0x158)][_0x774ae0(0x337)]+_0x774ae0(0x2b6)+this[_0x774ae0(0x158)][_0x774ae0(0x270)]+'\x22\x20class=\x22detail-value\x22>-</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<!--\x20Persian\x20Calendar\x20-->\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22subscriber-calendar-container\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22calendar-header\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20class=\x22calendar-nav-btn\x22\x20id=\x22calendarPrevMonth\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<svg\x20width=\x2216\x22\x20height=\x2216\x22\x20viewBox=\x220\x200\x2024\x2024\x22\x20fill=\x22none\x22\x20stroke=\x22currentColor\x22\x20stroke-width=\x222\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<polyline\x20points=\x229\x2018\x2015\x2012\x209\x206\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</svg>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22calendar-month-year\x22\x20id=\x22calendarMonthYear\x22></span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20class=\x22calendar-nav-btn\x22\x20id=\x22calendarNextMonth\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<svg\x20width=\x2216\x22\x20height=\x2216\x22\x20viewBox=\x220\x200\x2024\x2024\x22\x20fill=\x22none\x22\x20stroke=\x22currentColor\x22\x20stroke-width=\x222\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<polyline\x20points=\x2215\x2018\x209\x2012\x2015\x206\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</svg>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22calendar-weekdays\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span>ش</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span>ی</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span>د</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span>س</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span>چ</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span>پ</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span>ج</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20id=\x22'+this[_0x774ae0(0x158)]['SUBSCRIBER_CALENDAR']+_0x774ae0(0x309)+this[_0x774ae0(0x158)][_0x774ae0(0x18f)]+_0x774ae0(0x29d)+this[_0x774ae0(0x158)][_0x774ae0(0x1f9)]+_0x774ae0(0x219);},'_setupSubscriberDetailsEventListeners'(){const _0x5dde6c=a0_0x4d3c49,_0x1e6126=DOMManager[_0x5dde6c(0x20c)](this[_0x5dde6c(0x158)][_0x5dde6c(0x1c2)]);_0x1e6126&&EventManager[_0x5dde6c(0x17b)](_0x1e6126,_0x5dde6c(0x279),()=>this[_0x5dde6c(0x15e)]());const _0xe1aa6e=DOMManager[_0x5dde6c(0x20c)](this[_0x5dde6c(0x158)][_0x5dde6c(0x18f)]);_0xe1aa6e&&EventManager['addEventListener'](_0xe1aa6e,_0x5dde6c(0x279),()=>this[_0x5dde6c(0x101)]());const _0x560691=DOMManager[_0x5dde6c(0x20c)](this[_0x5dde6c(0x158)]['SUBSCRIBER_DELETE_BTN']);_0x560691&&EventManager[_0x5dde6c(0x17b)](_0x560691,_0x5dde6c(0x279),()=>this[_0x5dde6c(0x30c)]());const _0x4c1707=document[_0x5dde6c(0x256)](_0x5dde6c(0x27a)),_0x1d7f7b=document['getElementById'](_0x5dde6c(0x29f));_0x4c1707&&EventManager['addEventListener'](_0x4c1707,_0x5dde6c(0x279),()=>this[_0x5dde6c(0x147)](-0x1));_0x1d7f7b&&EventManager[_0x5dde6c(0x17b)](_0x1d7f7b,_0x5dde6c(0x279),()=>this['_navigateCalendar'](0x1));const _0x4101b4=DOMManager['getElement'](this[_0x5dde6c(0x158)][_0x5dde6c(0x337)]);_0x4101b4&&EventManager[_0x5dde6c(0x17b)](_0x4101b4,'click',()=>this[_0x5dde6c(0x307)]());},async '_handleCopyToken'(){const _0x437268=a0_0x4d3c49,_0x337fff=DOMManager[_0x437268(0x20c)](this['ELEMENT_IDS'][_0x437268(0x28d)]);if(!_0x337fff)return;const _0x301093=_0x337fff[_0x437268(0x25e)];try{await navigator['clipboard'][_0x437268(0x1c6)](_0x301093),NotificationManager[_0x437268(0x29a)](_0x437268(0x33e));const _0xfc5cf8=DOMManager[_0x437268(0x20c)](this[_0x437268(0x158)]['SUBSCRIBER_COPY_TOKEN_BTN']);_0xfc5cf8&&(_0xfc5cf8[_0x437268(0x11d)][_0x437268(0x199)]('copied'),setTimeout(()=>_0xfc5cf8['classList'][_0x437268(0x21c)](_0x437268(0x311)),0x5dc));}catch(_0x49623f){globalThis['__GPTYAR_DEV_LOG__']?.('[AccupdatorManager]\x20Error\x20copying\x20token:',_0x49623f),NotificationManager[_0x437268(0x2e8)](_0x437268(0x2a4));}},'_updateSubscriberDetailsContent'(_0x1e5d26){const _0x2778ad=a0_0x4d3c49,_0x4acf95=DOMManager[_0x2778ad(0x20c)](this['ELEMENT_IDS'][_0x2778ad(0x214)]),_0x251446=DOMManager[_0x2778ad(0x20c)](this['ELEMENT_IDS'][_0x2778ad(0x28d)]),_0x38b56f=DOMManager[_0x2778ad(0x20c)](this[_0x2778ad(0x158)]['SUBSCRIBER_DETAILS_EXPIRY']);if(_0x4acf95)_0x4acf95[_0x2778ad(0x25e)]=_0x1e5d26[_0x2778ad(0x2fb)];if(_0x251446)_0x251446[_0x2778ad(0x25e)]=_0x1e5d26[_0x2778ad(0x1fa)];_0x38b56f&&(_0x38b56f[_0x2778ad(0x25e)]=this['_formatPersianDate'](_0x1e5d26[_0x2778ad(0xe9)]),_0x38b56f[_0x2778ad(0x11d)][_0x2778ad(0x21c)]('expiry-changing'));},'_newUserExpiryDate':null,'_newUserCalendarState':{'year':null,'month':null},'_showNewUserMenu'(){const _0x1d67d1=a0_0x4d3c49;globalThis['__GPTYAR_DEV_LOG__']?.(_0x1d67d1(0x17e));let _0x29f7dd=DOMManager['getElement'](this[_0x1d67d1(0x158)][_0x1d67d1(0x284)]);!_0x29f7dd&&(this[_0x1d67d1(0x2a3)](),_0x29f7dd=DOMManager['getElement'](this['ELEMENT_IDS']['NEW_USER_MENU']));const _0x561454=DOMManager[_0x1d67d1(0x20c)](this[_0x1d67d1(0x158)][_0x1d67d1(0x200)]);_0x561454&&_0x561454[_0x1d67d1(0x11d)][_0x1d67d1(0x21c)](_0x1d67d1(0x213)),_0x29f7dd&&_0x29f7dd['classList']['add'](_0x1d67d1(0x213)),this[_0x1d67d1(0x2df)](),this['_initializeNewUserCalendar']();},'_hideNewUserMenu'(){const _0x1d9444=a0_0x4d3c49;globalThis['__GPTYAR_DEV_LOG__']?.('[AccupdatorManager]\x20Closing\x20new\x20user\x20menu...');const _0x17d7d6=DOMManager['getElement'](this[_0x1d9444(0x158)][_0x1d9444(0x284)]),_0x1d6d5c=DOMManager['getElement'](this[_0x1d9444(0x158)][_0x1d9444(0x200)]);_0x17d7d6&&_0x17d7d6[_0x1d9444(0x11d)][_0x1d9444(0x21c)](_0x1d9444(0x213)),_0x1d6d5c&&_0x1d6d5c['classList'][_0x1d9444(0x199)](_0x1d9444(0x213));},'_createNewUserMenu'(){const _0x2d33e3=a0_0x4d3c49;globalThis[_0x2d33e3(0x15d)]?.('[AccupdatorManager]\x20Creating\x20new\x20user\x20menu...');const _0x1dd841=DOMManager[_0x2d33e3(0x20c)](this[_0x2d33e3(0x158)][_0x2d33e3(0x1b6)]);if(!_0x1dd841){globalThis[_0x2d33e3(0x15d)]?.(_0x2d33e3(0xe2));return;}const _0xc8e491=this['_generateNewUserMenuHTML']();_0x1dd841[_0x2d33e3(0x2fa)](_0x2d33e3(0x19d),_0xc8e491),this[_0x2d33e3(0x2d8)](),globalThis['__GPTYAR_DEV_LOG__']?.(_0x2d33e3(0x20f));},'_generateNewUserMenuHTML'(){const _0x21648f=a0_0x4d3c49;return _0x21648f(0x1d2)+this['ELEMENT_IDS'][_0x21648f(0x284)]+_0x21648f(0x1d3)+this[_0x21648f(0x158)][_0x21648f(0x2fc)]+_0x21648f(0x2c9)+this[_0x21648f(0x158)][_0x21648f(0x246)]+_0x21648f(0x283)+this[_0x21648f(0x158)][_0x21648f(0x246)]+_0x21648f(0x2f4)+this['ELEMENT_IDS'][_0x21648f(0x33a)]+'\x22\x20class=\x22detail-value\x20new-user-expiry\x22>انتخاب\x20نشده</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<!--\x20Persian\x20Calendar\x20-->\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22subscriber-calendar-container\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22calendar-header\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20class=\x22calendar-nav-btn\x22\x20id=\x22newUserCalendarPrevMonth\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<svg\x20width=\x2216\x22\x20height=\x2216\x22\x20viewBox=\x220\x200\x2024\x2024\x22\x20fill=\x22none\x22\x20stroke=\x22currentColor\x22\x20stroke-width=\x222\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<polyline\x20points=\x229\x2018\x2015\x2012\x209\x206\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</svg>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22calendar-month-year\x22\x20id=\x22newUserCalendarMonthYear\x22></span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20class=\x22calendar-nav-btn\x22\x20id=\x22newUserCalendarNextMonth\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<svg\x20width=\x2216\x22\x20height=\x2216\x22\x20viewBox=\x220\x200\x2024\x2024\x22\x20fill=\x22none\x22\x20stroke=\x22currentColor\x22\x20stroke-width=\x222\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<polyline\x20points=\x2215\x2018\x209\x2012\x2015\x206\x22/>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</svg>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22calendar-weekdays\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span>ش</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span>ی</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span>د</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span>س</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span>چ</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span>پ</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span>ج</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20id=\x22'+this[_0x21648f(0x158)][_0x21648f(0x19e)]+'\x22\x20class=\x22calendar-days\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<!--\x20Days\x20will\x20be\x20generated\x20dynamically\x20-->\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<!--\x20Create\x20Button\x20-->\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22subscriber-details-actions\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20id=\x22'+this['ELEMENT_IDS'][_0x21648f(0x13c)]+_0x21648f(0x335);},'_setupNewUserMenuEventListeners'(){const _0x37afd5=a0_0x4d3c49,_0x48e704=DOMManager['getElement'](this[_0x37afd5(0x158)][_0x37afd5(0x2fc)]);_0x48e704&&EventManager[_0x37afd5(0x17b)](_0x48e704,'click',()=>this[_0x37afd5(0x227)]());const _0x469f9b=DOMManager[_0x37afd5(0x20c)](this[_0x37afd5(0x158)][_0x37afd5(0x246)]);_0x469f9b&&EventManager[_0x37afd5(0x17b)](_0x469f9b,_0x37afd5(0x110),()=>this[_0x37afd5(0x1c3)]());const _0x4c6eab=DOMManager['getElement'](this[_0x37afd5(0x158)][_0x37afd5(0x13c)]);_0x4c6eab&&EventManager['addEventListener'](_0x4c6eab,_0x37afd5(0x279),()=>this[_0x37afd5(0x22a)]());const _0x4a8915=document['getElementById'](_0x37afd5(0x2e1)),_0x7b44c7=document[_0x37afd5(0x256)]('newUserCalendarNextMonth');_0x4a8915&&EventManager[_0x37afd5(0x17b)](_0x4a8915,_0x37afd5(0x279),()=>this['_navigateNewUserCalendar'](-0x1)),_0x7b44c7&&EventManager[_0x37afd5(0x17b)](_0x7b44c7,_0x37afd5(0x279),()=>this[_0x37afd5(0x275)](0x1));},'_resetNewUserForm'(){const _0xe2fb75=a0_0x4d3c49,_0x5e73ce=DOMManager[_0xe2fb75(0x20c)](this[_0xe2fb75(0x158)][_0xe2fb75(0x246)]);_0x5e73ce&&(_0x5e73ce[_0xe2fb75(0x29c)]='');this[_0xe2fb75(0x2a7)]=null;const _0x42ea22=DOMManager[_0xe2fb75(0x20c)](this[_0xe2fb75(0x158)][_0xe2fb75(0x33a)]);_0x42ea22&&(_0x42ea22[_0xe2fb75(0x25e)]=_0xe2fb75(0xed),_0x42ea22[_0xe2fb75(0x11d)]['remove'](_0xe2fb75(0xdc)));const _0x54cfab=DOMManager['getElement'](this['ELEMENT_IDS'][_0xe2fb75(0x13c)]);_0x54cfab&&(_0x54cfab[_0xe2fb75(0x12f)]=!![]);},'_initializeNewUserCalendar'(){const _0x1f7182=a0_0x4d3c49,_0x1063ee=new Date(),_0x174eea=this['_gregorianToPersian'](_0x1063ee);this[_0x1f7182(0x303)][_0x1f7182(0x1d8)]=_0x174eea[_0x1f7182(0x1d8)],this[_0x1f7182(0x303)][_0x1f7182(0x1cf)]=_0x174eea[_0x1f7182(0x1cf)],this['_renderNewUserCalendar']();},'_navigateNewUserCalendar'(_0xb51e4a){const _0x353d19=a0_0x4d3c49;this['_newUserCalendarState'][_0x353d19(0x1cf)]+=_0xb51e4a;if(this['_newUserCalendarState'][_0x353d19(0x1cf)]<0x1)this['_newUserCalendarState'][_0x353d19(0x1cf)]=0xc,this[_0x353d19(0x303)][_0x353d19(0x1d8)]--;else this[_0x353d19(0x303)]['month']>0xc&&(this[_0x353d19(0x303)][_0x353d19(0x1cf)]=0x1,this[_0x353d19(0x303)]['year']++);this[_0x353d19(0x2f8)]();},'_renderNewUserCalendar'(){const _0x25a947=a0_0x4d3c49,_0x196ada=DOMManager[_0x25a947(0x20c)](this[_0x25a947(0x158)]['NEW_USER_CALENDAR']),_0x404663=document[_0x25a947(0x256)](_0x25a947(0x2ce));if(!_0x196ada||!_0x404663)return;const {year:_0x4d5d91,month:_0x2031b1}=this[_0x25a947(0x303)];_0x404663[_0x25a947(0x25e)]=this[_0x25a947(0x27c)][_0x2031b1-0x1]+'\x20'+_0x4d5d91;const _0xcbf23f=new Date(),_0x3fea94=this['_gregorianToPersian'](_0xcbf23f),_0x3f9be4=this[_0x25a947(0x2a7)]?this[_0x25a947(0x31f)](this[_0x25a947(0x2a7)]):null,_0x626a52=this[_0x25a947(0x193)](_0x4d5d91,_0x2031b1),_0x4e3aa6=this[_0x25a947(0x328)](_0x4d5d91,_0x2031b1);let _0x482e65='';for(let _0x2c79f0=0x0;_0x2c79f0<_0x4e3aa6;_0x2c79f0++){_0x482e65+=_0x25a947(0x1b2);}for(let _0x555e0e=0x1;_0x555e0e<=_0x626a52;_0x555e0e++){const _0x5aef75=_0x3fea94[_0x25a947(0x1d8)]===_0x4d5d91&&_0x3fea94[_0x25a947(0x1cf)]===_0x2031b1&&_0x3fea94['day']===_0x555e0e,_0x5a46df=_0x3f9be4&&_0x3f9be4[_0x25a947(0x1d8)]===_0x4d5d91&&_0x3f9be4[_0x25a947(0x1cf)]===_0x2031b1&&_0x3f9be4['day']===_0x555e0e;let _0x2b1eb5=_0x25a947(0x1ca);if(_0x5aef75)_0x2b1eb5+=_0x25a947(0x151);if(_0x5a46df)_0x2b1eb5+=_0x25a947(0x295);_0x482e65+=_0x25a947(0x233)+_0x2b1eb5+'\x22\x20data-day=\x22'+_0x555e0e+_0x25a947(0x306)+(_0x5aef75?_0x25a947(0x2aa):_0x5a46df?'تاریخ\x20انتخاب\x20شده':'')+'\x22>'+_0x555e0e+_0x25a947(0x25b);}_0x196ada[_0x25a947(0x28f)]=_0x482e65;const _0xc498d8=_0x196ada[_0x25a947(0x316)](_0x25a947(0x166));_0xc498d8[_0x25a947(0x33f)](_0x58df4a=>{const _0xfe23d2=_0x25a947;_0x58df4a['addEventListener'](_0xfe23d2(0x279),()=>{const _0xc4cd66=_0xfe23d2,_0x1e41ad=parseInt(_0x58df4a['getAttribute'](_0xc4cd66(0x2b8)));this['_selectNewUserDate'](_0x4d5d91,_0x2031b1,_0x1e41ad);});});},'_selectNewUserDate'(_0x32f242,_0x2d479f,_0x548fdf){const _0x346a14=a0_0x4d3c49;this['_newUserExpiryDate']=this[_0x346a14(0x1e1)](_0x32f242,_0x2d479f,_0x548fdf),this[_0x346a14(0x2f8)]();const _0x44370b=DOMManager[_0x346a14(0x20c)](this['ELEMENT_IDS'][_0x346a14(0x33a)]);_0x44370b&&(_0x44370b[_0x346a14(0x25e)]=this['_formatPersianDate'](this[_0x346a14(0x2a7)]),_0x44370b[_0x346a14(0x11d)][_0x346a14(0x199)](_0x346a14(0xdc))),this['_updateNewUserCreateButtonState']();},'_updateNewUserCreateButtonState'(){const _0x230617=a0_0x4d3c49,_0x13d00d=DOMManager[_0x230617(0x20c)](this[_0x230617(0x158)][_0x230617(0x246)]),_0x674268=DOMManager[_0x230617(0x20c)](this[_0x230617(0x158)]['NEW_USER_CREATE_BTN']);if(!_0x13d00d||!_0x674268)return;const _0x3739b3=_0x13d00d[_0x230617(0x29c)][_0x230617(0xfd)]()['length']>0x0,_0x14ffb5=this[_0x230617(0x2a7)]!==null;_0x674268[_0x230617(0x12f)]=!(_0x3739b3&&_0x14ffb5);},async '_handleCreateNewUser'(){const _0x44c42b=a0_0x4d3c49,_0x2c6d7e=DOMManager['getElement'](this['ELEMENT_IDS'][_0x44c42b(0x246)]);if(!_0x2c6d7e||!this[_0x44c42b(0x2a7)])return;const _0xfd48d9=_0x2c6d7e['value']['trim']();if(!_0xfd48d9)return;globalThis[_0x44c42b(0x15d)]?.(_0x44c42b(0x21f),_0xfd48d9);const _0x5d9537=DOMManager[_0x44c42b(0x20c)](this[_0x44c42b(0x158)][_0x44c42b(0x13c)]);try{this[_0x44c42b(0x176)](_0x5d9537,!![]);const _0x3f1aab=await this['createNewUser'](_0xfd48d9,this[_0x44c42b(0x2a7)]);NotificationManager['showSuccess'](_0x44c42b(0x265));const _0x1d81d7=DOMManager[_0x44c42b(0x20c)](this['ELEMENT_IDS']['NEW_USER_MENU']);_0x1d81d7&&_0x1d81d7[_0x44c42b(0x11d)][_0x44c42b(0x21c)](_0x44c42b(0x213)),this[_0x44c42b(0x1c1)](_0x3f1aab),this[_0x44c42b(0x313)](),this['refreshAccountInfo']();}catch(_0x4f528f){globalThis[_0x44c42b(0x15d)]?.(_0x44c42b(0x243),_0x4f528f),NotificationManager[_0x44c42b(0x2e8)](_0x44c42b(0x188));}finally{this[_0x44c42b(0x176)](_0x5d9537,![]);}},'_showCreatedUserDetails'(_0x58fe57){const _0x4254bb=a0_0x4d3c49;globalThis[_0x4254bb(0x15d)]?.('[AccupdatorManager]\x20Showing\x20created\x20user\x20details:',_0x58fe57),this[_0x4254bb(0x1b8)]=_0x58fe57,this[_0x4254bb(0xe3)]=null;let _0x2849b5=DOMManager[_0x4254bb(0x20c)](this[_0x4254bb(0x158)][_0x4254bb(0x20e)]);!_0x2849b5&&(this[_0x4254bb(0x277)](),_0x2849b5=DOMManager[_0x4254bb(0x20c)](this[_0x4254bb(0x158)][_0x4254bb(0x20e)])),this[_0x4254bb(0xf3)](_0x58fe57),this[_0x4254bb(0x209)](_0x58fe57[_0x4254bb(0xe9)]),_0x2849b5&&_0x2849b5[_0x4254bb(0x11d)][_0x4254bb(0x199)](_0x4254bb(0x213));},async 'createNewUser'(_0x1aeae4,_0x64c5d9){const _0x1bb347=a0_0x4d3c49;globalThis[_0x1bb347(0x15d)]?.(_0x1bb347(0x26c),{'name':_0x1aeae4,'expiryDate':_0x64c5d9});const _0x10fa21=await AccupdatorAPI['createUser'](_0x1aeae4,_0x64c5d9);return{'subscriptionId':_0x10fa21[_0x1bb347(0x1a6)],'name':_0x10fa21[_0x1bb347(0x2fb)],'token':_0x10fa21[_0x1bb347(0x1fa)],'expiryDate':_0x10fa21[_0x1bb347(0x1d6)]?new Date(_0x10fa21['expiresAt']):_0x64c5d9};},'_proxyServerNames':[a0_0x4d3c49(0x1db),'سرور\x20دوم',a0_0x4d3c49(0x226),a0_0x4d3c49(0x2d1),a0_0x4d3c49(0x145)],'_setupProxyEventListeners'(){const _0x765936=a0_0x4d3c49;globalThis[_0x765936(0x15d)]?.(_0x765936(0x1c8));const _0x23d1af=DOMManager[_0x765936(0x20c)](this[_0x765936(0x158)][_0x765936(0x13d)]);_0x23d1af&&EventManager[_0x765936(0x17b)](_0x23d1af,_0x765936(0x2ca),_0x5f3da6=>this[_0x765936(0x17c)](_0x5f3da6[_0x765936(0x1a2)][_0x765936(0x2d3)]));const _0x1ff586=DOMManager[_0x765936(0x20c)](this[_0x765936(0x158)]['PROXY_REFRESH_BTN']);_0x1ff586&&EventManager[_0x765936(0x17b)](_0x1ff586,_0x765936(0x279),()=>this[_0x765936(0x170)]());},async '_initializeProxyState'(){const _0x5d9a98=a0_0x4d3c49;globalThis[_0x5d9a98(0x15d)]?.('[AccupdatorManager]\x20Initializing\x20proxy\x20state...');try{const _0x4f9ae7=await StorageManager[_0x5d9a98(0x276)]([CONFIG[_0x5d9a98(0x225)][_0x5d9a98(0x1b9)],CONFIG[_0x5d9a98(0x225)][_0x5d9a98(0x220)]]),_0x93dfc4=_0x4f9ae7[CONFIG[_0x5d9a98(0x225)][_0x5d9a98(0x1b9)]],_0x18a28f=Boolean(_0x4f9ae7[CONFIG[_0x5d9a98(0x225)][_0x5d9a98(0x220)]]);globalThis[_0x5d9a98(0x15d)]?.(_0x5d9a98(0x319),_0x93dfc4);const _0xf9c86b=DOMManager[_0x5d9a98(0x20c)](this[_0x5d9a98(0x158)][_0x5d9a98(0x13d)]),_0x2db399=DOMManager['getElement'](this[_0x5d9a98(0x158)][_0x5d9a98(0xf2)]),_0x45e766=_0x93dfc4===undefined||_0x93dfc4===null;if(_0x45e766)globalThis['__GPTYAR_DEV_LOG__']?.(_0x5d9a98(0x17a)),this['_proxyEnabled']=!![],_0xf9c86b&&(_0xf9c86b[_0x5d9a98(0x2d3)]=!![]),_0x2db399&&(_0x2db399[_0x5d9a98(0x312)][_0x5d9a98(0x122)]=_0x5d9a98(0x10a)),await this[_0x5d9a98(0x17c)](!![]);else _0x93dfc4<0x0?(this[_0x5d9a98(0x329)]=![],this['_selectedAdminProxyIndex']=-0x1,_0xf9c86b&&(_0xf9c86b[_0x5d9a98(0x2d3)]=![]),_0x2db399&&(_0x2db399[_0x5d9a98(0x312)][_0x5d9a98(0x122)]=_0x5d9a98(0x314))):(this[_0x5d9a98(0x329)]=!![],this['_selectedAdminProxyIndex']=_0x93dfc4,_0xf9c86b&&(_0xf9c86b['checked']=!![]),_0x2db399&&(_0x2db399[_0x5d9a98(0x312)][_0x5d9a98(0x122)]=_0x5d9a98(0x10a)),await this['_fetchAdminProxies'](),!_0x18a28f&&await this[_0x5d9a98(0x247)](!![]));globalThis['__GPTYAR_DEV_LOG__']?.(_0x5d9a98(0x2fe),{'enabled':this[_0x5d9a98(0x329)],'selectedIndex':this['_selectedAdminProxyIndex']});}catch(_0x460843){globalThis[_0x5d9a98(0x15d)]?.(_0x5d9a98(0x297),_0x460843);}},async '_setProxyKeepAliveState'(_0x2a69f1){const _0x4af3f7=a0_0x4d3c49;await StorageManager[_0x4af3f7(0x330)]({[CONFIG[_0x4af3f7(0x225)][_0x4af3f7(0x220)]]:_0x2a69f1});if(!_0x2a69f1)return;const _0x42ce3b=PopupState[_0x4af3f7(0x294)]||await DeviceIdManager[_0x4af3f7(0x238)]();PopupState[_0x4af3f7(0x294)]=_0x42ce3b,await new Promise(_0x1fea73=>{const _0x37cd0e=_0x4af3f7;chrome[_0x37cd0e(0x315)][_0x37cd0e(0x1f1)]({'action':_0x37cd0e(0x139),'token':PopupState['token'],'device_id':_0x42ce3b,'isChecked':!![]},()=>_0x1fea73());});},async '_handleProxyToggle'(_0x3e4f13){const _0x5572aa=a0_0x4d3c49;globalThis[_0x5572aa(0x15d)]?.(_0x5572aa(0x248),_0x3e4f13),this[_0x5572aa(0x329)]=_0x3e4f13;const _0x272a09=DOMManager[_0x5572aa(0x20c)](this[_0x5572aa(0x158)][_0x5572aa(0xf2)]);if(_0x3e4f13){_0x272a09&&(_0x272a09[_0x5572aa(0x312)][_0x5572aa(0x122)]=_0x5572aa(0x10a));this['_adminProxies'][_0x5572aa(0x26d)]===0x0&&await this[_0x5572aa(0x23f)]();if(this[_0x5572aa(0x322)][_0x5572aa(0x26d)]>0x0)try{const _0x1b7c74=await StorageManager[_0x5572aa(0x276)]([CONFIG[_0x5572aa(0x225)][_0x5572aa(0x1b9)]]),_0x595162=_0x1b7c74[CONFIG[_0x5572aa(0x225)]['SELECTED_PROXY_INDEX']];let _0x380f48;_0x595162!==undefined&&_0x595162!==null&&_0x595162>=0x0&&_0x595162<this[_0x5572aa(0x322)]['length']?(_0x380f48=_0x595162,globalThis[_0x5572aa(0x15d)]?.(_0x5572aa(0x317),_0x380f48)):(_0x380f48=Math[_0x5572aa(0x11f)](Math[_0x5572aa(0x2ae)]()*this[_0x5572aa(0x322)][_0x5572aa(0x26d)]),globalThis[_0x5572aa(0x15d)]?.(_0x5572aa(0x259),_0x380f48)),await this['_selectAdminProxy'](_0x380f48);}catch(_0x32d2d8){globalThis[_0x5572aa(0x15d)]?.('[AccupdatorManager]\x20Error\x20selecting\x20proxy:',_0x32d2d8);}}else _0x272a09&&(_0x272a09[_0x5572aa(0x312)][_0x5572aa(0x122)]='none'),this[_0x5572aa(0x338)]();},async '_fetchAdminProxies'(){const _0xce9a02=a0_0x4d3c49;globalThis[_0xce9a02(0x15d)]?.('[AccupdatorManager]\x20Fetching\x20admin\x20proxies...');const _0x54ad30=DOMManager['getElement'](this[_0xce9a02(0x158)][_0xce9a02(0x331)]);if(!_0x54ad30)return;_0x54ad30[_0xce9a02(0x28f)]=this[_0xce9a02(0x157)]();try{const _0x2537c4=await fetch(CONFIG[_0xce9a02(0x30a)]+_0xce9a02(0x2a5),{'method':_0xce9a02(0x32f),'headers':{'Content-Type':_0xce9a02(0xdb)},'body':JSON['stringify']({'token':PopupState[_0xce9a02(0x1fa)]})});if(!_0x2537c4['ok'])throw new Error('Proxy\x20fetch\x20failed\x20with\x20status:\x20'+_0x2537c4['status']);const _0x45a3fe=await _0x2537c4[_0xce9a02(0x2c7)]();globalThis[_0xce9a02(0x15d)]?.(_0xce9a02(0x273),_0x45a3fe),_0x45a3fe&&Array['isArray'](_0x45a3fe)?(this[_0xce9a02(0x322)]=this['_normalizeProxyList'](_0x45a3fe),this[_0xce9a02(0x26e)]()):(this[_0xce9a02(0x322)]=[],_0x54ad30[_0xce9a02(0x28f)]=_0xce9a02(0x31d));}catch(_0x3e8c7b){globalThis[_0xce9a02(0x15d)]?.(_0xce9a02(0x2d6),_0x3e8c7b),_0x54ad30['innerHTML']=_0xce9a02(0x2f2);}},'_normalizeProxy'(_0x32879a){const _0xdf02c=a0_0x4d3c49,_0x56e569={..._0x32879a},_0xcca2ae=typeof _0x56e569['PROXY_SERVER']===_0xdf02c(0x1bd)?_0x56e569[_0xdf02c(0xda)]:'',_0x24fa7e=_0xcca2ae['split'](':'),_0xe35d70=_0x24fa7e[0x0]||'',_0x1b1aef=_0x24fa7e[_0xdf02c(0x26d)]>0x1?parseInt(_0x24fa7e[_0x24fa7e[_0xdf02c(0x26d)]-0x1],0xa):undefined,_0x24fcc3=_0x56e569[_0xdf02c(0x2e0)]||_0xe35d70;let _0x343fc2=_0x56e569[_0xdf02c(0x2b3)];if(typeof _0x343fc2===_0xdf02c(0x1bd))_0x343fc2=parseInt(_0x343fc2,0xa);if(!Number['isFinite'](_0x343fc2)&&Number['isFinite'](_0x1b1aef))_0x343fc2=_0x1b1aef;if(!Number[_0xdf02c(0x25f)](_0x343fc2))_0x343fc2=0x2385;let _0x251cbb=_0x56e569[_0xdf02c(0x15c)];if(typeof _0x251cbb===_0xdf02c(0x1bd))_0x251cbb=parseInt(_0x251cbb,0xa);if(!Number[_0xdf02c(0x25f)](_0x251cbb)&&Number[_0xdf02c(0x25f)](_0x343fc2))_0x251cbb=_0x343fc2+0x1;if(!Number['isFinite'](_0x251cbb))_0x251cbb=0x2386;return _0x24fcc3&&(_0x56e569[_0xdf02c(0x2e0)]=_0x24fcc3,_0x56e569[_0xdf02c(0xda)]=_0x24fcc3+':'+_0x343fc2),_0x56e569[_0xdf02c(0x2b3)]=_0x343fc2,_0x56e569[_0xdf02c(0x15c)]=_0x251cbb,_0x56e569;},'_normalizeProxyList'(_0x83f8da){const _0x1225bb=a0_0x4d3c49;return _0x83f8da[_0x1225bb(0x143)](_0x26449c=>this[_0x1225bb(0x20b)](_0x26449c));},async '_refreshAdminProxies'(){const _0x5983e5=a0_0x4d3c49;globalThis[_0x5983e5(0x15d)]?.(_0x5983e5(0x196));const _0x8cb78e=DOMManager[_0x5983e5(0x20c)](this[_0x5983e5(0x158)][_0x5983e5(0x258)]);_0x8cb78e&&_0x8cb78e[_0x5983e5(0x11d)][_0x5983e5(0x199)]('spinning'),await this['_fetchAdminProxies'](),_0x8cb78e&&setTimeout(()=>_0x8cb78e[_0x5983e5(0x11d)][_0x5983e5(0x21c)]('spinning'),0x1f4);},'_generateProxySkeletonHTML'(){const _0x54a54e=a0_0x4d3c49;let _0xd3388e='';for(let _0x151686=0x0;_0x151686<0x3;_0x151686++){_0xd3388e+=_0x54a54e(0x323);}return _0xd3388e;},'_renderAdminProxyList'(){const _0x57cc24=a0_0x4d3c49,_0x1e8347=DOMManager[_0x57cc24(0x20c)](this[_0x57cc24(0x158)][_0x57cc24(0x331)]);if(!_0x1e8347)return;if(this[_0x57cc24(0x322)]['length']===0x0){_0x1e8347['innerHTML']='<div\x20class=\x22admin-proxy-empty\x22>هیچ\x20پروکسی\x20در\x20دسترس\x20نیست</div>';return;}let _0x4fcda2='';this[_0x57cc24(0x322)][_0x57cc24(0x33f)]((_0x2b2f2d,_0x40a085)=>{const _0x513914=_0x57cc24,_0x16fb6a=_0x40a085===this[_0x513914(0x261)],_0xbcd6d5=_0x2b2f2d[_0x513914(0x2fb)]||this[_0x513914(0x268)][_0x40a085]||_0x513914(0x160)+(_0x40a085+0x1);_0x4fcda2+=_0x513914(0x22d)+(_0x16fb6a?_0x513914(0x295):'')+_0x513914(0x1a5)+_0x40a085+_0x513914(0x232)+this[_0x513914(0x1f0)](_0xbcd6d5)+_0x513914(0x14b);}),_0x1e8347['innerHTML']=_0x4fcda2,this[_0x57cc24(0x167)](),this[_0x57cc24(0x102)]();},'_setupProxyItemListeners'(){const _0x59bed9=a0_0x4d3c49,_0x40f84f=DOMManager[_0x59bed9(0x20c)](this[_0x59bed9(0x158)][_0x59bed9(0x331)]);if(!_0x40f84f)return;const _0x255ad8=_0x40f84f[_0x59bed9(0x316)](_0x59bed9(0x1f4));_0x255ad8[_0x59bed9(0x33f)](_0x3db77c=>{const _0x64bfa2=_0x59bed9;_0x3db77c[_0x64bfa2(0x17b)](_0x64bfa2(0x279),()=>{const _0x2344aa=_0x64bfa2,_0xb2f598=parseInt(_0x3db77c['getAttribute'](_0x2344aa(0x336)),0xa);this[_0x2344aa(0x262)](_0xb2f598);});});},async '_testAdminProxies'(){const _0x31efac=a0_0x4d3c49;globalThis[_0x31efac(0x15d)]?.(_0x31efac(0x186));const _0x128af0=DOMManager[_0x31efac(0x20c)](this[_0x31efac(0x158)][_0x31efac(0x331)]);if(!_0x128af0)return;const _0x3efd1c=_0x128af0[_0x31efac(0x316)](_0x31efac(0x1f4)),_0x50374b=this[_0x31efac(0x322)]['map'](async(_0x4911b9,_0x37df53)=>{const _0x18def2=_0x31efac;globalThis[_0x18def2(0x15d)]?.('Testing...',_0x4911b9,_0x37df53);const _0x524500=_0x3efd1c[_0x37df53];if(!_0x524500)return;const _0x13c1e8=_0x524500[_0x18def2(0x30b)](_0x18def2(0x1e8));try{const _0x2431fe=new AbortController(),_0x579d42=setTimeout(()=>_0x2431fe[_0x18def2(0xf5)](),0x1388),_0xc7f9c4=_0x4911b9[_0x18def2(0x2e0)]||(_0x4911b9['PROXY_SERVER']||'')[_0x18def2(0xe8)](':')[0x0],_0x19b6ad=Number(_0x4911b9[_0x18def2(0x2b3)]),_0x1b30c4=Number[_0x18def2(0x25f)](Number(_0x4911b9['PING_PORT']))?Number(_0x4911b9[_0x18def2(0x15c)]):Number[_0x18def2(0x25f)](_0x19b6ad)?_0x19b6ad+0x1:0x2386;if(!_0xc7f9c4)throw new Error(_0x18def2(0x1f2));const _0x302f60=_0x18def2(0x255)+_0xc7f9c4+':'+_0x1b30c4+'/ping',_0x57f132=Date[_0x18def2(0x287)](),_0x52a913=await fetch(_0x302f60,{'method':_0x18def2(0x1ac),'signal':_0x2431fe['signal'],'cache':_0x18def2(0x231)});clearTimeout(_0x579d42);const _0x347be9=Date['now'](),_0x2c9363=_0x347be9-_0x57f132;_0x13c1e8&&(_0x52a913['ok']?(_0x13c1e8[_0x18def2(0x25e)]=_0x2c9363+'ms',_0x13c1e8[_0x18def2(0x11d)]['add'](_0x18def2(0x148))):(_0x13c1e8[_0x18def2(0x25e)]=_0x18def2(0x333),_0x13c1e8[_0x18def2(0x11d)]['add'](_0x18def2(0x125)))),_0x524500[_0x18def2(0x11d)]['remove'](_0x18def2(0x208)),_0x524500[_0x18def2(0x11d)]['add'](_0x52a913['ok']?_0x18def2(0x298):_0x18def2(0x249));}catch(_0x58f9f1){globalThis[_0x18def2(0x15d)]?.(_0x18def2(0x2a0)+_0x37df53+'\x20test\x20failed:',_0x58f9f1[_0x18def2(0xfe)]),_0x13c1e8&&(_0x13c1e8[_0x18def2(0x25e)]=_0x18def2(0x333),_0x13c1e8['classList']['add'](_0x18def2(0x125))),_0x524500[_0x18def2(0x11d)][_0x18def2(0x21c)]('testing'),_0x524500[_0x18def2(0x11d)][_0x18def2(0x199)](_0x18def2(0x249));}});await Promise['all'](_0x50374b),globalThis[_0x31efac(0x15d)]?.('[AccupdatorManager]\x20Proxy\x20testing\x20complete');},async '_selectAdminProxy'(_0x3b6c07){const _0x38da40=a0_0x4d3c49;globalThis['__GPTYAR_DEV_LOG__']?.(_0x38da40(0x2bf),_0x3b6c07);if(_0x3b6c07<0x0||_0x3b6c07>=this[_0x38da40(0x322)][_0x38da40(0x26d)]){globalThis[_0x38da40(0x15d)]?.(_0x38da40(0x210),_0x3b6c07);return;}this['_selectedAdminProxyIndex']=_0x3b6c07;const _0x45e69e=DOMManager[_0x38da40(0x20c)](this['ELEMENT_IDS'][_0x38da40(0x331)]);if(_0x45e69e){const _0x323382=_0x45e69e[_0x38da40(0x316)]('.admin-proxy-item');_0x323382[_0x38da40(0x33f)]((_0xa2c63b,_0x104ee5)=>{const _0x420bb5=_0x38da40;_0xa2c63b[_0x420bb5(0x11d)][_0x420bb5(0x2ea)](_0x420bb5(0xec),_0x104ee5===_0x3b6c07);});}try{const _0x1030d4=await chrome['runtime']['sendMessage']({'action':_0x38da40(0x1c5),'index':_0x3b6c07,'proxies':this['_adminProxies']});if(!_0x1030d4?.[_0x38da40(0x148)])throw new Error(_0x1030d4?.[_0x38da40(0x125)]||_0x38da40(0x2b7));await StorageManager['set']({[CONFIG[_0x38da40(0x225)][_0x38da40(0x1b9)]]:_0x3b6c07}),await this[_0x38da40(0x247)](!![]),NotificationManager['showSuccess']('پروکسی\x20با\x20موفقیت\x20تغییر\x20کرد'),globalThis[_0x38da40(0x15d)]?.('[AccupdatorManager]\x20Admin\x20proxy\x20selected:',_0x3b6c07);}catch(_0x58ebeb){globalThis[_0x38da40(0x15d)]?.(_0x38da40(0x1f8),_0x58ebeb),NotificationManager[_0x38da40(0x2e8)](_0x38da40(0x10d));}},async '_disableProxy'(){const _0x39b445=a0_0x4d3c49;globalThis[_0x39b445(0x15d)]?.(_0x39b445(0x32a));try{await chrome['runtime'][_0x39b445(0x1f1)]({'action':_0x39b445(0x128)}),await this['_setProxyKeepAliveState'](![]),this[_0x39b445(0x261)]=-0x1,NotificationManager['showSuccess']('پروکسی\x20غیرفعال\x20شد');}catch(_0x44c28a){globalThis['__GPTYAR_DEV_LOG__']?.(_0x39b445(0x2ac),_0x44c28a);}},'_persianMonths':['فروردین',a0_0x4d3c49(0x1e7),a0_0x4d3c49(0x11e),'تیر','مرداد','شهریور','مهر',a0_0x4d3c49(0x109),'آذر','دی',a0_0x4d3c49(0x1a8),a0_0x4d3c49(0x152)],'_gregorianToPersian'(_0xbbf20d){const _0x993056=a0_0x4d3c49,_0x280607=_0xbbf20d[_0x993056(0xfa)](),_0xd5e814=_0xbbf20d[_0x993056(0x32b)]()+0x1,_0x49ae21=_0xbbf20d['getDate'](),_0x1bef56=[0x0,0x1f,0x3b,0x5a,0x78,0x97,0xb5,0xd4,0xf3,0x111,0x130,0x14e];let _0x5d6b07,_0x67684f,_0x14fcb3,_0x15409e,_0x26a0af;return _0x15409e=_0xd5e814>0x2?_0x280607+0x1:_0x280607,_0x26a0af=0x56d52+0x16d*_0x280607+Math[_0x993056(0x11f)]((_0x15409e+0x3)/0x4)-Math[_0x993056(0x11f)]((_0x15409e+0x63)/0x64)+Math[_0x993056(0x11f)]((_0x15409e+0x18f)/0x190)+_0x49ae21+_0x1bef56[_0xd5e814-0x1],_0x5d6b07=-0x63b+0x21*Math[_0x993056(0x11f)](_0x26a0af/0x2f15),_0x26a0af%=0x2f15,_0x5d6b07+=0x4*Math[_0x993056(0x11f)](_0x26a0af/0x5b5),_0x26a0af%=0x5b5,_0x26a0af>0x16d&&(_0x5d6b07+=Math[_0x993056(0x11f)]((_0x26a0af-0x1)/0x16d),_0x26a0af=(_0x26a0af-0x1)%0x16d),_0x26a0af<0xba?(_0x67684f=0x1+Math['floor'](_0x26a0af/0x1f),_0x14fcb3=0x1+_0x26a0af%0x1f):(_0x67684f=0x7+Math['floor']((_0x26a0af-0xba)/0x1e),_0x14fcb3=0x1+(_0x26a0af-0xba)%0x1e),{'year':_0x5d6b07,'month':_0x67684f,'day':_0x14fcb3};},'_persianToGregorian'(_0x526e99,_0xa9685a,_0x56b657){const _0xa92609=a0_0x4d3c49;let _0x2908d4,_0x94d4f5,_0x36adef,_0x47add8,_0x280361,_0x1c0703;_0x526e99+=0x63b,_0x47add8=-0x56d54+0x16d*_0x526e99+Math[_0xa92609(0x11f)](_0x526e99/0x21)*0x8+Math[_0xa92609(0x11f)]((_0x526e99%0x21+0x3)/0x4)+_0x56b657+(_0xa9685a<0x7?(_0xa9685a-0x1)*0x1f:(_0xa9685a-0x7)*0x1e+0xba),_0x2908d4=0x190*Math[_0xa92609(0x11f)](_0x47add8/0x23ab1),_0x47add8%=0x23ab1;if(_0x47add8>0x8eac){_0x2908d4+=0x64*Math[_0xa92609(0x11f)](--_0x47add8/0x8eac),_0x47add8%=0x8eac;if(_0x47add8>=0x16d)_0x47add8++;}_0x2908d4+=0x4*Math[_0xa92609(0x11f)](_0x47add8/0x5b5),_0x47add8%=0x5b5;_0x47add8>0x16d&&(_0x2908d4+=Math['floor']((_0x47add8-0x1)/0x16d),_0x47add8=(_0x47add8-0x1)%0x16d);_0x36adef=_0x47add8+0x1,_0x280361=[0x0,0x1f,_0x2908d4%0x4===0x0&&_0x2908d4%0x64!==0x0||_0x2908d4%0x190===0x0?0x1d:0x1c,0x1f,0x1e,0x1f,0x1e,0x1f,0x1f,0x1e,0x1f,0x1e,0x1f];for(_0x94d4f5=0x0;_0x94d4f5<0xd&&_0x36adef>_0x280361[_0x94d4f5];_0x94d4f5++)_0x36adef-=_0x280361[_0x94d4f5];return new Date(_0x2908d4,_0x94d4f5-0x1,_0x36adef);},'_getPersianMonthDays'(_0x571f4f,_0x978a34){if(_0x978a34<=0x6)return 0x1f;if(_0x978a34<=0xb)return 0x1e;const _0x1f38e1=((_0x571f4f-(_0x571f4f>0x0?0x1da:0x1d9))%0xb04+0x1da+0x26)*0x2aa%0xb00<0x2aa;return _0x1f38e1?0x1e:0x1d;},'_getFirstDayOfPersianMonth'(_0x4f0bb3,_0x5a12ea){const _0x94370a=a0_0x4d3c49,_0x2db2bd=this[_0x94370a(0x1e1)](_0x4f0bb3,_0x5a12ea,0x1);return(_0x2db2bd[_0x94370a(0x2f7)]()+0x1)%0x7;},'_initializeCalendar'(_0x1c4d66){const _0x1f92f1=a0_0x4d3c49,_0xee5946=this[_0x1f92f1(0x31f)](_0x1c4d66);this[_0x1f92f1(0x236)][_0x1f92f1(0x1d8)]=_0xee5946[_0x1f92f1(0x1d8)],this['_calendarState'][_0x1f92f1(0x1cf)]=_0xee5946[_0x1f92f1(0x1cf)],this[_0x1f92f1(0x21d)]();},'_navigateCalendar'(_0x530ef5){const _0x3c9bce=a0_0x4d3c49;this['_calendarState'][_0x3c9bce(0x1cf)]+=_0x530ef5;if(this['_calendarState']['month']<0x1)this[_0x3c9bce(0x236)][_0x3c9bce(0x1cf)]=0xc,this[_0x3c9bce(0x236)]['year']--;else this[_0x3c9bce(0x236)]['month']>0xc&&(this['_calendarState']['month']=0x1,this[_0x3c9bce(0x236)][_0x3c9bce(0x1d8)]++);this[_0x3c9bce(0x21d)]();},'_renderCalendar'(){const _0xfe6977=a0_0x4d3c49,_0x4d541e=DOMManager[_0xfe6977(0x20c)](this[_0xfe6977(0x158)][_0xfe6977(0x239)]),_0x4bb159=document[_0xfe6977(0x256)](_0xfe6977(0x1cc));if(!_0x4d541e||!_0x4bb159)return;const {year:_0x2edf8b,month:_0x297e12}=this[_0xfe6977(0x236)];_0x4bb159[_0xfe6977(0x25e)]=this[_0xfe6977(0x27c)][_0x297e12-0x1]+'\x20'+_0x2edf8b;const _0x1a7b6a=this[_0xfe6977(0x1b8)]?this['_gregorianToPersian'](this[_0xfe6977(0x1b8)][_0xfe6977(0xe9)]):null,_0x2f80e2=this[_0xfe6977(0xe3)]?this['_gregorianToPersian'](this[_0xfe6977(0xe3)]):null,_0x550fab=new Date(),_0x19b9f9=this['_gregorianToPersian'](_0x550fab),_0x593c2f=this[_0xfe6977(0x193)](_0x2edf8b,_0x297e12),_0x711fd6=this['_getFirstDayOfPersianMonth'](_0x2edf8b,_0x297e12);let _0x2956d8='';for(let _0x5a81cf=0x0;_0x5a81cf<_0x711fd6;_0x5a81cf++){_0x2956d8+=_0xfe6977(0x1b2);}for(let _0x1db446=0x1;_0x1db446<=_0x593c2f;_0x1db446++){const _0x3701c9=_0x19b9f9[_0xfe6977(0x1d8)]===_0x2edf8b&&_0x19b9f9['month']===_0x297e12&&_0x19b9f9[_0xfe6977(0xee)]===_0x1db446,_0x26ac2a=_0x1a7b6a&&_0x1a7b6a[_0xfe6977(0x1d8)]===_0x2edf8b&&_0x1a7b6a[_0xfe6977(0x1cf)]===_0x297e12&&_0x1a7b6a[_0xfe6977(0xee)]===_0x1db446,_0x581a41=_0x2f80e2&&_0x2f80e2[_0xfe6977(0x1d8)]===_0x2edf8b&&_0x2f80e2[_0xfe6977(0x1cf)]===_0x297e12&&_0x2f80e2['day']===_0x1db446;let _0x1e5e21=_0xfe6977(0x1ca);if(_0x3701c9)_0x1e5e21+=_0xfe6977(0x151);if(_0x26ac2a)_0x1e5e21+=_0xfe6977(0x165);if(_0x581a41)_0x1e5e21+=_0xfe6977(0x295);_0x2956d8+=_0xfe6977(0x233)+_0x1e5e21+_0xfe6977(0x300)+_0x1db446+_0xfe6977(0x306)+(_0x3701c9?_0xfe6977(0x2aa):_0x26ac2a?_0xfe6977(0x16e):_0x581a41?'تاریخ\x20انتخاب\x20شده':'')+'\x22>'+_0x1db446+'</span>';}_0x4d541e[_0xfe6977(0x28f)]=_0x2956d8;const _0x11aee7=_0x4d541e[_0xfe6977(0x316)](_0xfe6977(0x166));_0x11aee7[_0xfe6977(0x33f)](_0x159dbf=>{const _0x57a325=_0xfe6977;_0x159dbf[_0x57a325(0x17b)]('click',()=>{const _0x329943=_0x57a325,_0xb8faef=parseInt(_0x159dbf['getAttribute'](_0x329943(0x2b8)));this['_selectCalendarDate'](_0x2edf8b,_0x297e12,_0xb8faef);});});},'_selectCalendarDate'(_0x1e84a4,_0x116958,_0x57bcb7){const _0x17c0c8=a0_0x4d3c49;this[_0x17c0c8(0xe3)]=this[_0x17c0c8(0x1e1)](_0x1e84a4,_0x116958,_0x57bcb7),this[_0x17c0c8(0x21d)]();const _0x517086=DOMManager['getElement'](this[_0x17c0c8(0x158)][_0x17c0c8(0x18f)]);_0x517086&&(_0x517086[_0x17c0c8(0x12f)]=![]);const _0x3191d5=DOMManager[_0x17c0c8(0x20c)](this[_0x17c0c8(0x158)][_0x17c0c8(0x270)]);_0x3191d5&&(_0x3191d5['classList'][_0x17c0c8(0x199)](_0x17c0c8(0xdc)),_0x3191d5[_0x17c0c8(0x25e)]=this[_0x17c0c8(0x17d)](this['_selectedNewDate']));},'_formatPersianDate'(_0x59d5a0){const _0x265a8e=a0_0x4d3c49,_0x59b190=this[_0x265a8e(0x31f)](_0x59d5a0);return _0x59b190['day']+'\x20'+this['_persianMonths'][_0x59b190[_0x265a8e(0x1cf)]-0x1]+'\x20'+_0x59b190[_0x265a8e(0x1d8)];},async '_handleApplyChanges'(){const _0x22f4f8=a0_0x4d3c49;if(!this[_0x22f4f8(0x1b8)]||!this[_0x22f4f8(0xe3)])return;globalThis[_0x22f4f8(0x15d)]?.(_0x22f4f8(0x14a),this[_0x22f4f8(0x1b8)][_0x22f4f8(0x1a6)]);const _0x478aa9=DOMManager[_0x22f4f8(0x20c)](this['ELEMENT_IDS'][_0x22f4f8(0x18f)]);try{this[_0x22f4f8(0x176)](_0x478aa9,!![]),await this[_0x22f4f8(0x263)](this[_0x22f4f8(0x1b8)]['subscriptionId'],this[_0x22f4f8(0xe3)]),NotificationManager['showSuccess'](_0x22f4f8(0x33d)),this[_0x22f4f8(0x1b8)]['expiryDate']=this['_selectedNewDate'],this[_0x22f4f8(0xf3)](this[_0x22f4f8(0x1b8)]),this[_0x22f4f8(0xe3)]=null,this[_0x22f4f8(0x21d)](),this[_0x22f4f8(0x313)](),this[_0x22f4f8(0x332)]();}catch(_0x50c7f8){globalThis['__GPTYAR_DEV_LOG__']?.(_0x22f4f8(0x14e),_0x50c7f8),NotificationManager[_0x22f4f8(0x2e8)]('خطا\x20در\x20به‌روزرسانی\x20تاریخ\x20انقضا');}finally{this[_0x22f4f8(0x176)](_0x478aa9,![]);if(_0x478aa9)_0x478aa9[_0x22f4f8(0x12f)]=!![];}},async '_handleDeleteSubscriber'(){const _0x4c6a98=a0_0x4d3c49;if(!this[_0x4c6a98(0x1b8)])return;if(!confirm('آیا\x20از\x20حذف\x20کاربر\x20\x22'+this[_0x4c6a98(0x1b8)][_0x4c6a98(0x2fb)]+'\x22\x20اطمینان\x20دارید؟'))return;globalThis[_0x4c6a98(0x15d)]?.(_0x4c6a98(0x1d1),this[_0x4c6a98(0x1b8)][_0x4c6a98(0x1a6)]);const _0x57a667=DOMManager[_0x4c6a98(0x20c)](this[_0x4c6a98(0x158)][_0x4c6a98(0x1f9)]);try{this[_0x4c6a98(0x176)](_0x57a667,!![]),await this[_0x4c6a98(0x2f9)](this['_selectedSubscriber'][_0x4c6a98(0x1a6)]),NotificationManager[_0x4c6a98(0x29a)](_0x4c6a98(0x120)),this[_0x4c6a98(0x15e)](),this[_0x4c6a98(0x313)](),this[_0x4c6a98(0x332)]();}catch(_0x352bab){globalThis['__GPTYAR_DEV_LOG__']?.(_0x4c6a98(0x179),_0x352bab),NotificationManager[_0x4c6a98(0x2e8)]('خطا\x20در\x20حذف\x20کاربر');}finally{this[_0x4c6a98(0x176)](_0x57a667,![]);}},async 'fetchSubscriberDetails'(_0x119bb5){const _0x3cdf3e=a0_0x4d3c49;globalThis[_0x3cdf3e(0x15d)]?.(_0x3cdf3e(0x1c7),_0x119bb5);try{const _0xa25c1a=this['_subscribersList'][_0x3cdf3e(0x19c)](_0x3e6a91=>_0x3e6a91[_0x3cdf3e(0x1fa)]===_0x119bb5);if(_0xa25c1a){const _0x2e36c6=new Date();return _0x2e36c6[_0x3cdf3e(0x142)](_0x2e36c6[_0x3cdf3e(0x127)]()+_0xa25c1a['remainingDays']),{..._0xa25c1a,'expiryDate':_0x2e36c6};}return null;}catch(_0xe91745){return globalThis[_0x3cdf3e(0x15d)]?.(_0x3cdf3e(0x2a1),_0xe91745),null;}},async 'updateSubscriberExpiry'(_0x32a24f,_0x4642a0){const _0x15fefa=a0_0x4d3c49;return globalThis[_0x15fefa(0x15d)]?.(_0x15fefa(0x2e3),_0x32a24f,_0x4642a0),await AccupdatorAPI[_0x15fefa(0x263)](_0x32a24f,_0x4642a0);},async 'deleteSubscriber'(_0xef0b36){const _0x45758d=a0_0x4d3c49;return globalThis['__GPTYAR_DEV_LOG__']?.('[AccupdatorManager]\x20Deleting\x20subscription:',_0xef0b36),await AccupdatorAPI[_0x45758d(0x2f9)](_0xef0b36);},async 'refreshUI'(){const _0x577aed=a0_0x4d3c49;globalThis['__GPTYAR_DEV_LOG__']?.('[AccupdatorManager]\x20Refreshing\x20UI...');try{this[_0x577aed(0x133)](),await this[_0x577aed(0x149)](),globalThis[_0x577aed(0x15d)]?.(_0x577aed(0x121));}catch(_0xb4b9de){globalThis['__GPTYAR_DEV_LOG__']?.(_0x577aed(0x1b5),_0xb4b9de);}}};

/* === GPTYAR unlimited new-user option v1 === */
;(() => {
  const UNLIMITED_ID = 'newUserUnlimited';
  const UNLIMITED_ROW_ID = 'newUserUnlimitedRow';

  const getExpiryElement = manager =>
    DOMManager.getElement(manager.ELEMENT_IDS.NEW_USER_EXPIRY);

  const getCalendarContainer = manager => {
    const calendar = DOMManager.getElement(manager.ELEMENT_IDS.NEW_USER_CALENDAR);
    return calendar ? calendar.closest('.subscriber-calendar-container') : null;
  };

  const syncUnlimitedUI = manager => {
    const checkbox = document.getElementById(UNLIMITED_ID);
    const expiry = getExpiryElement(manager);
    const calendarContainer = getCalendarContainer(manager);
    const unlimited = Boolean(checkbox && checkbox.checked);

    if (calendarContainer) {
      calendarContainer.style.display = unlimited ? 'none' : '';
    }

    if (expiry) {
      if (unlimited) {
        expiry.textContent = 'نامحدود';
        expiry.classList.add('selected');
      } else if (manager._newUserExpiryDate) {
        expiry.textContent = manager._formatPersianDate(manager._newUserExpiryDate);
        expiry.classList.add('selected');
      } else {
        expiry.textContent = 'انتخاب نشده';
        expiry.classList.remove('selected');
      }
    }
  };

  const ensureUnlimitedControl = manager => {
    let checkbox = document.getElementById(UNLIMITED_ID);
    if (checkbox) return checkbox;

    const expiry = getExpiryElement(manager);
    const expiryRow = expiry ? expiry.closest('.detail-row') : null;
    if (!expiryRow) return null;

    const row = document.createElement('div');
    row.id = UNLIMITED_ROW_ID;
    row.className = 'detail-row new-user-unlimited-row';
    row.style.cssText = 'align-items:center;gap:12px;';
    row.innerHTML = `
      <span class="detail-label">مدت اشتراک:</span>
      <label for="${UNLIMITED_ID}" style="display:inline-flex;align-items:center;gap:8px;cursor:pointer;user-select:none;">
        <input id="${UNLIMITED_ID}" type="checkbox" style="width:18px;height:18px;cursor:pointer;accent-color:#22c55e;">
        <span style="font-weight:700;">نامحدود</span>
      </label>`;

    expiryRow.insertAdjacentElement('afterend', row);
    checkbox = document.getElementById(UNLIMITED_ID);

    if (checkbox) {
      checkbox.addEventListener('change', () => {
        syncUnlimitedUI(manager);
        manager._updateNewUserCreateButtonState();
      });
    }

    return checkbox;
  };

  const originalSetupNewUserMenuEventListeners =
    AccupdatorManager._setupNewUserMenuEventListeners;

  AccupdatorManager._setupNewUserMenuEventListeners = function () {
    originalSetupNewUserMenuEventListeners.call(this);
    ensureUnlimitedControl(this);
    syncUnlimitedUI(this);
  };

  const originalResetNewUserForm = AccupdatorManager._resetNewUserForm;

  AccupdatorManager._resetNewUserForm = function () {
    originalResetNewUserForm.call(this);

    const checkbox = ensureUnlimitedControl(this);
    if (checkbox) checkbox.checked = false;

    syncUnlimitedUI(this);
    this._updateNewUserCreateButtonState();
  };

  AccupdatorManager._updateNewUserCreateButtonState = function () {
    const nameInput =
      DOMManager.getElement(this.ELEMENT_IDS.NEW_USER_NAME_INPUT);
    const createButton =
      DOMManager.getElement(this.ELEMENT_IDS.NEW_USER_CREATE_BTN);

    if (!nameInput || !createButton) return;

    const checkbox = document.getElementById(UNLIMITED_ID);
    const hasName = nameInput.value.trim().length > 0;
    const isUnlimited = Boolean(checkbox && checkbox.checked);
    const hasExpiry = this._newUserExpiryDate !== null;

    createButton.disabled = !(hasName && (isUnlimited || hasExpiry));
  };

  AccupdatorManager._handleCreateNewUser = async function () {
    const nameInput =
      DOMManager.getElement(this.ELEMENT_IDS.NEW_USER_NAME_INPUT);
    const checkbox = document.getElementById(UNLIMITED_ID);
    const isUnlimited = Boolean(checkbox && checkbox.checked);

    if (!nameInput || (!isUnlimited && !this._newUserExpiryDate)) return;

    const name = nameInput.value.trim();
    if (!name) return;

    const createButton =
      DOMManager.getElement(this.ELEMENT_IDS.NEW_USER_CREATE_BTN);

    try {
      this._setButtonLoading(createButton, true);

      const createdUser = await this.createNewUser(
        name,
        isUnlimited ? null : this._newUserExpiryDate
      );

      NotificationManager.showSuccess('کاربر جدید با موفقیت ایجاد شد');

      if (isUnlimited) {
        this._hideNewUserMenu();
        await this._loadSubscribers();
        await this.refreshAccountInfo();
      } else {
        const newUserMenu =
          DOMManager.getElement(this.ELEMENT_IDS.NEW_USER_MENU);

        if (newUserMenu) {
          newUserMenu.classList.remove('active');
        }

        this._showCreatedUserDetails(createdUser);
        await this._loadSubscribers();
        await this.refreshAccountInfo();
      }
    } catch (error) {
      globalThis.__GPTYAR_DEV_LOG__?.(
        '[AccupdatorManager] Error creating new user:',
        error
      );
      NotificationManager.showError('خطا در ایجاد کاربر جدید');
    } finally {
      this._setButtonLoading(createButton, false);
      this._updateNewUserCreateButtonState();
    }
  };
})();

/* === GPTYAR unlimited subscription v4 === */
;(() => {
  const UNLIMITED_ID = 'newUserUnlimited';
  const UNLIMITED_ROW_ID = 'newUserUnlimitedRow';
  const UNLIMITED_EXPIRES_AT = '2099-12-31T23:59:59.999Z';
  const UNLIMITED_YEAR = 2099;

  const getExpiryElement = manager =>
    DOMManager.getElement(manager.ELEMENT_IDS.NEW_USER_EXPIRY);

  const getCalendarContainer = manager => {
    const calendar = DOMManager.getElement(manager.ELEMENT_IDS.NEW_USER_CALENDAR);
    return calendar ? calendar.closest('.subscriber-calendar-container') : null;
  };

  const isUnlimitedDate = value => {
    if (!value) return false;
    const date = value instanceof Date ? value : new Date(value);
    return !Number.isNaN(date.getTime()) &&
      date.getUTCFullYear() >= UNLIMITED_YEAR;
  };

  const isUnlimitedSelected = () => {
    const input = document.getElementById(UNLIMITED_ID);
    return Boolean(input && input.checked);
  };

  const extractApiMessage = error => {
    const raw = error && error.message
      ? String(error.message)
      : String(error || 'خطای نامشخص');

    const jsonMatch = raw.match(/(\{[\s\S]*\})\s*$/);
    if (jsonMatch) {
      try {
        const parsed = JSON.parse(jsonMatch[1]);
        const msg = parsed.message || parsed.error || parsed.detail || parsed.errors;
        if (msg) return typeof msg === 'string' ? msg : JSON.stringify(msg);
      } catch (_) {}
    }

    return raw
      .replace(/^API request failed\s*\([^)]*\):?\s*/i, '')
      .trim();
  };

  const syncUnlimitedUI = manager => {
    const unlimited = isUnlimitedSelected();
    const expiry = getExpiryElement(manager);
    const calendarContainer = getCalendarContainer(manager);

    if (calendarContainer) {
      calendarContainer.classList.toggle('new-user-calendar-hidden', unlimited);
    }

    if (!expiry) return;

    expiry.classList.toggle('new-user-expiry-unlimited', unlimited);

    if (unlimited) {
      expiry.textContent = 'نامحدود';
      expiry.classList.add('selected');
    } else if (manager._newUserExpiryDate) {
      expiry.textContent = manager._formatPersianDate(manager._newUserExpiryDate);
      expiry.classList.add('selected');
    } else {
      expiry.textContent = 'انتخاب نشده';
      expiry.classList.remove('selected');
    }
  };

  const ensureUnlimitedControl = manager => {
    let input = document.getElementById(UNLIMITED_ID);
    if (input) return input;

    const expiry = getExpiryElement(manager);
    const expiryRow = expiry ? expiry.closest('.detail-row') : null;
    if (!expiryRow) return null;

    const row = document.createElement('div');
    row.id = UNLIMITED_ROW_ID;
    row.className = 'detail-row new-user-unlimited-row';
    row.innerHTML = `
      <div class="new-user-unlimited-copy">
        <span class="detail-label">اشتراک نامحدود</span>
        <span class="new-user-unlimited-hint">بدون تاریخ پایان</span>
      </div>
      <label class="new-user-unlimited-switch" title="فعال یا غیرفعال کردن اشتراک نامحدود">
        <input id="${UNLIMITED_ID}" type="checkbox" aria-label="اشتراک نامحدود">
        <span class="new-user-unlimited-slider">
          <span class="new-user-unlimited-knob"></span>
        </span>
      </label>
    `;

    expiryRow.insertAdjacentElement('afterend', row);
    input = document.getElementById(UNLIMITED_ID);

    if (input) {
      input.addEventListener('change', () => {
        syncUnlimitedUI(manager);
        manager._updateNewUserCreateButtonState();
      });
    }

    return input;
  };

  const createUnlimitedUser = async name => {
    const url = CONFIG.API_SERVER + '/accupdator/subscribers/create';
    return await AccupdatorAPI._request(url, 'POST', {
      name,
      expiresAt: UNLIMITED_EXPIRES_AT
    });
  };

  const originalSetup = AccupdatorManager._setupNewUserMenuEventListeners;
  AccupdatorManager._setupNewUserMenuEventListeners = function () {
    originalSetup.call(this);
    ensureUnlimitedControl(this);
    syncUnlimitedUI(this);
  };

  const originalReset = AccupdatorManager._resetNewUserForm;
  AccupdatorManager._resetNewUserForm = function () {
    originalReset.call(this);
    const input = ensureUnlimitedControl(this);
    if (input) input.checked = false;
    syncUnlimitedUI(this);
    this._updateNewUserCreateButtonState();
  };

  AccupdatorManager._updateNewUserCreateButtonState = function () {
    const nameInput = DOMManager.getElement(this.ELEMENT_IDS.NEW_USER_NAME_INPUT);
    const createButton = DOMManager.getElement(this.ELEMENT_IDS.NEW_USER_CREATE_BTN);
    if (!nameInput || !createButton) return;

    const hasName = nameInput.value.trim().length > 0;
    const hasExpiry = this._newUserExpiryDate !== null;

    createButton.disabled =
      !(hasName && (isUnlimitedSelected() || hasExpiry));
  };

  AccupdatorManager._handleCreateNewUser = async function () {
    const nameInput = DOMManager.getElement(this.ELEMENT_IDS.NEW_USER_NAME_INPUT);
    const createButton = DOMManager.getElement(this.ELEMENT_IDS.NEW_USER_CREATE_BTN);
    if (!nameInput) return;

    const name = nameInput.value.trim();
    if (!name) return;

    const unlimited = isUnlimitedSelected();
    if (!unlimited && !this._newUserExpiryDate) return;

    try {
      this._setButtonLoading(createButton, true);

      if (unlimited) {
        await createUnlimitedUser(name);
        NotificationManager.showSuccess('کاربر نامحدود با موفقیت ایجاد شد');
        this._hideNewUserMenu();
        await this._loadSubscribers();
        await this.refreshAccountInfo();
        return;
      }

      const createdUser = await this.createNewUser(
        name,
        this._newUserExpiryDate
      );

      NotificationManager.showSuccess('کاربر جدید با موفقیت ایجاد شد');

      const menu = DOMManager.getElement(this.ELEMENT_IDS.NEW_USER_MENU);
      if (menu) menu.classList.remove('active');

      this._showCreatedUserDetails(createdUser);
      await this._loadSubscribers();
      await this.refreshAccountInfo();
    } catch (error) {
      const message = extractApiMessage(error);

      globalThis.__GPTYAR_DEV_LOG__?.(
        '[AccupdatorManager] Error creating new user:',
        error
      );

      NotificationManager.showError(
        'خطا در ایجاد کاربر: ' +
        (message.length > 160 ? message.slice(0, 160) + '…' : message)
      );
    } finally {
      this._setButtonLoading(createButton, false);
      this._updateNewUserCreateButtonState();
    }
  };

  const originalFetchSubscribersList = AccupdatorManager.fetchSubscribersList;
  AccupdatorManager.fetchSubscribersList = async function () {
    const items = await originalFetchSubscribersList.call(this);
    return items.map(item => ({
      ...item,
      isUnlimited: isUnlimitedDate(item.expiryDate)
    }));
  };

  const originalGenerateSubscriberItemHTML =
    AccupdatorManager._generateSubscriberItemHTML;

  AccupdatorManager._generateSubscriberItemHTML = function (item) {
    const html = originalGenerateSubscriberItemHTML.call(this, item);
    if (!item?.isUnlimited) return html;

    return html.replace(
      String(item.remainingDays) + ' روز',
      'نامحدود'
    );
  };

  const originalFetchSubscriberDetails =
    AccupdatorManager.fetchSubscriberDetails;

  AccupdatorManager.fetchSubscriberDetails = async function (token) {
    const item = Array.isArray(this._subscribersList)
      ? this._subscribersList.find(entry => entry.token === token)
      : null;

    if (item && item.isUnlimited) {
      return { ...item };
    }

    return await originalFetchSubscriberDetails.call(this, token);
  };

  const originalUpdateSubscriberDetailsContent =
    AccupdatorManager._updateSubscriberDetailsContent;

  AccupdatorManager._updateSubscriberDetailsContent = function (item) {
    originalUpdateSubscriberDetailsContent.call(this, item);

    if (!item || !(item.isUnlimited || isUnlimitedDate(item.expiryDate))) {
      return;
    }

    const expiry = DOMManager.getElement(
      this.ELEMENT_IDS.SUBSCRIBER_DETAILS_EXPIRY
    );

    if (expiry) {
      expiry.textContent = 'نامحدود';
      expiry.classList.add('new-user-expiry-unlimited');
    }
  };
})();


/* === GPTYAR edit subscriber unlimited v5 === */
;(() => {
  const EDIT_UNLIMITED_ID = 'subscriberUnlimitedEdit';
  const EDIT_UNLIMITED_ROW_ID = 'subscriberUnlimitedEditRow';
  const UNLIMITED_EXPIRES_AT = '2099-12-31T23:59:59.999Z';
  const UNLIMITED_YEAR = 2099;

  const isUnlimitedDate = value => {
    if (!value) return false;

    const date =
      value instanceof Date
        ? value
        : new Date(value);

    return (
      !Number.isNaN(date.getTime()) &&
      date.getUTCFullYear() >= UNLIMITED_YEAR
    );
  };

  const isCurrentSubscriberUnlimited = manager => {
    const subscriber = manager._selectedSubscriber;

    return Boolean(
      subscriber &&
      (
        subscriber.isUnlimited ||
        isUnlimitedDate(subscriber.expiryDate)
      )
    );
  };

  const getEditUnlimitedCheckbox = () =>
    document.getElementById(EDIT_UNLIMITED_ID);

  const getDetailsExpiryElement = manager =>
    DOMManager.getElement(
      manager.ELEMENT_IDS.SUBSCRIBER_DETAILS_EXPIRY
    );

  const getDetailsCalendarContainer = manager => {
    const calendar =
      DOMManager.getElement(
        manager.ELEMENT_IDS.SUBSCRIBER_CALENDAR
      );

    return calendar
      ? calendar.closest('.subscriber-calendar-container')
      : null;
  };

  const getApplyButton = manager =>
    DOMManager.getElement(
      manager.ELEMENT_IDS.SUBSCRIBER_APPLY_BTN
    );

  const extractApiMessage = error => {
    const raw =
      error && error.message
        ? String(error.message)
        : String(error || 'خطای نامشخص');

    const jsonMatch =
      raw.match(/(\{[\s\S]*\})\s*$/);

    if (jsonMatch) {
      try {
        const parsed =
          JSON.parse(jsonMatch[1]);

        const message =
          parsed.message ||
          parsed.error ||
          parsed.detail ||
          parsed.errors;

        if (message) {
          return typeof message === 'string'
            ? message
            : JSON.stringify(message);
        }
      } catch (_) {}
    }

    return raw
      .replace(
        /^API request failed\s*\([^)]*\):?\s*/i,
        ''
      )
      .trim();
  };

  const syncEditUnlimitedUI = manager => {
    const checkbox =
      getEditUnlimitedCheckbox();

    const expiry =
      getDetailsExpiryElement(manager);

    const calendarContainer =
      getDetailsCalendarContainer(manager);

    const applyButton =
      getApplyButton(manager);

    if (!checkbox) return;

    const desiredUnlimited =
      checkbox.checked;

    const currentUnlimited =
      isCurrentSubscriberUnlimited(manager);

    if (calendarContainer) {
      calendarContainer.classList.toggle(
        'new-user-calendar-hidden',
        desiredUnlimited
      );
    }

    if (expiry) {
      expiry.classList.toggle(
        'new-user-expiry-unlimited',
        desiredUnlimited
      );

      if (desiredUnlimited) {
        expiry.textContent = 'نامحدود';
      } else if (manager._selectedNewDate) {
        expiry.textContent =
          manager._formatPersianDate(
            manager._selectedNewDate
          );
      } else if (currentUnlimited) {
        expiry.textContent =
          'تاریخ جدید انتخاب نشده';

        expiry.classList.remove(
          'new-user-expiry-unlimited'
        );
      } else if (
        manager._selectedSubscriber &&
        manager._selectedSubscriber.expiryDate
      ) {
        expiry.textContent =
          manager._formatPersianDate(
            manager._selectedSubscriber.expiryDate
          );
      }
    }

    if (applyButton) {
      if (desiredUnlimited) {
        applyButton.disabled =
          currentUnlimited;
      } else if (currentUnlimited) {
        applyButton.disabled =
          !manager._selectedNewDate;
      }
    }
  };

  const ensureEditUnlimitedControl = manager => {
    let checkbox =
      getEditUnlimitedCheckbox();

    if (checkbox) {
      return checkbox;
    }

    const expiry =
      getDetailsExpiryElement(manager);

    const expiryRow =
      expiry
        ? expiry.closest('.detail-row')
        : null;

    if (!expiryRow) {
      return null;
    }

    const row =
      document.createElement('div');

    row.id =
      EDIT_UNLIMITED_ROW_ID;

    row.className =
      'detail-row new-user-unlimited-row subscriber-unlimited-edit-row';

    row.innerHTML = `
      <div class="new-user-unlimited-copy">
        <span class="detail-label">
          اشتراک نامحدود
        </span>

        <span class="new-user-unlimited-hint">
          بدون تاریخ پایان
        </span>
      </div>

      <label
        class="new-user-unlimited-switch"
        title="تغییر اشتراک به حالت نامحدود"
      >
        <input
          id="${EDIT_UNLIMITED_ID}"
          type="checkbox"
          aria-label="اشتراک نامحدود"
        >

        <span class="new-user-unlimited-slider">
          <span class="new-user-unlimited-knob"></span>
        </span>
      </label>
    `;

    expiryRow.insertAdjacentElement(
      'afterend',
      row
    );

    checkbox =
      getEditUnlimitedCheckbox();

    if (checkbox) {
      checkbox.addEventListener(
        'change',
        () => {
          const currentUnlimited =
            isCurrentSubscriberUnlimited(
              manager
            );

          if (checkbox.checked) {
            manager._selectedNewDate = null;
          } else if (currentUnlimited) {
            manager._selectedNewDate = null;

            if (
              typeof manager._initializeCalendar ===
              'function'
            ) {
              manager._initializeCalendar(
                new Date()
              );
            }
          }

          syncEditUnlimitedUI(manager);
        }
      );
    }

    return checkbox;
  };

  const originalDetailsSetup =
    AccupdatorManager
      ._setupSubscriberDetailsEventListeners;

  AccupdatorManager
    ._setupSubscriberDetailsEventListeners =
    function () {

      originalDetailsSetup.call(this);

      ensureEditUnlimitedControl(this);
    };

  const originalOpenDetails =
    AccupdatorManager
      ._openSubscriberDetails;

  AccupdatorManager
    ._openSubscriberDetails =
    async function (token) {

      const result =
        await originalOpenDetails.call(
          this,
          token
        );

      const checkbox =
        ensureEditUnlimitedControl(this);

      if (checkbox) {
        checkbox.checked =
          isCurrentSubscriberUnlimited(
            this
          );
      }

      syncEditUnlimitedUI(this);

      return result;
    };

  const originalSelectCalendarDate =
    AccupdatorManager
      ._selectCalendarDate;

  AccupdatorManager
    ._selectCalendarDate =
    function (year, month, day) {

      const checkbox =
        getEditUnlimitedCheckbox();

      if (
        checkbox &&
        checkbox.checked
      ) {
        checkbox.checked = false;
      }

      const result =
        originalSelectCalendarDate.call(
          this,
          year,
          month,
          day
        );

      syncEditUnlimitedUI(this);

      return result;
    };

  AccupdatorManager
    ._handleApplyChanges =
    async function () {

      if (!this._selectedSubscriber) {
        return;
      }

      const checkbox =
        getEditUnlimitedCheckbox();

      const desiredUnlimited =
        Boolean(
          checkbox &&
          checkbox.checked
        );

      const currentUnlimited =
        isCurrentSubscriberUnlimited(
          this
        );

      let targetDate = null;

      if (desiredUnlimited) {
        if (currentUnlimited) {
          return;
        }

        targetDate =
          new Date(
            UNLIMITED_EXPIRES_AT
          );
      } else {
        targetDate =
          this._selectedNewDate;

        if (!targetDate) {
          return;
        }
      }

      const applyButton =
        getApplyButton(this);

      try {
        this._setButtonLoading(
          applyButton,
          true
        );

        await this.updateSubscriberExpiry(
          this._selectedSubscriber.subscriptionId,
          targetDate
        );

        this._selectedSubscriber.expiryDate =
          targetDate;

        this._selectedSubscriber.isUnlimited =
          desiredUnlimited;

        this._selectedNewDate = null;

        NotificationManager.showSuccess(
          desiredUnlimited
            ? 'اشتراک با موفقیت نامحدود شد'
            : 'تاریخ انقضا با موفقیت به‌روزرسانی شد'
        );

        this._updateSubscriberDetailsContent(
          this._selectedSubscriber
        );

        if (
          !desiredUnlimited &&
          typeof this._initializeCalendar ===
            'function'
        ) {
          this._initializeCalendar(
            targetDate
          );
        }

        await this._loadSubscribers();
        await this.refreshAccountInfo();

        if (checkbox) {
          checkbox.checked =
            desiredUnlimited;
        }

        syncEditUnlimitedUI(this);

      } catch (error) {
        const message =
          extractApiMessage(error);

        globalThis
          .__GPTYAR_DEV_LOG__?.(
            '[AccupdatorManager] Error updating subscription:',
            error
          );

        NotificationManager.showError(
          'خطا در به‌روزرسانی اشتراک: ' +
          (
            message.length > 160
              ? message.slice(0, 160) + '…'
              : message
          )
        );

      } finally {
        this._setButtonLoading(
          applyButton,
          false
        );

        syncEditUnlimitedUI(this);
      }
    };
})();


/* === GPTYAR edit subscriber unlimited robust v6 === */
;(() => {
  const ID = 'subscriberUnlimitedEdit';
  const ROW_ID = 'subscriberUnlimitedEditRow';
  const UNLIMITED_EXPIRES_AT = '2099-12-31T23:59:59.999Z';
  const UNLIMITED_YEAR = 2099;

  const isUnlimitedDate = value => {
    if (!value) return false;
    const date = value instanceof Date ? value : new Date(value);
    return !Number.isNaN(date.getTime()) &&
      date.getUTCFullYear() >= UNLIMITED_YEAR;
  };

  const currentIsUnlimited = manager => {
    const item = manager._selectedSubscriber;
    return Boolean(
      item &&
      (
        item.isUnlimited ||
        isUnlimitedDate(item.expiryDate)
      )
    );
  };

  const getExpiry = manager =>
    DOMManager.getElement(
      manager.ELEMENT_IDS.SUBSCRIBER_DETAILS_EXPIRY
    );

  const getCalendarContainer = manager => {
    const calendar = DOMManager.getElement(
      manager.ELEMENT_IDS.SUBSCRIBER_CALENDAR
    );
    return calendar
      ? calendar.closest('.subscriber-calendar-container')
      : null;
  };

  const getApplyButton = manager =>
    DOMManager.getElement(
      manager.ELEMENT_IDS.SUBSCRIBER_APPLY_BTN
    );

  const getCheckbox = () =>
    document.getElementById(ID);

  const extractApiMessage = error => {
    const raw = error && error.message
      ? String(error.message)
      : String(error || 'خطای نامشخص');

    const jsonMatch = raw.match(/(\{[\s\S]*\})\s*$/);

    if (jsonMatch) {
      try {
        const parsed = JSON.parse(jsonMatch[1]);
        const msg =
          parsed.message ||
          parsed.error ||
          parsed.detail ||
          parsed.errors;

        if (msg) {
          return typeof msg === 'string'
            ? msg
            : JSON.stringify(msg);
        }
      } catch (_) {}
    }

    return raw
      .replace(/^API request failed\s*\([^)]*\):?\s*/i, '')
      .trim();
  };

  const sync = manager => {
    const checkbox = getCheckbox();
    if (!checkbox) return;

    const expiry = getExpiry(manager);
    const calendarContainer = getCalendarContainer(manager);
    const applyButton = getApplyButton(manager);
    const desiredUnlimited = checkbox.checked;
    const wasUnlimited = currentIsUnlimited(manager);

    if (calendarContainer) {
      calendarContainer.classList.toggle(
        'new-user-calendar-hidden',
        desiredUnlimited
      );
    }

    if (expiry) {
      expiry.classList.toggle(
        'new-user-expiry-unlimited',
        desiredUnlimited
      );

      if (desiredUnlimited) {
        expiry.textContent = 'نامحدود';
        expiry.classList.add('selected');
      } else if (manager._selectedNewDate) {
        expiry.textContent =
          manager._formatPersianDate(
            manager._selectedNewDate
          );
        expiry.classList.add('selected');
      } else if (wasUnlimited) {
        expiry.textContent = 'تاریخ جدید انتخاب نشده';
        expiry.classList.remove(
          'new-user-expiry-unlimited'
        );
      } else if (
        manager._selectedSubscriber &&
        manager._selectedSubscriber.expiryDate
      ) {
        expiry.textContent =
          manager._formatPersianDate(
            manager._selectedSubscriber.expiryDate
          );
      }
    }

    if (applyButton) {
      if (desiredUnlimited) {
        applyButton.disabled = wasUnlimited;
      } else {
        applyButton.disabled = !manager._selectedNewDate;
      }
    }
  };

  const ensure = manager => {
    let checkbox = getCheckbox();

    if (checkbox) {
      return checkbox;
    }

    const expiry = getExpiry(manager);
    const expiryRow =
      expiry ? expiry.closest('.detail-row') : null;

    if (!expiryRow) {
      return null;
    }

    const row = document.createElement('div');
    row.id = ROW_ID;
    row.className =
      'detail-row new-user-unlimited-row subscriber-unlimited-edit-row';

    row.innerHTML = `
      <div class="new-user-unlimited-copy">
        <span class="detail-label">اشتراک نامحدود</span>
        <span class="new-user-unlimited-hint">بدون تاریخ پایان</span>
      </div>

      <label
        class="new-user-unlimited-switch"
        title="فعال یا غیرفعال کردن اشتراک نامحدود"
      >
        <input
          id="${ID}"
          type="checkbox"
          aria-label="اشتراک نامحدود"
        >
        <span class="new-user-unlimited-slider">
          <span class="new-user-unlimited-knob"></span>
        </span>
      </label>
    `;

    expiryRow.insertAdjacentElement(
      'afterend',
      row
    );

    checkbox = getCheckbox();

    if (checkbox) {
      checkbox.addEventListener('change', () => {
        if (checkbox.checked) {
          manager._selectedNewDate = null;
        } else if (currentIsUnlimited(manager)) {
          manager._selectedNewDate = null;

          if (
            typeof manager._initializeCalendar ===
            'function'
          ) {
            manager._initializeCalendar(
              new Date()
            );
          }
        }

        sync(manager);
      });
    }

    return checkbox;
  };

  const refreshControl = manager => {
    const checkbox = ensure(manager);
    if (!checkbox) return;

    checkbox.checked =
      currentIsUnlimited(manager);

    sync(manager);
  };

  const previousOpen =
    AccupdatorManager._openSubscriberDetails;

  AccupdatorManager._openSubscriberDetails =
    async function (token) {
      const result =
        await previousOpen.call(this, token);

      requestAnimationFrame(() => {
        refreshControl(this);
      });

      setTimeout(() => {
        refreshControl(this);
      }, 0);

      return result;
    };

  const previousCreateDetails =
    AccupdatorManager._createSubscriberDetailsMenu;

  AccupdatorManager._createSubscriberDetailsMenu =
    function () {
      const result =
        previousCreateDetails.call(this);

      requestAnimationFrame(() => {
        ensure(this);
      });

      return result;
    };

  const previousSelectDate =
    AccupdatorManager._selectCalendarDate;

  AccupdatorManager._selectCalendarDate =
    function (year, month, day) {
      const checkbox = getCheckbox();

      if (checkbox && checkbox.checked) {
        checkbox.checked = false;
      }

      const result =
        previousSelectDate.call(
          this,
          year,
          month,
          day
        );

      sync(this);
      return result;
    };

  AccupdatorManager._handleApplyChanges =
    async function () {
      if (!this._selectedSubscriber) {
        return;
      }

      const checkbox = getCheckbox();
      const desiredUnlimited =
        Boolean(checkbox && checkbox.checked);
      const wasUnlimited =
        currentIsUnlimited(this);

      let targetDate = null;

      if (desiredUnlimited) {
        if (wasUnlimited) {
          return;
        }

        targetDate =
          new Date(UNLIMITED_EXPIRES_AT);
      } else {
        targetDate =
          this._selectedNewDate;

        if (!targetDate) {
          return;
        }
      }

      const applyButton =
        getApplyButton(this);

      try {
        this._setButtonLoading(
          applyButton,
          true
        );

        await this.updateSubscriberExpiry(
          this._selectedSubscriber.subscriptionId,
          targetDate
        );

        this._selectedSubscriber.expiryDate =
          targetDate;

        this._selectedSubscriber.isUnlimited =
          desiredUnlimited;

        this._selectedNewDate = null;

        NotificationManager.showSuccess(
          desiredUnlimited
            ? 'اشتراک با موفقیت نامحدود شد'
            : 'تاریخ انقضا با موفقیت به‌روزرسانی شد'
        );

        this._updateSubscriberDetailsContent(
          this._selectedSubscriber
        );

        await this._loadSubscribers();
        await this.refreshAccountInfo();

        if (checkbox) {
          checkbox.checked =
            desiredUnlimited;
        }

        sync(this);
      } catch (error) {
        const message =
          extractApiMessage(error);

        globalThis.__GPTYAR_DEV_LOG__?.(
          '[AccupdatorManager] Error updating subscription:',
          error
        );

        NotificationManager.showError(
          'خطا در به‌روزرسانی اشتراک: ' +
          (
            message.length > 160
              ? message.slice(0, 160) + '…'
              : message
          )
        );
      } finally {
        this._setButtonLoading(
          applyButton,
          false
        );

        sync(this);
      }
    };

  const observer = new MutationObserver(() => {
    const detailsMenu =
      DOMManager.getElement(
        AccupdatorManager.ELEMENT_IDS.SUBSCRIBER_DETAILS_MENU
      );

    if (!detailsMenu) {
      return;
    }

    ensure(AccupdatorManager);

    if (
      detailsMenu.classList.contains('active') &&
      AccupdatorManager._selectedSubscriber
    ) {
      refreshControl(AccupdatorManager);
    }
  });

  const startObserver = () => {
    if (!document.body) {
      setTimeout(startObserver, 50);
      return;
    }

    observer.observe(
      document.body,
      {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ['class']
      }
    );

    ensure(AccupdatorManager);
  };

  startObserver();
})();
